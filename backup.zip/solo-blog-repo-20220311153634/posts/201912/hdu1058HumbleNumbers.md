title: hdu- 1058 Humble Numbers
date: '2019-12-03 19:51:23'
updated: '2019-12-03 19:51:23'
tags: [DP, acm]
permalink: /articles/2019/12/03/1575373883131.html
---
题目链接：[hdu-1058](http://acm.hdu.edu.cn/showproblem.php?pid=1058)

思路：可四个循环暴力，此处说下 dp;让每个数都乘以 2,3,5,7； 四个指针，分别指向已经乘过 2,3,5,7 的数的下一个，然后让这四个数分别乘以 2,3,5,7 取最小值，注意 11，12,13 的英文字母结尾都是 th

```c++
#include <iostream>    
#include <string>  
using namespace std;  
int num[5845];  
int min(int a,int b,int c,int d) //求四者中最小值 
{  
    a=a>b?b:a;  
    c=c>d?d:c;  
    return a>c?c:a;  
}  
  
int main()  
{  
    int n;  
    int i1=1,i2=1,i3=1,i4=1;//四个数，分别记录2，3,5,7,的个数 
    num[1]=1;  
    for(int i=2;i<=5842;i++)  
    {  
      num[i]=min(num[i1]*2,num[i2]*3,num[i3]*5,num[i4]*7);//让每个数分别乘2,3,5,7，取四者中最小值 
  
      if(num[i]==num[i1]*2)i1++; 
      if(num[i]==num[i2]*3)i2++;  
      if(num[i]==num[i3]*5)i3++;  
      if(num[i]==num[i4]*7)i4++;  
    }  
    
    while(cin>>n&&n)  
    {  
          if(n % 10 == 1 && n % 100 != 11)  
              printf("The %dst humble number is %lld.\n",n ,num[n]);  
          else if(n % 10 == 2 && n % 100 != 12)  
              printf("The %dnd humble number is %lld.\n",n ,num[n]);  
          else if(n % 10 == 3 && n % 100 != 13)  
              printf("The %drd humble number is %lld.\n",n ,num[n]);  
          else  
              printf("The %dth humble number is %lld.\n",n ,num[n]);  
    }  
    return 0;  
}  


```
