title: docker 笔记
date: '2020-10-27 22:47:41'
updated: '2020-10-27 22:47:41'
tags: [docker, 学习笔记, 软件教程]
permalink: /articles/2020/10/27/1603810061485.html
---
## Docker 安装

1.centos6.8

```shell
yum install -y epel-release
yum install -y docker-io
# 配置文件 /etc/sysconfig/docker
# 启动 docker 服务
service docker start
# 验证
docker version
```

2.其他参考 https://docs.docker.com/engine/install/

## 阿里云镜像加速

https://help.aliyun.com/document_detail/60750.html

针对安装了Docker for Mac的用户，您可以参考以下配置步骤：

在任务栏点击 Docker Desktop 应用图标 -> Perferences，在左侧导航菜单选择 Docker Engine，在右侧输入栏编辑 json 文件。将

https://ln6hzcek.mirror.aliyuncs.com（自己的加速地址） 加到"registry-mirrors"的数组里，点击 Apply & Restart按钮，等待Docker重启并应用配置的镜像加速器。

## Docker 命令

### 帮助命令

```
# 查看版本
docker version
# docker 相关信息 
docker info
# 帮助命令
docker --help
```

### 镜像命令

```
# 查看本地镜像
docker images
  -a # 列出本地所有镜像，包含中间镜像层
  -q # 只显示镜像 ID
  --digests # 显示镜像的摘要信息
  --no-trunc # 显示完整的镜像信息
  
# 搜索镜像
docker search 镜像名
  --no-trunc # 显示完整的镜像信息
  -s # 列出收藏数不小于指定值的镜像
  --automated # 只列出 automated build 类型的镜像
  
# 下载镜像
docker pull 镜像名[:TAG]  # 默认 tag 为 latest

# 删除镜像
docker rmi 镜像名[:TAG]/镜像 ID [镜像2名[:TAG]/镜像2 ID]
  -f # 强制删除
  
# 删除全部镜像
docker rmi -f $(docker imgages -qa)

# 查看镜像构建历史
docker history 镜像 ID
```

### 容器命令

```
# 新建并启动容器
docker run [OPITIONS] IMAGE [COMMAND] [ARG...]
  OPITIONS 说明
    --name="容器名称"
    -d # 后台运行容器，并返回容器 ID
    -i # 以交互模式运行容器，通常与 it 同时使用
    -t # 为容器重新分配一个伪输入终端，通常与 i 同时使用
    -P # 随机端口映射
    -p # 指定端口映射，有以下四种格式
      ip:hostPort:containerPort
      ip::containerPort
      hostPort:containerPort
      containerPort
    
# 列出当前所有正在运行的容器
docker ps [OPITIONS]
  -a # 列出当前所有正在运行的容器+历史上运行过的容器
  -l # 显示最近创建的容器
  -n # 显示最近 n 个创建的容器
  -q # 静默模式，只显示容器编号
  -no-trunc # 不截断输出
  
# 退出容器
exit # 停止当前终端进程并退出
ctrl+P+Q # 当前终端不停止退出

# 启动容器
docker start 容器 ID/Name

# 重启容器
docker restart 容器 ID/Name

# 停止容器
docker stop 容器 ID/Name

# 强制停止容器
docker kill 容器 ID/Name

# 删除已停止的容器
docker rm [OPITIONS] 容器 ID/Name
  -f # 强制删除
  
# 一次删除多个容器
docker rm -f $(docker ps -a -q)
docker ps -a -q | xargs docker rm

# 查看容器日志
docker logs [OPITIONS] 容器ID
  -t # 加入时间戳
  -f # 跟随最新的日志打印
  --tail n # 显示最后 n 条 
  
# 查看容器内运行的进程
docker top 容器 ID

# 查看容器内部细节
docker inspect 容器 ID

# 进入正在运行的容器并以命令行交互
docker attach 容器 ID # 直接进入容器启动命令的终端，不会启动新的 bash 进程
docker exec -it 容器 ID bashShell  # 在容器中打开新的终端，并且启动新的 bash 进程，而且可以将命令执行结果返回给宿主机
docker exec -it 容器 ID /bin/bash # 进入容器

# 从容器内拷贝文件到宿主机
docker cp 容器 ID:容器内路径 目的主机路径

# 提交容器副本使之成为一个新的镜像
docker commit 容器 ID 要创建的目标镜像名:[标签名]
  -m="提交的描述信息"
  -a="作者"
```

## 镜像原理

分层的好处：共享资源
有多个镜像都从相同的 base 镜像构建而来，那么宿主机只需在磁盘上保存一份 base 镜像，同时内存中也只需加载一份 base  镜像，就可以为所有容器服务了。而且镜像的每一层都可以被共享。

Docker 镜像都是只读的
当容器启动时，一个新的可写层被加载到镜像的顶部，这一层通常被称作“容器层”，“容器层”之下的都叫镜像层。
比如 tomcat,从内到外分别为 kernel、centos、jdk、tomcat，tomcat 为容器层，其他为镜像层。

## Doker 容器数据卷

Docker 数据持久化有两种方式：

* bind mount
* Volume

### bind mount

bind mount 就是常用的 -v 的方式。

```
docker run -it -v /宿主机绝对路径目录:/容器内目录 镜像名
  -v # 指定数据卷，容器和宿主机数据共享，没有的话会自动新建文件夹

# 查看数据卷是否挂载成功
docker inspect 容器 ID

# 容器内目录只读
docker run -it -v /宿主机绝对路径目录:/容器内目录:ro 镜像名
```

* 宿主机目录路径必须为全路径(准确的说需要以`/`或`~/`开始的路径)，不然 docker 会将其当做 volume 处理
* 宿主机上的目录不存在时，docker 会自动创建该目录
* 容器中的目录不存在时，docker 会自动创建该目录
* 如果容器中的目录已经有内容，docker 会使用主机上的目录将其覆盖掉

### volume

Volume 是被 docker 管理的，docker 下所有的 volume 都在宿主机上的指定目录 `/var/lib/docker/volumes` 下。

```
# 创建 volume
docker volume create volumeName

# 查看所有容器卷
docker volume ls 

# 将 volume 挂载到容器目录
docker run -it -v volumeName:/mydata 镜像名

# 查看 volume
docker volume inspect volumeName

# 可见 volume 位于 /var/lib/docker/volumes/volumeName/_data

# 删除自定义数据卷
docker volume rm volumeName
```

此时，如果 volumeName 不存在，那么 docker 会自动创建 volumeName，然后再挂载。

```
# 也可以不指定 host 上的 volume
docker run -it -v /mydata tomcat
```

此时 docker 将自动创建一个匿名的 volume，并将其挂载到 container 中的 `/mydata` 目录。匿名 volume 在 host 机器上的目录路径类似于：`/var/lib/docker/volumes/300c2264cd0acfe862507eedf156eb61c197720f69e7e9a053c87c2182b2e7d8/_data`。

**与 bind mount 不同的是，如果 volume 是空的而 container 中的目录有内容，那么 docker 会将 container 目录中的内容拷贝到 volume 中，但是如果 volume 中已经有内容，则会将 container 中的目录覆盖。**

### DockerFile 添加

dockerfile 相当于对镜像源码级的描述。

出于可移植和分享的考虑，用 -v 主机目录:容器目录 这种方法不能够直接在 Dockerfile 中实现。
由于宿主机目录是依赖于特定宿主机的，并不能够保证在所有的宿主机上都存在这样的特定目录。

```
vim /mydocker/Dokerfile

# volume test
FROM centos   # 基于 centos
VOLUME["/dockerVolumeContainer1", "/dockerVolumeContainer2", "/dockerVolumeContainer3"]
CMD each "finished, -success"
CMD /bin/bash

# 容器卷默认位置
/var/ib/docker/volumes/很长的字符串/_data

# 构建镜像
docker build -f /mydocker/Dockerfile -t rainsheep/centos .
  -f # dokerfile 文件位置
  -t # 镜像名
  . # 镜像在哪个目录
```

### 数据卷共享

命名的容器挂载数据卷，其它容器通过挂载这个（父容器）实现数据共享，挂载数据卷的容器，称之为数据卷容器。

```
# 新建一个容器
docker run -it --name dc01 rainsheep/centos
# 容器 dc02 的数据卷和 dc01 共享
docker run -it --name dc02 --volumes-from dc01 rainsheep/centos 
# 容器 dc03 的数据卷和 dc01 共享
docker run -it --name dc03 --volumes-from dc01 rainsheep/centos 
# 删除容器 dc01
docker rm dc01
# 发现 dc02 和 dc03 数据还能共享，就像加入了群聊一样
```

容器之间配置信息的传递，数据卷的生命周期一直持续到没有容器使用它为止。

## Docker 容器网络

* 所有 docker 容器共用一个网关
* 网桥为每一个 docker 分配一个 IP
* 容器之间可以通过 IP 进行通信
* 外部网络没办法通过 IP 地址访问到容器内部，只能通过端口映射来访问
* 四种网络模式

  | Docker网络模式 | 配置 | 说明 |
  | - | - | - |
  | host模式 | –network=host | 容器和宿主机共享Network namespace。mac 系统无法使用。 |
  | container模式 | -network=container:容器名或者 ID | 容器和另外一个容器共享Network namespace。 |
  | none模式 | –network=none | 容器有独立的Network namespace，但并没有对其进行任何网络设置，如分配veth pair 和网桥连接，配置IP等。 |
  | bridge模式 | –network=bridge | （默认为该模式） |

## DockerFile

Dockerfile 是用来构建 Docker 镜像的构建文件，是由一系列命令和参数构成的脚本。

编写 Dockerfile 文件 → docker build → docker run

scratch 为源镜像

**dockerfile 内容基础知识**

* 每条保留字指令都必须为大写且后面要跟随至少一个参数
* 指令按照从上到下，顺序执行
* `#` 表示注释
* 每条指令都会创建一个新的镜像层，并对镜像进行提交

**docker 执行 dockerfile 的大致流程**

* docker 从基础镜像运行一个容器
* 执行每一条指令并对容器做出修改
* 执行类似 docker commit 的操作提交一个新的镜像层
* docker 再基于刚刚提交的镜像运行一个新容器
* 执行 dockerfile 中的下一条指令直至所有指令都执行完成

**dockerfile 体系结构**

* FROM: 基础镜像，当前镜像是基于哪个镜像的
* MAINTAINER: 作者+作者的邮箱
* RUN: 容器构建时需要运行的命令
* EXPOSE: 暴露端口号
* WORKDIR: 指定镜像创建后，终端默认登录时的工作目录
* ENV: 用来在构建镜像过程中设置环境变量
* ADD: 将宿主机目录下的文件拷贝进镜像且 ADD 命令会自动处理 URL 和解压 tar 压缩包
* COPY:  类似ADD，拷贝文件和目录到镜像中。将从构建上下文目录中 <源路径> 的文件/目录复制到新的一层的镜像内的 <目标路径> 位置

  * COPY src dest
  * COPY ["src","dest"]
* VOLUME: 容器数据卷，用于数据保存和持久化工作
* CMD:

  * 指定一个容器启动时要运行的命令
  * Dockerfile 中可以有多个 CMD 指令，但只有最后一个生效，**CMD 会被 docker run之 后的命令参数替换**
    * `docker run -it centos ls -l` 则原 dockerfile 中的 CMD 会被替换掉
  * `CMD <命令>`
  * `CMD ["可执行命令","参数 1","参数 2"...]`，例如`CMD ["curl", "-s", "http://ip.cn"]`
  * 参数列表格式：`CMD ["参数 1","参数 2"...]`，指定了在 ENTERYPOINT 指令后，使用 CMD 指定具体的参数
* ENTRYPOINT

  * 指定一个容器启动时要运行的命令
  * ENTRYPOINT 的目的和 CMD 一样，都是在指定容器启动命令及参数
  * **docker run 之后的参数会被当做参数传递给 ENTRYPOINT, 之后形成新的命令组合**
* ONBUILD: 当构建一个被继承的 Dockerfile 时运行命令，父镜像在被子继承后父镜像的 onbuild  被触发
