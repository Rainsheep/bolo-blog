title: Chrome始终开启flash
date: '2019-12-11 14:59:49'
updated: '2019-12-11 14:59:49'
tags: [软件教程, windows]
permalink: /articles/2019/12/11/1576047589725.html
---
>**谷歌公司计划在2020年12月，取消Chrome的Flash插件支持。**

### 69.0之前
1. 打开 chrome://settings/content/flash  
2. 禁止网站运行Flash -> 改为“先询问（推荐）”  
3. 允许->添加  
4. 添加
```
https://*
http://*
```

### 69.0~70.0
>69.0~70.0，Flash权限受到进一步限制，默认仅在当前浏览会话有效。  
关闭Ephemeral Flash Permission，才能看到“添加”按钮。

1. 打开 chrome://flags/#enable-ephemeral-flash-permission  
2. 把它从Default改为Disabled  
3. 重新打开Chrome，进入 chrome://settings/content/flash  
4. 添加
```
https://*
http://*
```

### 71.0以上
>从71.0开始，Flash插件的Ephemeral模式不可关闭。  
修改允许名单，要动用“Chrome政策模板”，对Windows来说最终就是注册表。

**请注意这是一项危险操作：**
>使用方法：复制到新建的.reg文件中，双击运行
```reg
Windows Registry Editor Version 5.00  
[HKEY_CURRENT_USER\SOFTWARE\Policies\Chromium] 
"AllowOutdatedPlugins"=dword:00000001 
"RunAllFlashInAllowMode"=dword:00000001 
"DefaultPluginsSetting"=dword:00000001 
"HardwareAccelerationModeEnabled"=dword:00000001 
[HKEY_CURRENT_USER\SOFTWARE\Policies\Chromium\PluginsAllowedForUrls] 
"1"="https://*" 
"2"="http://*" 
[HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Google\Chrome] 
"AllowOutdatedPlugins"=dword:00000001 
"RunAllFlashInAllowMode"=dword:00000001 
"DefaultPluginsSetting"=dword:00000001 
"HardwareAccelerationModeEnabled"=dword:00000001 
[HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Google\Chrome\PluginsAllowedForUrls] 
"1"="https://*" 
"2"="http://*"
```
或者下载以下文件
[chromeOpenFlash.zip](https://img.hacpai.com/file/2019/12/chromeOpenFlash-6b6d4252.zip)


