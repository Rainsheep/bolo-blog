title: Ubuntu图形化root用户登录
date: '2020-08-03 23:58:54'
updated: '2020-08-03 23:58:54'
tags: [Linux]
permalink: /articles/2020/08/03/1596470334604.html
---
参考文献：[Ubuntu16.04中设置使用root用户登录图形界面](https://blog.csdn.net/dengjin20104042056/article/details/80461749#01-%E4%BD%BF%E7%94%A8root%E7%94%A8%E6%88%B7%E7%99%BB%E5%BD%95%E5%9B%BE%E5%BD%A2%E7%95%8C%E9%9D%A2%E8%AE%BE%E7%BD%AE%E6%96%B9%E6%B3%95)

### 1. root用户登录图形界面方法

Ubuntu默认的是root用户不能登录图形界面的，只能以其他用户登录图形界面。这样就很麻烦，因为权限的问题，不能随意复制删除文件，用gedit编辑文件时经常不能保存，只能用vim去编辑。

打开配置文件
`vim /usr/share/lightdm/lightdm. conf. d/50-ubuntu. conf`

在最后一行添加
`greeter-show-manual-login=true`

> 【备注】
> greeter-show-manual-login=true #手工输入登陆系统的用户名和密码
> allow-guest=false #不允许guest登录


设置root用户密码
`sudo passwd root`

在终端中测试root用户是否能够登录成功
`su - root`

用root用户在图形界面登录会有错误，读取/root/.profile时发生错误解决办法
打开root用户配置文件
`vim /root/.profile`

修改mesg n所在行信息如下：
`tty -s && mesg n || true`

> tty命令不跟任何参数，会打印标准输入设备的文件名称，如果标准输入不是终端设备时，打印“not a tty”，否则打印终端设备名称，比如“/etc/tty1”、“/etc/pts/1”。
> tty命令跟上参数-s（或–silent或–quiet），不会打印任何信息，根据退出状态可以用来判断标准输入是否是终端。（Print nothing; only return an exit status.）
> tty命令的退出状态：如果标准输入是终端时为0，否则返回1。

root用户使用音频设备（可以不用此步操作）
`vim /etc/profile`

添加
`pulseaudio --start --log-target=syslog`

重启，root登录

### 2.  Linux su 和 sudo 命令区别

**su 命令**

su就是切换用户的工具，通过su命令可以在不同用户之间切换，其用法为

`su [可选参数] [用户名]`

超级权限用户root向普通用户切换不需要密码，普通用户切换到其他任何用户都需要密码验证。

**sudo 命令**

通过sudo，可以把某些超级权限有针对性的下放，并且不需要普通用户知道root密码，故sudo又称为受限制的su。

sudo执行命令的过程是当前用户切换为root（或者其他用户），然后以root（指定切换到的用户）身份执行命令，执行完成后，直接退回到当前用户，而这些的前提是要通过sudo的配置文件/etc/sudoers来进行授权。


### 3. Linux su 和 su - 命令区别

su只是切换身份，Shell环境仍然是当前用户的shell，su -连用户和Shell环境一起切换成了指定用户的身份。
