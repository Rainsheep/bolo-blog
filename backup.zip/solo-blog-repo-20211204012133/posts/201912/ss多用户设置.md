title: ss多用户设置
date: '2019-12-02 22:31:22'
updated: '2019-12-02 22:31:53'
tags: [ss, Shadowsocks]
permalink: /articles/2019/12/02/1575297082354.html
---
查看配置文件
`cat /etc/shadowsocks-go/config.json`

修改配置文件
`vi /etc/shadowsocks-go/config.json`

### 单用户

> 默认的配置信息就是单用户的。

```shell
{
    "server":"0.0.0.0",
    "server_port":443,
    "local_address":"127.0.0.1",
    "local_port":1080,
    "password":"aabbcc",
    "timeout":300,
    "method":"aes-256-cfb",
    "fast_open":false
}

```

### 多用户
```shell
{
    "server":"0.0.0.0",
    "local_address":"127.0.0.1",
    "local_port":1080,
    "port_password":{
         "443":"pwd000",
         "9001":"pwd123",
         "9002":"pwd234",
         "9003":"pwd345",
         "9004":"pwd456"                    
    },
    "timeout":300,
    "method":"aes-256-cfb",
    "fast_open": false
}

```

修改完配置文件之后
`/etc/init.d/shadowsocks-go restart`

如果连接失败，**打开防火墙配置文件看下是否开放了端口。**
`cat /etc/sysconfig/iptables`

如果没有，就将配置防火墙开放端口。
编辑iptables配置文件
`vi /etc/sysconfig/iptables`

添加规则 `-A INPUT -p tcp -m tcp --dport 端口号 -j ACCEPT `
```
在配置文件中加入以下代码。
#开放9001端口
-A INPUT -p tcp -m tcp --dport 9001 -j ACCEPT  
 
#开放9001-9009之间的所有端口
-A INPUT -p tcp -m tcp --dport 9001:9009 -j ACCEPT  

```
**注意，要添加的规则要加在 `REJECT` 那行代码的上面的任意位置，不能加在它的下面行，否则不会生效 ：**

重启防火墙
`service iptables restart或者/etc/init.d/iptables restart`
