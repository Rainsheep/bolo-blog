title: Spring Boot+Spring Security+JWT实现单点登录
date: '2021-08-02 23:42:56'
updated: '2021-09-18 18:55:37'
tags: [java, sso]
permalink: /articles/2021/08/02/1627918976083.html
---
参考文献：

[Spring Boot+Spring Security+JWT实现单点登录](https://caochenlei.blog.csdn.net/article/details/112973713)

完整代码：

链接: https://pan.baidu.com/s/1sasfinZoLALl64DghR20fg 提取码: q3b5

# 一、常用术语

## 1.1 SSO

**SSO 术语介绍：**

单点登录 (SingleSignOn，SSO)，就是通过用户的一次性鉴别登录。当用户在身份认证服务器上登录一次以后，即可获得访问单点登录系统中其他关联系统和应用软件的权限，同时这种实现是不需要管理员对用户的登录状态或其他信息进行修改的，这意味着在多个应用系统中，用户只需一次登录就可以访问所有相互信任的应用系统。这种方式减少了由登录产生的时间消耗，辅助了用户管理，是目前比较流行的一种分布式登录方式。

**SSO 实现流程：**

首先，我们要明确，在分布式项目中，每台服务器都有各自独立的 session，而这些 session 之间是无法直接共享资源的，所以，session 通常不能被作为单点登录的技术方案。最合理的单点登录方案流程如下图所示：

![678b989efc79d06a1ac1d1107b6cb22d.png](https://b3logfile.com/file/2021/08/678b989efc79d06a1ac1d1107b6cb22d-b87312d3.png)

**单点登录的实现分两大环节：**

用户认证：这一环节主要是用户向认证服务器发起认证请求，认证服务器给用户返回一个成功的令牌 token， 主要在认证服务器中完成，即图中的 A 系统，注意 A 系统只能有一个。
身份校验：这一环节是用户携带 token 去访问其他服务器时，在其他服务器中要对 token 的真伪进行检验，主要在资源服务器中完成，即图中的 B 系统，这里 B 系统可以有很多个。

## 1.2 JWT

JWT 是 JSON WEB TOKEN 的缩写，它是基于 RFC 7519 标准定义的一种可以安全传输的的JSON对象，由于使用了数字签名，所以是可信任和安全的。

从分布式认证流程中，我们不难发现，这中间起最关键作用的就是 token，token 的安全与否，直接关系到系统的健壮性，这里我们选择使用 JWT 来实现 token 的生成和校验。JWT，全称 JSON Web Token，官网地址：https://jwt.io，是一款出色的分布式身份校验方案，可以生成 token，也可以解析检验 token。

JWT 生成的 token 由三部分组成(JWT token的格式：header.payload.signature)：

头部：主要设置一些规范信息，签名部分的编码格式就在头部中声明。
载荷：token 中存放有效信息的部分，比如用户名，用户角色，过期时间等，但是不要放密码，会泄露密码。
签名：将头部与载荷分别采用 base64 编码后，用“.”相连，再加入盐，最后使用头部声明的编码类型进行编码，就得到了签名。
那么，一个完整的 jwt 字符串到底长成什么样呢？
![arch_screen_13](https://oss.rainsheep.cn/blog/arch_screen_13-1631962503-0cf.png)

JWT 生成的 token 的安全性分析：

从 JWT 生成的 token 组成上来看，要想避免 token 被伪造，主要就得看签名部分了，而签名部分又有三部分组成，其中头部和载荷的 base64 编码，几乎是透明的，毫无安全性可言，那么最终守护 token 安全的重担就落在了加入的盐上面了，试想，如果生成 token 所用的盐与解析 token 时加入的盐是一样的。岂不是类似于中国人民银行把人民币防伪技术公开了？大家可以用这个盐来解析 token，就能用来伪造 token。 这时，我们就需要对盐采用非对称加密的方式进行加密，以达到生成 token 与校验 token 方所用的盐不一致的安全效果！

注意：加盐的意思就是让味道改变，也就是让通过加盐来提高 token 的复杂度，让 token 更加安全，这个盐你可以任意指定，全凭自己和项目需求。

**JWT实现认证和授权的原理**

- 用户调用登录接口，登录成功后获取到 JWT 的 token；
- 之后用户每次调用接口都在 http 的 header 中添加一个叫 Authorization 的头，值为 JWT 的 token；
- 后台程序通过对 Authorization 头中信息的解码及数字签名校验来获取其中的用户信息，从而实现认证和授权。

## 1.3 RSA

**RSA术语介绍：**

1976 年，两位美国计算机学家 Whitfield Diffie 和 Martin Hellman，提出了一种崭新构思，可以在不直接传递密钥的情况下，完成解密。这被称为 "Diffie-Hellman 密钥交换算法"。这个算法启发了其他科学家。人们认识到，加密和解密可以使用不同的规则，只要这两种规则之间存在某种对应关系即可，这样就避免了直接传递密钥。这种新的加密模式被称为"非对称加密算法"。

（1）乙方生成两把密钥（公钥和私钥）。公钥是公开的，任何人都可以获得，私钥则是保密的。
（2）甲方获取乙方的公钥，然后用它对信息加密。
（3）乙方得到加密后的信息，用私钥解密。
RSA 是1977年由罗纳德·李维斯特（Ron Rivest）、阿迪·萨莫尔（Adi Shamir）和伦纳德·阿德曼（Leonard Adleman）一起提出的，当时他们三人都在麻省理工学院工作，RSA 就是他们三人姓氏开头字母拼在一起组成的 。从那时直到现在，RSA 算法一直是最广为使用的"非对称加密算法"。毫不夸张地说，只要有计算机网络的地方，就有 RSA 算法。这种算法非常可靠，密钥越长，它就越难破解。根据已经披露的文献，目前被破解的最长 RSA 密钥是 768 个二进制位。也就是说，长度超过 768 位的密钥，还无法破解（至少没人公开宣布）。因此可以认为，1024 位的 RSA 密钥基本安全，2048 位的密钥极其安全。

**RSA使用流程：**

基本使用流程，同时生成两把密钥：私钥和公钥，私钥保存起来，公钥可以下发给信任客户端

私钥加密，持有私钥或公钥才可以解密
公钥加密，持有私钥才可解密
因此，我们认证服务一般存放私钥和公钥，而资源服务一般存放公钥。私钥负责加密，公钥负责解密。

![c61aa8b2a2a068f665e8879f451ff4ca.png](https://b3logfile.com/file/2021/08/c61aa8b2a2a068f665e8879f451ff4ca-1f199326.png)

# 二、认证思路

## 2.1 分析集中式认证流程

* 用户认证：使用 UsernamePasswordAuthenticationFilter 过滤器中 attemptAuthentication 方法实现认证功能，该过滤器父类中 successfulAuthentication 方法实现认证成功后的操作。
* 身份校验：使用 BasicAuthenticationFilter 过滤器中 doFilterInternal 方法验证是否登录，以决定能否进入后续过滤器。

## 2.2 分析分布式认证流程

* 用户认证：分布式项目多数是前后端分离的架构设计，我们要满足可以接受异步 post 的认证请求参数，需要修改 UsernamePasswordAuthenticationFilter 过滤器中 attemptAuthentication 方法，让其能够接收请求体。另外，默认 successfulAuthentication 方法在认证通过后，是把用户信息直接放入session就完事了，现在我们需要修改这个方法，在认证通过后生成 token 并返回给用户。
* 身份校验： 原来 BasicAuthenticationFilter 过滤器中 doFilterInternal 方法校验用户是否登录，就是看 session 中是否有用户信息，我们要修改为，验证用户携带的 token 是否合法，并解析出用户信息，交给 SpringSecurity，以便于后续的授权功能可以正常使用。

# 三、 工程介绍

## 3.1 介绍父工程

为了方便大家能够快速进行学习，我已经提前搭建好了一个基本工程，工程代码在配套资料中，名称叫单点登录基础代码，这只是一个普通的 Spring Boot 工程，该工程由四个子模块组成，一个认证服务模块，一个通用工具模块，一个订单资源模块，一个产品资源模块，我已经帮大家创建好了基本的包结构，并在父工程中对 Spring Boot 的版本进行了管理，在接下来的代码展示环节中，我并不会展示全部代码，我只展示核心代码，完整代码我会给出。

![96edd6deab17b599cdc3b2846c7155ae.png](https://b3logfile.com/file/2021/08/96edd6deab17b599cdc3b2846c7155ae-2b1637f3.png)![62e31479d7966d6f93b269784723e5a4.png](https://b3logfile.com/file/2021/08/62e31479d7966d6f93b269784723e5a4-d9a6a46f.png)

## 3.2 导入数据库

```sql
DROP DATABASE IF EXISTS `test`;

CREATE DATABASE `test`;

USE `test`;

DROP TABLE IF EXISTS `sys_role`;

CREATE TABLE `sys_role` (
  `id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '角色编号',
  `name` VARCHAR(32) NOT NULL COMMENT '角色名称',
  `desc` VARCHAR(32) NOT NULL COMMENT '角色描述',
  PRIMARY KEY (`id`)
) ENGINE=INNODB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT  INTO `sys_role`(`id`,`name`,`desc`) VALUES (1,'ROLE_USER','用户权限');
INSERT  INTO `sys_role`(`id`,`name`,`desc`) VALUES (2,'ROLE_ADMIN','管理权限');
INSERT  INTO `sys_role`(`id`,`name`,`desc`) VALUES (3,'ROLE_PRODUCT','产品权限');
INSERT  INTO `sys_role`(`id`,`name`,`desc`) VALUES (4,'ROLE_ORDER','订单权限');

DROP TABLE IF EXISTS `sys_user`;

CREATE TABLE `sys_user` (
  `id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '用户编号',
  `username` VARCHAR(32) NOT NULL COMMENT '用户名称',
  `password` VARCHAR(128) NOT NULL COMMENT '用户密码',
  `status` INT(1) NOT NULL DEFAULT '1' COMMENT '用户状态（0：关闭、1：开启）',
  PRIMARY KEY (`id`)
) ENGINE=INNODB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT  INTO `sys_user`(`id`,`username`,`password`,`status`) VALUES (1,'zhangsan','$2a$10$M7fmKpMZEkkzrTBiKie.EeAKZhQDrWAltpCA1y/py5AU/8lyiNB8y',0);
INSERT  INTO `sys_user`(`id`,`username`,`password`,`status`) VALUES (2,'lisi','$2a$10$M7fmKpMZEkkzrTBiKie.EeAKZhQDrWAltpCA1y/py5AU/8lyiNB8y',1);
INSERT  INTO `sys_user`(`id`,`username`,`password`,`status`) VALUES (3,'wangwu','$2a$10$M7fmKpMZEkkzrTBiKie.EeAKZhQDrWAltpCA1y/py5AU/8lyiNB8y',2);
INSERT  INTO `sys_user`(`id`,`username`,`password`,`status`) VALUES (4,'zhaoliu','$2a$10$M7fmKpMZEkkzrTBiKie.EeAKZhQDrWAltpCA1y/py5AU/8lyiNB8y',3);
INSERT  INTO `sys_user`(`id`,`username`,`password`,`status`) VALUES (5,'xiaoqi','$2a$10$M7fmKpMZEkkzrTBiKie.EeAKZhQDrWAltpCA1y/py5AU/8lyiNB8y',4);

DROP TABLE IF EXISTS `sys_user_role`;

CREATE TABLE `sys_user_role` (
  `uid` INT(11) NOT NULL COMMENT '用户编号',
  `rid` INT(11) NOT NULL COMMENT '角色编号',
  PRIMARY KEY (`uid`,`rid`)
) ENGINE=INNODB DEFAULT CHARSET=utf8;

INSERT  INTO `sys_user_role`(`uid`,`rid`) VALUES (1,1);
INSERT  INTO `sys_user_role`(`uid`,`rid`) VALUES (1,3);
INSERT  INTO `sys_user_role`(`uid`,`rid`) VALUES (2,1);
INSERT  INTO `sys_user_role`(`uid`,`rid`) VALUES (2,4);
INSERT  INTO `sys_user_role`(`uid`,`rid`) VALUES (3,1);
INSERT  INTO `sys_user_role`(`uid`,`rid`) VALUES (3,2);
INSERT  INTO `sys_user_role`(`uid`,`rid`) VALUES (3,3);
INSERT  INTO `sys_user_role`(`uid`,`rid`) VALUES (3,4);
```

# 四、通用模块

> 注意：本章节所有操作均在 `sso-common` 中进行。

## 4.1 导入依赖

```xml
<dependencies>
    <!--JWT-->
    <dependency>
        <groupId>io.jsonwebtoken</groupId>
        <artifactId>jjwt-api</artifactId>
        <version>0.11.2</version>
    </dependency>
    <dependency>
        <groupId>io.jsonwebtoken</groupId>
        <artifactId>jjwt-impl</artifactId>
        <version>0.11.2</version>
        <scope>runtime</scope>
    </dependency>
    <dependency>
        <groupId>io.jsonwebtoken</groupId>
        <artifactId>jjwt-jackson</artifactId>
        <version>0.11.2</version>
        <scope>runtime</scope>
    </dependency>
    <!--Jackson-->
    <dependency>
        <groupId>com.fasterxml.jackson.core</groupId>
        <artifactId>jackson-core</artifactId>
        <version>2.11.4</version>
    </dependency>
    <dependency>
        <groupId>com.fasterxml.jackson.core</groupId>
        <artifactId>jackson-databind</artifactId>
        <version>2.11.4</version>
    </dependency>
    <dependency>
        <groupId>com.fasterxml.jackson.core</groupId>
        <artifactId>jackson-annotations</artifactId>
        <version>2.11.4</version>
    </dependency>
    <!--JodaTime-->
    <dependency>
        <groupId>joda-time</groupId>
        <artifactId>joda-time</artifactId>
        <version>2.10.9</version>
    </dependency>
    <!--Lombok-->
    <dependency>
        <groupId>org.projectlombok</groupId>
        <artifactId>lombok</artifactId>
        <version>1.18.16</version>
    </dependency>

    <!--日志包-->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-logging</artifactId>
    </dependency>
    <!--测试包-->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-test</artifactId>
    </dependency>
</dependencies>
```

## 4.2 统一格式

### 4.2.1 统一载荷对象

com.caochenlei.domain.Payload

```java
/**
 * 为了方便后期获取token中的用户信息，将token中载荷部分单独封装成一个对象
 *
 * @author CaoChenLei
 */
@Data
public class Payload<T> implements Serializable {
    private String id;
    private T userInfo;
    private Date expiration;
}
```

### 4.2.2 统一返回结果

com.caochenlei.domain.Result

```java
/**
 * 统一处理返回结果
 *
 * @author CaoChenLei
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Result implements Serializable {
    private Integer code;
    private String msg;
    private Object data;
}
```

## 4.3 常用工具

### 4.3.1 JSON 工具类

com.caochenlei.utils.JsonUtils

```java
/**
 * 对Jackson中的方法进行了简单封装
 *
 * @author CaoChenLei
 */
public class JsonUtils {
    private static final Logger logger = LoggerFactory.getLogger(JsonUtils.class);
    private static final ObjectMapper mapper = new ObjectMapper();

    /**
     * 将指定对象序列化为一个json字符串
     *
     * @param obj 指定对象
     * @return 返回一个json字符串
     */
    public static String toString(Object obj) {
        if (obj == null) {
            return null;
        }
        if (obj.getClass() == String.class) {
            return (String) obj;
        }
        try {
            return mapper.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            logger.error("json序列化出错：" + obj, e);
            return null;
        }
    }

    /**
     * 将指定json字符串解析为指定类型对象
     *
     * @param json   json字符串
     * @param tClass 指定类型
     * @return 返回一个指定类型对象
     */
    public static <T> T toBean(String json, Class<T> tClass) {
        try {
            return mapper.readValue(json, tClass);
        } catch (IOException e) {
            logger.error("json解析出错：" + json, e);
            return null;
        }
    }

    /**
     * 将指定输入流解析为指定类型对象
     *
     * @param inputStream 输入流对象
     * @param tClass      指定类型
     * @return 返回一个指定类型对象
     */
    public static <T> T toBean(InputStream inputStream, Class<T> tClass) {
        try {
            return mapper.readValue(inputStream, tClass);
        } catch (IOException e) {
            logger.error("json解析出错：" + inputStream, e);
            return null;
        }
    }

    /**
     * 将指定json字符串解析为指定类型集合
     *
     * @param json   json字符串
     * @param eClass 指定元素类型
     * @return 返回一个指定类型集合
     */
    public static <E> List<E> toList(String json, Class<E> eClass) {
        try {
            return mapper.readValue(json, mapper.getTypeFactory().constructCollectionType(List.class, eClass));
        } catch (IOException e) {
            logger.error("json解析出错：" + json, e);
            return null;
        }
    }

    /**
     * 将指定json字符串解析为指定键值对类型集合
     *
     * @param json   json字符串
     * @param kClass 指定键类型
     * @param vClass 指定值类型
     * @return 返回一个指定键值对类型集合
     */
    public static <K, V> Map<K, V> toMap(String json, Class<K> kClass, Class<V> vClass) {
        try {
            return mapper.readValue(json, mapper.getTypeFactory().constructMapType(Map.class, kClass, vClass));
        } catch (IOException e) {
            logger.error("json解析出错：" + json, e);
            return null;
        }
    }

    /**
     * 将指定json字符串解析为一个复杂类型对象
     *
     * @param json json字符串
     * @param type 复杂类型
     * @return 返回一个复杂类型对象
     */
    public static <T> T nativeRead(String json, TypeReference<T> type) {
        try {
            return mapper.readValue(json, type);
        } catch (IOException e) {
            logger.error("json解析出错：" + json, e);
            return null;
        }
    }
}
```

### 4.3.2 Jwt 工具类

com.caochenlei.utils.JwtUtils

```java
/**
 * 生成token以及校验token相关方法
 *
 * @author CaoChenLei
 */
public class JwtUtils {
    private static final String JWT_PAYLOAD_USER_KEY = "user";

    private static String createJTI() {
        return new String(Base64.getEncoder().encode(UUID.randomUUID().toString().getBytes()));
    }

    /**
     * 私钥加密token
     *
     * @param userInfo   载荷中的数据
     * @param privateKey 私钥
     * @param expire     过期时间，单位分钟
     * @return JWT
     */
    public static String generateTokenExpireInMinutes(Object userInfo, PrivateKey privateKey, int expire) {
        return Jwts.builder()
                .claim(JWT_PAYLOAD_USER_KEY, JsonUtils.toString(userInfo))
                .setId(createJTI())
                .setExpiration(DateTime.now().plusMinutes(expire).toDate())
                .signWith(privateKey, SignatureAlgorithm.RS256)
                .compact();
    }

    /**
     * 私钥加密token
     *
     * @param userInfo   载荷中的数据
     * @param privateKey 私钥
     * @param expire     过期时间，单位秒
     * @return JWT
     */
    public static String generateTokenExpireInSeconds(Object userInfo, PrivateKey privateKey, int expire) {
        return Jwts.builder()
                .claim(JWT_PAYLOAD_USER_KEY, JsonUtils.toString(userInfo))
                .setId(createJTI())
                .setExpiration(DateTime.now().plusSeconds(expire).toDate())
                .signWith(privateKey, SignatureAlgorithm.RS256)
                .compact();
    }

    /**
     * 公钥解析token
     *
     * @param token     用户请求中的token
     * @param publicKey 公钥
     * @return Jws<Claims>
     */
    private static Jws<Claims> parserToken(String token, PublicKey publicKey) {
        return Jwts.parserBuilder()
                .setSigningKey(publicKey)
                .build()
                .parseClaimsJws(token);
    }

    /**
     * 获取token中的用户信息
     *
     * @param token     用户请求中的令牌
     * @param publicKey 公钥
     * @return 用户信息
     */
    public static <T> Payload<T> getInfoFromToken(String token, PublicKey publicKey, Class<T> userType) {
        Jws<Claims> claimsJws = parserToken(token, publicKey);
        Claims body = claimsJws.getBody();
        Payload<T> claims = new Payload<>();
        claims.setId(body.getId());
        claims.setUserInfo(JsonUtils.toBean(body.get(JWT_PAYLOAD_USER_KEY).toString(), userType));
        claims.setExpiration(body.getExpiration());
        return claims;
    }

    /**
     * 获取token中的载荷信息
     *
     * @param token     用户请求中的令牌
     * @param publicKey 公钥
     * @return 用户信息
     */
    public static <T> Payload<T> getInfoFromToken(String token, PublicKey publicKey) {
        Jws<Claims> claimsJws = parserToken(token, publicKey);
        Claims body = claimsJws.getBody();
        Payload<T> claims = new Payload<>();
        claims.setId(body.getId());
        claims.setExpiration(body.getExpiration());
        return claims;
    }
}
```

### 4.3.3 RSA 工具类

com.caochenlei.utils.RsaUtils

```java
/**
 * 对Rsa操作进行了简单封装
 *
 * @author CaoChenLei
 */
public class RsaUtils {
    private static final int DEFAULT_KEY_SIZE = 2048;

    /**
     * 从文件中读取公钥
     *
     * @param filename 公钥保存路径，相对于classpath
     * @return 公钥对象
     * @throws Exception
     */
    public static PublicKey getPublicKey(String filename) throws Exception {
        byte[] bytes = readFile(filename);
        return getPublicKey(bytes);
    }

    /**
     * 从文件中读取密钥
     *
     * @param filename 私钥保存路径，相对于classpath
     * @return 私钥对象
     * @throws Exception
     */
    public static PrivateKey getPrivateKey(String filename) throws Exception {
        byte[] bytes = readFile(filename);
        return getPrivateKey(bytes);
    }

    /**
     * 获取公钥
     *
     * @param bytes 公钥的字节形式
     * @return
     * @throws Exception
     */
    private static PublicKey getPublicKey(byte[] bytes) throws Exception {
        bytes = Base64.getDecoder().decode(bytes);
        X509EncodedKeySpec spec = new X509EncodedKeySpec(bytes);
        KeyFactory factory = KeyFactory.getInstance("RSA");
        return factory.generatePublic(spec);
    }

    /**
     * 获取密钥
     *
     * @param bytes 私钥的字节形式
     * @return
     * @throws Exception
     */
    private static PrivateKey getPrivateKey(byte[] bytes) throws NoSuchAlgorithmException, InvalidKeySpecException {
        bytes = Base64.getDecoder().decode(bytes);
        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(bytes);
        KeyFactory factory = KeyFactory.getInstance("RSA");
        return factory.generatePrivate(spec);
    }

    /**
     * 根据密文，生成rsa公钥和私钥，并写入指定文件
     *
     * @param publicKeyFilename  公钥文件路径
     * @param privateKeyFilename 私钥文件路径
     * @param secret             生成密钥的密文
     */
    public static void generateKey(String publicKeyFilename, String privateKeyFilename, String secret, int keySize) throws Exception {
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
        SecureRandom secureRandom = new SecureRandom(secret.getBytes());
        keyPairGenerator.initialize(Math.max(keySize, DEFAULT_KEY_SIZE), secureRandom);
        KeyPair keyPair = keyPairGenerator.genKeyPair();
        // 获取公钥并写出
        byte[] publicKeyBytes = keyPair.getPublic().getEncoded();
        publicKeyBytes = Base64.getEncoder().encode(publicKeyBytes);
        writeFile(publicKeyFilename, publicKeyBytes);
        // 获取私钥并写出
        byte[] privateKeyBytes = keyPair.getPrivate().getEncoded();
        privateKeyBytes = Base64.getEncoder().encode(privateKeyBytes);
        writeFile(privateKeyFilename, privateKeyBytes);
    }

    private static byte[] readFile(String fileName) throws Exception {
        return Files.readAllBytes(new File(fileName).toPath());
    }

    private static void writeFile(String destPath, byte[] bytes) throws IOException {
        File dest = new File(destPath);
        File parentFile = dest.getParentFile();
        if (!parentFile.exists()) {
            parentFile.mkdirs();
        }
        if (!dest.exists()) {
            dest.createNewFile();
        }
        Files.write(dest.toPath(), bytes);
    }
}
```

## 4.4 生成密钥

com.caochenlei.utils.RsaUtilsTest

```java
public class RsaUtilsTest {
    private String publicFile = "D:\\auth_key\\rsa_key.pub";
    private String privateFile = "D:\\auth_key\\rsa_key";
    private String secret = "CaoChenLeiSecret";

    @Test
    public void generateKey() throws Exception {
        RsaUtils.generateKey(publicFile, privateFile, secret, 2048);
    }
}
```

# 五、认证服务

> 注意：本章节所有操作均在`sso-auth-server`中进行。

## 5.1 导入依赖

```xml
<dependencies>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-security</artifactId>
    </dependency>
    <dependency>
        <groupId>org.mybatis.spring.boot</groupId>
        <artifactId>mybatis-spring-boot-starter</artifactId>
        <version>2.1.4</version>
    </dependency>
    <dependency>
        <groupId>mysql</groupId>
        <artifactId>mysql-connector-java</artifactId>
        <version>5.1.49</version>
    </dependency>
    <!--引入通用子模块-->
    <dependency>
        <groupId>com.caochenlei</groupId>
        <artifactId>sso-common</artifactId>
        <version>1.0-SNAPSHOT</version>
    </dependency>
</dependencies>
```

## 5.2 编写配置文件

```yaml
server:
  port: 9001
  servlet:
    application-display-name: sso-auth-server
spring:
  datasource:
    driver-class-name: com.mysql.jdbc.Driver
    url: jdbc:mysql://localhost:3309/test
    username: root
    password: root
mybatis:
  type-aliases-package: com.caochenlei.domain
  configuration:
    map-underscore-to-camel-case: true
logging:
  level:
    com.caochenlei: debug
#自定义属性，配置私钥路径
rsa:
  key:
    privateKeyPath: D:\auth_key\rsa_key
```

## 5.3 编写属性类

com.caochenlei.prop.RsaKeyProperties

```java
@Data
@ConfigurationProperties(prefix = "rsa.key", ignoreInvalidFields = true)
public class RsaKeyProperties {
    private String publicKeyPath;
    private String privateKeyPath;

    private PublicKey publicKey;
    private PrivateKey privateKey;

    /**
     * 该方法用于初始化公钥和私钥的内容
     */
    @PostConstruct
    public void loadRsaKey() throws Exception {
        if (publicKeyPath != null) {
            publicKey = RsaUtils.getPublicKey(publicKeyPath);
        }
        if (privateKeyPath != null) {
            privateKey = RsaUtils.getPrivateKey(privateKeyPath);
        }
    }
}
```

com.caochenlei.AuthServerApplication

```java
@SpringBootApplication
@EnableConfigurationProperties(RsaKeyProperties.class)
public class AuthServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(AuthServerApplication.class, args);
    }
}
```

## 5.4 编写工具类

com.caochenlei.utils.RequestUtils

```java
/**
 * 请求工具类
 *
 * @author CaoChenLei
 */
public class RequestUtils {
    private static final Logger logger = LoggerFactory.getLogger(RequestUtils.class);

    /**
     * 从请求对象的输入流中获取指定类型对象
     *
     * @param request 请求对象
     * @param clazz   指定类型
     * @return 指定类型对象
     */
    public static <T> T read(HttpServletRequest request, Class<T> clazz) {
        try {
            return JsonUtils.toBean(request.getInputStream(), clazz);
        } catch (Exception e) {
            logger.error("读取出错：" + clazz, e);
            return null;
        }
    }
}
```

com.caochenlei.utils.ResponseUtils

```java
/**
 * 响应工具类
 *
 * @author CaoChenLei
 */
public class ResponseUtils {
    private static final Logger logger = LoggerFactory.getLogger(ResponseUtils.class);

    /**
     * 向浏览器响应一个json字符串
     *
     * @param response 响应对象
     * @param status   状态码
     * @param msg      响应信息
     */
    public static void write(HttpServletResponse response, int status, String msg) {
        try {
            response.setHeader("Access-Control-Allow-Origin", "*");
            response.setHeader("Cache-Control", "no-cache");
            response.setCharacterEncoding("UTF-8");
            response.setContentType("application/json");
            response.setStatus(status);
            PrintWriter out = response.getWriter();
            out.write(JsonUtils.toString(new Result(status, msg, null)));
            out.flush();
            out.close();
        } catch (Exception e) {
            logger.error("响应出错：" + msg, e);
        }
    }
}
```

## 5.5 编写实体类

com.caochenlei.domain.SysUser

```java
@Data
public class SysUser implements UserDetails {
    private Integer id;
    private String username;
    private String password;
    private Integer status;
    private List<SysRole> sysRoles;

    @JsonIgnore
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return sysRoles;
    }

    /**
     * 是否账号已过期
     */
    @JsonIgnore
    @Override
    public boolean isAccountNonExpired() {
        return status != 1;
    }

    /**
     * 是否账号已被锁
     */
    @JsonIgnore
    @Override
    public boolean isAccountNonLocked() {
        return status != 2;
    }

    /**
     * 是否凭证已过期
     */
    @JsonIgnore
    @Override
    public boolean isCredentialsNonExpired() {
        return status != 3;
    }

    /**
     * 是否账号已禁用
     */
    @JsonIgnore
    @Override
    public boolean isEnabled() {
        return status != 4;
    }
}
```

com.caochenlei.domain.SysRole

```java
@Data
public class SysRole implements GrantedAuthority {
    private Integer id;
    private String name;
    private String desc;

    @JsonIgnore
    @Override
    public String getAuthority() {
        return name;
    }
}
```

## 5.6 编写映射接口

com.caochenlei.mapper.SysUserMapper

```java
@Mapper
public interface SysUserMapper {
    //根据用户名称查询所对应的用户信息
    @Select("select * from `sys_user` where `username` = #{username}")
    @Results({
            //主键字段映射，property代表Java对象属性，column代表数据库字段
            @Result(property = "id", column = "id", id = true),
            //普通字段映射，property代表Java对象属性，column代表数据库字段
            @Result(property = "username", column = "username"),
            @Result(property = "password", column = "password"),
            @Result(property = "status", column = "status"),
            //角色列表映射，根据用户id查询该用户所对应的角色列表sysRoles
            @Result(property = "sysRoles", column = "id",
                    javaType = List.class,
                    many = @Many(select = "com.caochenlei.mapper.SysRoleMapper.findByUid")
            )
    })
    SysUser findByUsername(String username);
}
```

com.caochenlei.mapper.SysRoleMapper

```java
@Mapper
public interface SysRoleMapper {
    //根据用户编号查询角色列表
    @Select("select * from `sys_role` where id in (" +
            "  select rid from `sys_user_role` where uid = #{uid}" +
            ")")
    List<SysRole> findByUid(Integer uid);
}
```

## 5.7 编写服务接口

com.caochenlei.service.SysUserDetailsService

```java
public interface SysUserDetailsService extends UserDetailsService {

}
```

com.caochenlei.service.impl.SysUserDetailsServiceImpl

```java
@Service
@Transactional
public class SysUserDetailsServiceImpl implements SysUserDetailsService {
    @Autowired(required = false)
    private SysUserMapper sysUserMapper;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        //根据用户名去数据库中查询指定用户，这就要保证数据库中的用户的名称必须唯一，否则将会报错
        SysUser sysUser = sysUserMapper.findByUsername(username);
        //如果没有查询到这个用户，说明数据库中不存在此用户，认证失败，此时需要抛出用户账户不存在
        if (sysUser == null) {
            throw new UsernameNotFoundException("user not exist.");
        }
        return sysUser;
    }
}
```

## 5.8 编写认证过滤器

com.caochenlei.filter.JwtAuthenticationFilter

```java
/**
 * 认证过滤器
 *
 * @author CaoChenLei
 */
public class JwtAuthenticationFilter extends UsernamePasswordAuthenticationFilter {
    private AuthenticationManager authenticationManager;
    private RsaKeyProperties prop;

    public JwtAuthenticationFilter(AuthenticationManager authenticationManager, RsaKeyProperties prop) {
        this.authenticationManager = authenticationManager;
        this.prop = prop;
    }

    @Override
    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) throws AuthenticationException {
        SysUser sysUser = RequestUtils.read(request, SysUser.class);
        String username = sysUser.getUsername();
        username = username != null ? username : "";
        String password = sysUser.getPassword();
        password = password != null ? password : "";
        UsernamePasswordAuthenticationToken authRequest = new UsernamePasswordAuthenticationToken(username, password);
        return authenticationManager.authenticate(authRequest);
    }

    /**
     * 认证成功所执行的方法
     */
    @Override
    protected void successfulAuthentication(HttpServletRequest request, HttpServletResponse response, FilterChain chain, Authentication authResult) throws IOException, ServletException {
        SysUser sysUser = new SysUser();
        sysUser.setUsername(authResult.getName());
        sysUser.setSysRoles(new ArrayList(authResult.getAuthorities()));
        String token = JwtUtils.generateTokenExpireInMinutes(sysUser, prop.getPrivateKey(), 24 * 60);
        response.addHeader("Authorization", "Bearer " + token);
        ResponseUtils.write(response, HttpServletResponse.SC_OK, "用户认证通过！");
    }

    /**
     * 认证失败所执行的方法
     */
    @Override
    protected void unsuccessfulAuthentication(HttpServletRequest request, HttpServletResponse response, AuthenticationException failed) throws IOException, ServletException {
        //清理上下文
        SecurityContextHolder.clearContext();
        System.out.println(failed);
        //判断异常类
        if (failed instanceof InternalAuthenticationServiceException) {
            ResponseUtils.write(response, HttpServletResponse.SC_FORBIDDEN, "认证服务不正常！");
        } else if (failed instanceof UsernameNotFoundException) {
            ResponseUtils.write(response, HttpServletResponse.SC_FORBIDDEN, "用户账户不存在！");
        } else if (failed instanceof BadCredentialsException) {
            ResponseUtils.write(response, HttpServletResponse.SC_FORBIDDEN, "用户密码是错的！");
        } else if (failed instanceof AccountExpiredException) {
            ResponseUtils.write(response, HttpServletResponse.SC_FORBIDDEN, "用户账户已过期！");
        } else if (failed instanceof LockedException) {
            ResponseUtils.write(response, HttpServletResponse.SC_FORBIDDEN, "用户账户已被锁！");
        } else if (failed instanceof CredentialsExpiredException) {
            ResponseUtils.write(response, HttpServletResponse.SC_FORBIDDEN, "用户密码已失效！");
        } else if (failed instanceof DisabledException) {
            ResponseUtils.write(response, HttpServletResponse.SC_FORBIDDEN, "用户账户已被锁！");
        }
    }
}
```

## 5.9 编写安全配置类

com.caochenlei.config.WebSecurityConfig

```java
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(securedEnabled = true)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
    @Autowired
    private SysUserDetailsService sysUserDetailsService;
    @Autowired
    private RsaKeyProperties prop;

    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    public AuthenticationProvider daoAuthenticationProvider() {
        DaoAuthenticationProvider daoAuthenticationProvider = new DaoAuthenticationProvider();
        daoAuthenticationProvider.setUserDetailsService(sysUserDetailsService);
        daoAuthenticationProvider.setPasswordEncoder(passwordEncoder());
        daoAuthenticationProvider.setHideUserNotFoundExceptions(false);
        return daoAuthenticationProvider;
    }

    public void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.authenticationProvider(daoAuthenticationProvider());
    }

    public void configure(HttpSecurity http) throws Exception {
        //禁用csrf保护机制
        http.csrf().disable();
        //禁用cors保护机制
        http.cors().disable();
        //禁用session会话
        http.sessionManagement().disable();
        //禁用form表单登录
        http.formLogin().disable();
        //增加自定义认证过滤器（认证服务需要配置）
        http.addFilter(new JwtAuthenticationFilter(super.authenticationManager(), prop));
    }
}
```

# 六、订单资源

> 意：本章节所有操作均在`sso-source-order`中进行。

## 6.1 导入依赖

```xml
<dependencies>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-security</artifactId>
    </dependency>
    <dependency>
        <groupId>org.mybatis.spring.boot</groupId>
        <artifactId>mybatis-spring-boot-starter</artifactId>
        <version>2.1.4</version>
    </dependency>
    <dependency>
        <groupId>mysql</groupId>
        <artifactId>mysql-connector-java</artifactId>
        <version>5.1.49</version>
    </dependency>
    <!--引入通用子模块-->
    <dependency>
        <groupId>com.caochenlei</groupId>
        <artifactId>sso-common</artifactId>
        <version>1.0-SNAPSHOT</version>
    </dependency>
</dependencies>
```

## 6.2 编写配置文件

```yaml
server:
  port: 9002
  servlet:
    application-display-name: sso-source-order
spring:
  datasource:
    driver-class-name: com.mysql.jdbc.Driver
    url: jdbc:mysql://localhost:3309/test
    username: root
    password: root
mybatis:
  type-aliases-package: com.caochenlei.domain
  configuration:
    map-underscore-to-camel-case: true
logging:
  level:
    com.caochenlei: debug
#自定义属性，配置公钥路径
rsa:
  key:
    publicKeyPath: D:\auth_key\rsa_key.pub
```

## 6.3 编写属性类

com.caochenlei.prop.RsaKeyProperties

```java
@Data
@ConfigurationProperties(prefix = "rsa.key", ignoreInvalidFields = true)
public class RsaKeyProperties {
    private String publicKeyPath;
    private String privateKeyPath;

    private PublicKey publicKey;
    private PrivateKey privateKey;

    /**
     * 该方法用于初始化公钥和私钥的内容
     */
    @PostConstruct
    public void loadRsaKey() throws Exception {
        if (publicKeyPath != null) {
            publicKey = RsaUtils.getPublicKey(publicKeyPath);
        }
        if (privateKeyPath != null) {
            privateKey = RsaUtils.getPrivateKey(privateKeyPath);
        }
    }
}
```

com.caochenlei.SourceOrderApplication（这里注意启动类名称）

```java
@SpringBootApplication
@EnableConfigurationProperties(RsaKeyProperties.class)
public class SourceOrderApplication {
    public static void main(String[] args) {
        SpringApplication.run(SourceOrderApplication.class, args);
    }
}
```

## 6.4 编写工具类

com.caochenlei.utils.RequestUtils

```java
/**
 * 请求工具类
 *
 * @author CaoChenLei
 */
public class RequestUtils {
    private static final Logger logger = LoggerFactory.getLogger(RequestUtils.class);

    /**
     * 从请求对象的输入流中获取指定类型对象
     *
     * @param request 请求对象
     * @param clazz   指定类型
     * @return 指定类型对象
     */
    public static <T> T read(HttpServletRequest request, Class<T> clazz) {
        try {
            return JsonUtils.toBean(request.getInputStream(), clazz);
        } catch (Exception e) {
            logger.error("读取出错：" + clazz, e);
            return null;
        }
    }
}
```

com.caochenlei.utils.ResponseUtils

```java
/**
 * 响应工具类
 *
 * @author CaoChenLei
 */
public class ResponseUtils {
    private static final Logger logger = LoggerFactory.getLogger(ResponseUtils.class);

    /**
     * 向浏览器响应一个json字符串
     *
     * @param response 响应对象
     * @param status   状态码
     * @param msg      响应信息
     */
    public static void write(HttpServletResponse response, int status, String msg) {
        try {
            response.setHeader("Access-Control-Allow-Origin", "*");
            response.setHeader("Cache-Control", "no-cache");
            response.setCharacterEncoding("UTF-8");
            response.setContentType("application/json");
            response.setStatus(status);
            PrintWriter out = response.getWriter();
            out.write(JsonUtils.toString(new Result(status, msg, null)));
            out.flush();
            out.close();
        } catch (Exception e) {
            logger.error("响应出错：" + msg, e);
        }
    }
}
```

## 6.5 编写验证过滤器

com.caochenlei.filter.JwtVerificationFilter

```java
/**
 * 验证过滤器
 *
 * @author CaoChenLei
 */
public class JwtVerificationFilter extends BasicAuthenticationFilter {
    private RsaKeyProperties prop;

    public JwtVerificationFilter(AuthenticationManager authenticationManager, RsaKeyProperties prop) {
        super(authenticationManager);
        this.prop = prop;
    }

    @Override
    public void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
        try {
            String header = request.getHeader("Authorization");
            if (header == null || !header.startsWith("Bearer ")) {
                //如果token的格式错误，则提示用户非法登录
                chain.doFilter(request, response);
                ResponseUtils.write(response, HttpServletResponse.SC_FORBIDDEN, "用户非法登录！");
            } else {
                //如果token的格式正确，则先要获取到token
                String token = header.replace("Bearer ", "");
                //使用公钥进行解密然后来验证token是否正确
                Payload<SysUser> payload = JwtUtils.getInfoFromToken(token, prop.getPublicKey(), SysUser.class);
                SysUser sysUser = payload.getUserInfo();
                if (sysUser != null) {
                    UsernamePasswordAuthenticationToken authResult = new UsernamePasswordAuthenticationToken(sysUser.getUsername(), null, sysUser.getAuthorities());
                    SecurityContextHolder.getContext().setAuthentication(authResult);
                    chain.doFilter(request, response);
                } else {
                    ResponseUtils.write(response, HttpServletResponse.SC_FORBIDDEN, "用户验证失败！");
                }
            }
        } catch (ExpiredJwtException e) {
            ResponseUtils.write(response, HttpServletResponse.SC_FORBIDDEN, "请您重新登录！");
        }
    }
}
```

## 6.6 编写安全配置类

com.caochenlei.config.WebSecurityConfig

```java
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(securedEnabled = true)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
    @Autowired
    private RsaKeyProperties prop;

    public void configure(HttpSecurity http) throws Exception {
        //禁用csrf保护机制
        http.csrf().disable();
        //禁用cors保护机制
        http.cors().disable();
        //禁用session会话
        http.sessionManagement().disable();
        //禁用form表单登录
        http.formLogin().disable();
        //增加自定义验证过滤器（资源服务需要配置）
        http.addFilter(new JwtVerificationFilter(super.authenticationManager(), prop));
    }
}
```

## 6.7 配置全局异常处理

com.caochenlei.exception.GlobalExceptionHandler

```java
@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(AccessDeniedException.class)
    public Result accessDeniedException() {
        return new Result(403, "用户权限不足！", null);
    }

    @ExceptionHandler(RuntimeException.class)
    public Result serverException() {
        return new Result(500, "服务出现异常！", null);
    }
}
```

## 6.8 订单资源控制器

com.caochenlei.controller.OrderController

```java
@RestController
@RequestMapping("/order")
public class OrderController {
    @Secured({"ROLE_ADMIN","ROLE_ORDER"})
    @RequestMapping("/info")
    public String info() {
        return "Order Controller ...";
    }
}
```

# 七、测试

## 7.1 认证服务测试

![858c29d3d19ab377a8d894264a46ad2a.png](https://b3logfile.com/file/2021/08/858c29d3d19ab377a8d894264a46ad2a-884d2f34.png)

## 7.2 订单资源测试

![d57c1947374d0d4aeea79000727be850.png](https://b3logfile.com/file/2021/08/d57c1947374d0d4aeea79000727be850-d2c0d782.png)

## 7.3 用户状态测试

![9b18b29ffb6b447df1fc9d4f12e8131a.png](https://b3logfile.com/file/2021/08/9b18b29ffb6b447df1fc9d4f12e8131a-13a49aca.png)
![938e7b6787846d02ce45b6a3f2cc789e.png](https://b3logfile.com/file/2021/08/938e7b6787846d02ce45b6a3f2cc789e-4c88d4b2.png)
![851b93513e927a017fba9c176bfe376e.png](https://b3logfile.com/file/2021/08/851b93513e927a017fba9c176bfe376e-89a7fccd.png)
![80624cf417db22c1a90178d0f68347e8.png](https://b3logfile.com/file/2021/08/80624cf417db22c1a90178d0f68347e8-4fe1a7cd.png)
![d32192f0eb9f596ff603492fe3508949.png](https://b3logfile.com/file/2021/08/d32192f0eb9f596ff603492fe3508949-caf8c0bb.png)
![b7e4d66773f1e4a35b49865600d4b880.png](https://b3logfile.com/file/2021/08/b7e4d66773f1e4a35b49865600d4b880-f915e504.png)
![73e6067147594d8f99e39712f1b1b42e.png](https://b3logfile.com/file/2021/08/73e6067147594d8f99e39712f1b1b42e-25049b09.png)

