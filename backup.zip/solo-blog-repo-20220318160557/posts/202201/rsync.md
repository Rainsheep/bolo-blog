title: rsync
date: '2022-01-16 22:01:01'
updated: '2022-01-16 22:01:01'
tags: [bash]
permalink: /articles/2022/01/16/1642341661589.html
---
参考文档：
[集群服务器的同步xsync命令使用](https://blog.51cto.com/u_15119353/3309998)
[xsync同步脚本](https://zhuanlan.zhihu.com/p/377557611)

# 1. 介绍

先介绍 rsync，类似于 scp ，可以将文件发送到别的服务器，效率更高。

```
yum -y install rsync
rsync -rvl 需要同步的文件或目录 目标服务器的用户@主机ip地址:对应主机的位置
```

配置免密操作请参考 [ssh 用户配置](https://www.rainsheep.cn/articles/2021/11/12/1636717848438.html)

# 2. 同步配置至多台服务器

我们在 /usr/loca/bin 目录下自建脚本 xsync.sh

```shell
#!/bin/bash
#1. 判断参数个数
if [ $# -lt 1 ]
then
  echo Not Enough Arguement!
  exit;
fi
#2. 遍历集群所有机器
user=`root`
for host in 主机名1 主机名2 主机名3
do
  echo ====================  $host  ====================
  #3. 遍历所有目录，挨个发送
  for file in $@
  do
    #4 判断文件是否存在
    if [ -e $file ]
    then
      #5. 获取父目录
      pdir=$(cd -P $(dirname $file); pwd)
      #6. 获取当前文件的名称
      fname=$(basename $file)
      ssh $host "mkdir -p $pdir"
      rsync -rvl $pdir/$fname $user@$host:$pdir
    else
      echo $file does not exists!
    fi
  done
done
```



