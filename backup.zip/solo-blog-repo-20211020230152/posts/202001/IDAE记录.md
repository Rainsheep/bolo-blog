title: IDAE记录
date: '2020-01-07 16:19:37'
updated: '2021-06-05 01:06:58'
tags: [软件教程, 知识点总结]
permalink: /articles/2020/01/07/1578385176961.html
---
## 快捷键

参考链接：
[Idea 快捷键大全](https://blog.csdn.net/qq_38963960/article/details/89552704)

| 快捷键                   | 功能                                                             |
| :-------------------------- | :----------------------------------------------------------------- |
| `Ctrl+Y`                    | 删除光标所在行                                              |
| `Ctrl+D`                    | 复制光标所在行，插入光标位置下面                   |
| `Ctrl+/`                    | 单行注释，再按取消注释                                  |
| `Ctrl+Space`                | 基本代码提示                                                 |
| `Ctrl+O`                    | 覆盖重写方法                                                 |
| `Ctrl+P`                    | 方法参数提示                                                 |
| `Ctrl+N`                    | 查找类                                                          |
| `Ctrl+左键`               | 跳转到声明或用法                                           |
| `Ctrl+F12`                  | 显示当前文件的结构                                        |
| `Alt+Enter`                 | 导入包，自动修正代码                                     |
| `Alt+Insert`                | 自动生成代码，toString，get，set 等方法                |
| `Shift+F6`                  | 重命名变量(所有此变量)                                   |
| `Alt+Shift+上下箭头`    | 移动当前代码行                                              |
| `Ctrl+Shift+Space`          | 智能代码提示                                                 |
| `Ctrl+Shift+/`              | 注释选中代码，多行注释，再按取消注释             |
| `Ctrl + Shift + Enter`      | 自动结束代码，行末自动添加分号                      |
| `Ctrl + Alt + O`            | 优化导入的类，可以对当前文件和整个包目录使用 |
| `Ctrl + Alt + 左键`       | 跳转到实现                                                    |
| `Ctrl+Alt+L`                | 格式化代码                                                    |
| `输入/**,回车`          | 生成方法注释                                                 |
| `调试时 alt+click`       | 查看变量                                                       |
| `在方法中 ctrl+shift+T` | 创建测试类                                                    |

## 内存设置

**状态栏显示内存指示器**

mac: 视图 -> 外观 -> 状态栏微件 -> 内存指示器

Windows: 双 shift -> show memory indicator

**修改内存**

通过 idea 修改：

help -> 更改内存设置

通过文件修改：

到 idea 的安装目录的 bin 下，找 idea64.exe.vmoptions 文件
更改参数
　　对应的参数解释：
　　-Xms1024m    设置 IDEA 初时的内存大小，提高 Java 程序的启动速度。
　　-Xmx2048m    设置 IDEA 最大内存数，提高该值，可以减少内存 Garage 收集的频率，提高程序性能。
　　-XX:ReservedCodeCacheSize=512m    保留代码占用的内存容量。

## 背景图片

设置 -> 外观和行为 -> 外观 -> UI 选项 -> 背景图像

## 字体设置

设置 -> 编辑器 -> 字体

字体: JetBrains Mono Variable Italic
大小: 16
行高: 1.2
启用连写(将符号形象话, 如 != 连写为 ≠)

## 注释

**注释在第一列问题**

设置 -> 编辑器 -> 代码样式 -> Java -> 代码生成 -> 注释的代码 -> 取消注释在第一列，勾选添加空格

## Translation

功能：右键翻译

配置：设置 -> 工具 -> 翻译

快捷键： mac(control+command+u)   windows(ctrl+shift+y)

## Rainbow Brackets

功能：彩虹括号

设置：使用默认设置即可

![rainbowbrackets.png](https://b3logfile.com/file/2021/06/image-73d17acd.png)

## CodeGlance

功能：右侧代码地图

![codeglance.png](https://b3logfile.com/file/2021/06/image-2efe8d2b.png)

## Lombok

IDEA 2021 已经内置此插件

参考：[Lombok](https://mp.weixin.qq.com/s?__biz=MzU1Nzg4NjgyMw==&mid=2247488419&idx=1&sn=8fcd89fe0727a5b3fc4179db3aaf9891&scene=21#wechat_redirect)

使用前提：

```xml
<dependency>
     <groupId>org.projectlombok</groupId>
     <artifactId>lombok</artifactId>
     <version>1.18.12</version>
     <scope>provided</scope>
</dependency>
```

File → Settings → Build,Execution,Deployment → Annotation Processors → 勾选 Ennable annotation processing

使用说明：

| 注解              | 说明                                  |
| ------------------- | --------------------------------------- |
| @Getter / Setter    | 生成对应的 get/set 方法          |
| @NonNull            | 标记属性不能为空                |
| @toString           | 重写 toString 方法                  |
| @EqualsAndHashCode  | 给类增加 equals 和 hashCode 方法 |
| @Data               | 集成以上注解                      |
| @NoArgsConstructor  | 生成无参构造方法                |
| @AllArgsConstructor | 生成一个全参数的构造方法    |

## Statistic

功能描述: 统计代码信息，行数大小等

配置: 设置 -> 工具 -> Statistic

## One Dark theme

黑色主题

配置: 设置 -> 外观和行为 -> 外观 -> 主题 -> One Dark Vivid Italic

## Atom Material Icons

功能描述：美化图标

配置：设置 -> 外观和行为 -> Atom Material Icons Settings

![image.png](https://b3logfile.com/file/2021/06/image-ef477869.png)

## JRebel and XRebel for IntelliJ

功能描述：热部署

## Alibaba Java Coding Guidelines

功能描述：代码规范检查

## 禁止 IDEA 双击快捷键

问题：双击 shift 切换输入法的时候，总会打开全局搜索。
解决方法：ctrl+shift+a 弹出搜索框 →输入 registry（自己汉化了的话，搜注册）→找到“ide.suppress.double.click.handler”，将后面的复选框勾上 →点击 Close

## 添加外部工具(命令)

添加 `javap -c` 命令：
File→Settings→Tools→External Tools→左上角 + 号

![](https://b3logfile.com/file/2021/06/solo-fetchupload-2756650097941006967-ff2f3893.png)

编辑窗口右键：

![](https://b3logfile.com/file/2021/06/solo-fetchupload-3140807017255405656-4c8f33e6.png)

## IDEA 中 Project Struction 之 Project 模块介绍

* artifacts：存放 war 包解压以后的标准 Web 结构的代码，里面子文件的名字一般为 （项目名）_war_exploded；
* production：存放 Java 源代码 src 目录下编译以后的字节码文件和 Web 项目的配置文件；
* test：存放 Java 源代码 test 目录下编译以后的字节码文件，即测试代码的字节码文件。这个目录很重要，放置的原则是在项目下，但要和源代码区分开来，并且应该被 Git 等版本管理工具排除掉。

## IDEA 加载不了资源文件

问题描述：当把资源文件复制到 src 目录下的时候，`out\artifacts\login_test_war_exploded\WEB-INF\classes` 目录下没有相应的资源。

解决方法：构建 →重建项目，再启动服务器即可找到资源文件，主要是因为复制进去 IDEA 项目没有配置相关路径的问题，需要重建项目



