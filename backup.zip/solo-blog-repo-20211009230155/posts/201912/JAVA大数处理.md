title: JAVA大数处理
date: '2019-12-03 21:24:00'
updated: '2020-02-10 21:47:12'
tags: [Java]
permalink: /articles/2019/12/03/1575379440940.html
---
Java 中有两个类 BigInteger 和 BigDecimal 分别表示大整数类和大浮点数类。
这两个类都在 java.math.*包中，因此每次必须在开头处引用该包。

基本常量
BigInteger.ONE   1
BigInteger.TEN    10
BigInteger.ZERO  0

BigInteger 转为整型(浮点型类似):
BigInteger x;
int s=x.intValue();
long ss=x.longValue();

常用函数：
valueOf(long x);      将 x 转换为 BigInteger 并返回
add();           相加
subtract();    相减
multiply();    相乘
divide();        相除取整
remainder();   mod();   取余
pow();       次方
gcd();        最大公约
abs();        绝对值
max(); min();   最大最小
compareTo();    返回-1,0,1 小于、等于、大于
equals();    相等
toString(int radix); 转换为radix进制的String

构造函数：
BigInteger(String)     将字符串以十进制方式存储为大数
BigInteger(String val,int radix);   字符串 val 的基数为 radix,例如 val="11"，radix=2，则大数的十进制为 3

不常用函数：
and();  or(); not();  与、或、取反
negate(); 取相反数
toString(int radix);   返回对象的 radix 进制的字符串
BigInteger[] divideAndRemainder(BigInteger val)    用数组返回商和余数
boolean isProbablePrime(BigInteger n)      判断大数是否为素数
nextProbablePrime(BigInteger n)     返回比大数 n 大的为素数的数
modPow(BigInteger n, BigInteger mod) 计算 this^n % mod
shiftLeft(int n) 返回其值为 (this << n) 的 BigInteger
shiftRight(int n)  返回其值为 (this >> n) 的 BigInteger

输入输出
nextBigInteger(radix)； radix 进制形式输入

```java
import java.math.BigInteger;
import java.util.Scanner;
 
public class Main {
	public static void main(String[] args) {
		Scanner cin = new Scanner(System.in);
		while (cin.hasNext()) {
			BigInteger x = cin.nextBigInteger();
			x = x.add(BigInteger.valueOf(10)).subtract(new BigInteger("5"));//x=x+10-5
			System.out.println(x);
			System.out.println(x.toString());
		}
 
	}
}
```
