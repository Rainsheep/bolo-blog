title: es  查询 DSL
date: '2022-02-21 17:38:33'
updated: '2022-02-21 17:38:33'
tags: [es]
permalink: /articles/2022/02/21/1645436313670.html
---
参考文档：
[Elasticsearch: 权威指南](https://www.elastic.co/guide/cn/elasticsearch/guide/current/index.html)

# 1. ES 的数据结构

一个 Elasticsearch 集群可以 包含多个 *索引* (mysql 数据库) ，相应的每个索引可以包含多个 *类型* (mysql 表格) 。 这些不同的类型存储着多个 *文档* (mysql 行)  ，每个文档又有 多个 *属性*  (mysql 列)。

# 2. 查询表达式

## 2.1 match_all

> 查询所有

```json
{
    "query": {
        "match_all": {}
    }
}
```

## 2.2 match

> 分词查询，在匹配时会将 match 条件分词，模糊查询多用 match

无论你在任何字段上进行的是全文搜索还是精确查询，match 查询是你可用的标准查询。

如果你在一个全文字段上使用 match 查询，在执行查询前，它将用正确的分析器去分析查询字符串(分词)：

```json
{ "match": { "tweet": "About Search" }}
```

```json
{
    "query": {
        "match": {
            "tweet": "elasticsearch"
        }
    }
}
```

如果在一个精确值的字段上使用它，例如数字、日期、布尔或者一个 `not_analyzed` 字符串字段，那么它将会精确匹配给定的值：

```json
{ "match": { "age":    26           }}
{ "match": { "date":   "2014-09-01" }}
{ "match": { "public": true         }}
{ "match": { "tag":    "full_text"  }}
```

## 2.3 bool

> 合并多条查询语句，组合多查询中详解

```json
{
    "bool": {
        "must":     { "match": { "tweet": "elasticsearch" }},
        "must_not": { "match": { "name":  "mary" }},
        "should":   { "match": { "tweet": "full text" }},
        "filter":   { "range": { "age" : { "gt" : 30 }} }
    }
}
```

## 2.4 multi_match

`multi_match` 查询可以在多个字段上执行相同的 `match` 查询：

```json
{
    "multi_match": {
        "query":    "full text search",
        "fields":   [ "title", "body" ]
    }
}
```

## 2.5 range

`range` 查询找出那些落在指定区间内的数字或者时间：

```json
{
    "range": {
        "age": {
            "gte":  20,
            "lt":   30
        }
    }
}
```

被允许的操作符如下：

- **`gt`**
  
  大于
- **`gte`**
  
  大于等于
- **`lt`**
  
  小于
- **`lte`**
  
  小于等于

## 2.6 term

`term` 查询被用于精确值匹配，这些精确值可能是数字、时间、布尔或者那些 `not_analyzed` 的字符串：

```json
{ "term": { "age":    26           }}
{ "term": { "date":   "2014-09-01" }}
{ "term": { "public": true         }}
{ "term": { "tag":    "full_text"  }}
```

**`term` 查询对于输入的文本不 *分析* ，所以它将给定的值进行精确查询。**

## 2.7 terms

`terms` 查询和 `term` 查询一样，但它允许你指定多值进行匹配。如果这个字段包含了指定值中的任何一个值，那么这个文档满足条件：

```json
{ "terms": { "tag": [ "search", "full_text", "nosql" ] }}
```

和 `term` 查询一样，`terms` 查询对于输入的文本不分析。它查询那些精确匹配的值（包括在大小写、重音、空格等方面的差异）。

## 2.8 exists 和 missong

`exists` 查询和 `missing` 查询被用于查找那些指定字段中有值 (`exists`) 或无值 (`missing`) 的文档。这与SQL中的 `IS_NULL` (`missing`) 和 `NOT IS_NULL` (`exists`) 在本质上具有共性：

```json
{
    "exists":   {
        "field":    "title"
    }
}
```

## 2.9 constant_score

尽管没有 `bool` 查询使用这么频繁，`constant_score` 查询也是你工具箱里有用的查询工具。它将一个不变的常量评分应用于所有匹配的文档。**它被经常用于你只需要执行一个 filter 而没有其它查询（例如，评分查询）的情况下**。

**可以使用它来取代只有 filter 语句的 `bool` 查询**。在性能上是完全相同的，但对于提高查询简洁性和清晰度有很大帮助。

```json
{
    "constant_score":   {
        "filter": {
            "term": { "category": "ebooks" } 
        }
    }
}
```

## 2.10 match_phrase

match_phrase 会将查询 string 进行分词，当查询某个文档时，要求被查询的文档包含所有输入的分词结果，并要求保持顺序一致，默认要求仅仅相邻(即一样)，slop 控制位置距离。

## 2.11 query_string

和 match_phrase 基本一致，不要求顺序一致。

# 3. 查询和过滤

Elasticsearch 使用的查询语言（DSL）拥有一套查询组件，这些组件可以以无限组合的方式进行搭配。这套组件可以在以下两种情况下使用：过滤情况（filtering context）和查询情况（query context）。

当使用于 *过滤情况* 时，查询被设置成一个“不评分”或者“过滤”查询。即，这个查询只是简单的问一个问题：“这篇文档是否匹配？”。回答也是非常的简单，yes 或者 no ，二者必居其一。

- `created` 时间是否在 `2013` 与 `2014` 这个区间？
- `status` 字段是否包含 `published` 这个单词？
- `lat_lon` 字段表示的位置是否在指定点的 `10km` 范围内？

当使用于 *查询情况* 时，查询就变成了一个“评分”的查询。和不评分的查询类似，也要去判断这个文档是否匹配，同时它还需要判断这个文档匹配的有 *多好*（匹配程度如何）。 此查询的典型用法是用于查找以下文档：

- 查找与 `full text search` 这个词语最佳匹配的文档
- 包含 `run` 这个词，也能匹配 `runs` 、 `running` 、 `jog` 或者 `sprint`
- 包含 `quick` 、 `brown` 和 `fox` 这几个词 — 词之间离的越近，文档相关性越高
- 标有 `lucene` 、 `search` 或者 `java` 标签 — 标签越多，相关性越高

一个评分查询计算每一个文档与此查询的 *相关程度*，同时将这个相关程度分配给表示相关性的字段 `_score`，并且按照相关性对匹配到的文档进行排序。这种相关性的概念是非常适合全文搜索的情况，因为全文搜索几乎没有完全 “正确” 的答案。

> 自 Elasticsearch 问世以来，查询与过滤（queries and filters）就独自成为 Elasticsearch 的组件。但从 Elasticsearch 2.0 开始，过滤（filters）已经从技术上被排除了，同时所有的查询（queries）拥有变成不评分查询的能力。
> 
> 然而，为了明确和简单，我们用 "filter" 这个词表示不评分、只过滤情况下的查询。你可以把 "filter" 、 "filtering query" 和 "non-scoring query" 这几个词视为相同的。
> 
> 相似的，如果单独地不加任何修饰词地使用 "query" 这个词，我们指的是 "scoring query" 。

**性能差异**

过滤查询（Filtering queries）只是简单的检查包含或者排除，这就使得计算起来非常快。考虑到至少有一个过滤查询（filtering query）的结果是 “稀少的”（很少匹配的文档），并且经常使用不评分查询（non-scoring queries），结果会被缓存到内存中以便快速读取，所以有各种各样的手段来优化查询结果。

相反，评分查询（scoring queries）不仅仅要找出匹配的文档，还要计算每个匹配文档的相关性，计算相关性使得它们比不评分查询费力的多。同时，查询结果并不缓存。

多亏倒排索引（inverted index），一个简单的评分查询在匹配少量文档时可能与一个涵盖百万文档的filter表现的一样好，甚至会更好。但是在一般情况下，一个filter 会比一个评分的query性能更优异，并且每次都表现的很稳定。

过滤（filtering）的目标是减少那些需要通过评分查询（scoring queries）进行检查的文档。

**如何选择查询和过滤**

通常的规则是，使用查询（query）语句来进行 *全文* 搜索或者其它任何需要影响 *相关性得分* 的搜索。除此以外的情况都使用过滤（filters)。

# 4. 组合多查询

现实的查询需求从来都没有那么简单；它们需要在多个字段上查询多种多样的文本，并且根据一系列的标准来过滤。为了构建类似的高级查询，你需要一种能够将多查询组合成单一查询的查询方法。

你可以用 `bool` 查询来实现你的需求。这种查询将多查询组合在一起，成为用户自己想要的布尔查询。它接收以下参数：

- **`must`**
  
  文档 *必须* 匹配这些条件才能被包含进来。
- **`must_not`**
  
  文档 *必须不* 匹配这些条件才能被包含进来。
- **`should`**
  
  如果满足这些语句中的任意语句，将增加 `_score` ，否则，无任何影响。它们主要用于修正每个文档的相关性得分。
- **`filter`**
  
  *必须* 匹配，但它以不评分、过滤模式来进行。这些语句对评分没有贡献，只是根据过滤标准来排除或包含文档。并且自动缓存常用的 filter,效率高。

由于这是我们看到的第一个包含多个查询的查询，所以有必要讨论一下相关性得分是如何组合的。每一个子查询都独自地计算文档的相关性得分。一旦他们的得分被计算出来， `bool` 查询就将这些得分进行合并并且返回一个代表整个布尔操作的得分。

下面的查询用于查找 `title` 字段匹配 `how to make millions` 并且不被标识为 `spam` 的文档。那些被标识为 `starred` 或在2014之后的文档，将比另外那些文档拥有更高的排名。如果 *两者* 都满足，那么它排名将更高：

```json
{
    "bool": {
        "must":     { "match": { "title": "how to make millions" }},
        "must_not": { "match": { "tag":   "spam" }},
        "should": [
            { "match": { "tag": "starred" }},
            { "range": { "date": { "gte": "2014-01-01" }}}
        ]
    }
}
```

# 5. match 和 term

* term 精确查找，不分词
* match 模糊查找，分词

举个例子，两条数据

```json
{"name":"cherry word"}
{"name":"hello word"}
```

```json
{
    "match":{
        "name":"hello word"
    }
}
```

* 分词查询，得到两条结果，_score 不同

```json
{
    "term":{
        "name":"word"
    }
}
```

* 得到两条结果，_score 相同

```json
{
    "term":{
        "name":"hello word"
    }
}
```

* 得到 0 条结果，因为 term 不分词，但 doc 被分词了

