title: Cloudreve 搭建私有云
date: '2020-08-17 22:57:18'
updated: '2020-08-17 22:57:18'
tags: [Cloudreve, 个人网盘]
permalink: /articles/2020/08/17/1597676238116.html
---
参考：

[https://github.com/cloudreve/Cloudreve](https://github.com/cloudreve/Cloudreve)

[https://docs.cloudreve.org/](https://docs.cloudreve.org/)

### 1. 下载

[下载地址](https://github.com/cloudreve/Cloudreve/releases) linux下载amd

### 2. 运行

```
# 解压程序包
tar -zxvf cloudreve_VERSION_OS_ARCH.tar.gz

# 赋予执行权限
chmod +x ./cloudreve

# 启动 Cloudreve
./cloudreve
```

Cloudreve 在首次启动时，会创建初始管理员账号，请注意保管管理员密码，此密码只会在首次启动时出现。如果您忘记初始管理员密码，需要删除同级目录下的 `cloudreve.db`，重新启动主程序以初始化新的管理员账户。

Cloudreve 默认会监听 `5212`端口。你可以在浏览器中访问 `http://服务器IP:5212`进入 Cloudreve。

以上步骤操作完后，最简单的部署就完成了。你可能需要一些更为具体的配置，才能让Cloudreve更好的工作，具体流程请参考下面的配置流程。

### 3. 反向代理

nginx 配置文件加入以下字段

```
location / {
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header Host $http_host;
    proxy_redirect off;
    proxy_pass http://127.0.0.1:5212;
  
    # 如果您要使用本地存储策略，请将下一行注释符删除，并更改大小为理论最大文件尺寸
    # client_max_body_size 20000m;
}
```

### 4. 进程守护

```
# 编辑配置文件
vim /usr/lib/systemd/system/cloudreve.service
```

将下文 `PATH_TO_CLOUDREVE` 更换为程序所在目录：

```
[Unit]
Description=Cloudreve
Documentation=https://docs.cloudreve.org
After=network.target
Wants=network.target

[Service]
WorkingDirectory=/PATH_TO_CLOUDREVE
ExecStart=/PATH_TO_CLOUDREVE/cloudreve
Restart=on-abnormal
RestartSec=5s
KillMode=mixed

StandardOutput=null
StandardError=syslog

[Install]
WantedBy=multi-user.target
```

```
# 更新配置
systemctl daemon-reload

# 启动服务
systemctl start cloudreve

# 设置开机启动
systemctl enable cloudreve
```

### 5. 管理命令

```
# 启动服务
systemctl start cloudreve

# 停止服务
systemctl stop cloudreve

# 重启服务
systemctl restart cloudreve

# 查看状态
systemctl status cloudreve
```
