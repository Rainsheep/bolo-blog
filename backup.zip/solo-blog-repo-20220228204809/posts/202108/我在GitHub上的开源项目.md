title: 我在 GitHub 上的开源项目
date: '2021-08-15 21:36:11'
updated: '2021-08-15 21:36:11'
tags: [开源, GitHub]
permalink: /github
---
![GitHub Repo](https://www.rainsheep.cn/images/github_repo.jpg)

### 1. [community](https://github.com/Rainsheep/community) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`1`](https://github.com/Rainsheep/community/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Rainsheep/community/network/members "分叉数")</span>

毕设项目，社团活动管理系统



---

### 2. [heima-travel](https://github.com/Rainsheep/heima-travel) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`1`](https://github.com/Rainsheep/heima-travel/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Rainsheep/heima-travel/network/members "分叉数")</span>

黑马旅游网



---

### 3. [acme.sh](https://github.com/Rainsheep/acme.sh) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/Rainsheep/acme.sh/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Rainsheep/acme.sh/network/members "分叉数")&nbsp;&nbsp;[🏠`https://acme.sh`](https://acme.sh "项目主页")</span>

A pure Unix shell script implementing ACME client protocol



---

### 4. [authority-management](https://github.com/Rainsheep/authority-management) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/Rainsheep/authority-management/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Rainsheep/authority-management/network/members "分叉数")</span>

权限管理系统



---

### 5. [bolo-blog](https://github.com/Rainsheep/bolo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/Rainsheep/bolo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Rainsheep/bolo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`https://www.rainsheep.cn`](https://www.rainsheep.cn "项目主页")</span>

✍️ 雨羊的个人博客 - 咸鱼不配拥有梦想



---

### 6. [homebrew-brew](https://github.com/Rainsheep/homebrew-brew) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/Rainsheep/homebrew-brew/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Rainsheep/homebrew-brew/network/members "分叉数")</span>





---

### 7. [homebrew-services](https://github.com/Rainsheep/homebrew-services) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/Rainsheep/homebrew-services/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Rainsheep/homebrew-services/network/members "分叉数")</span>

🚀 Manage background services with macOS' launchctl daemon manager



---

### 8. [pic-bed](https://github.com/Rainsheep/pic-bed) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/Rainsheep/pic-bed/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Rainsheep/pic-bed/network/members "分叉数")</span>

雨羊的github图床



---

### 9. [Rainsheep.github.io](https://github.com/Rainsheep/Rainsheep.github.io) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/Rainsheep/Rainsheep.github.io/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Rainsheep/Rainsheep.github.io/network/members "分叉数")&nbsp;&nbsp;[🏠`https://rainsheep.github.io/`](https://rainsheep.github.io/ "项目主页")</span>

博客的静态站点



---

### 10. [solo-blog](https://github.com/Rainsheep/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/Rainsheep/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Rainsheep/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`https://www.rainsheep.cn`](https://www.rainsheep.cn "项目主页")</span>

✍️ 雨羊的个人博客 - 咸鱼不配拥有梦想



---

### 11. [vue-mall](https://github.com/Rainsheep/vue-mall) <kbd title="主要编程语言">Vue</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/Rainsheep/vue-mall/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Rainsheep/vue-mall/network/members "分叉数")</span>



