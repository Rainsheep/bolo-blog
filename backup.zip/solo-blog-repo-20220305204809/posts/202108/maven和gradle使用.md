title: maven 和 gradle 使用
date: '2021-08-06 01:50:15'
updated: '2021-08-06 10:22:52'
tags: [maven, gradle]
permalink: /articles/2021/08/06/1628185814836.html
---
背景：很多时候我们构建项目的时候，jar 包死活下不下来。。。

这时候可能需要我们手动去网站下载后安装到本地。

## Maven

maven 手动安装第三方库

参考文档：[Installing an artifact with a custom POM](http://maven.apache.org/plugins/maven-install-plugin/examples/custom-pom-installation.html)

```
mvn install:install-file -Dfile=path-to-your-artifact-jar -DpomFile=path-to-pom
// 或者指定版本
mvn org.apache.maven.plugins:maven-install-plugin:3.0.0-M1:install-file -Dfile=path-to-your-artifact-jar -DpomFile=path-to-pom
```

如果 jar 包是通过 maven 方式构建的，则我们可以省去 -DpomFile

> 但很遗憾的是，虽然能将 jar 和 pom 安装到本地库，但无法安装 pom 中的依赖，适用于仅此 jar 包下载不下来的情况，所依赖的 jar 还通过 idea maven 去自动下载。

## Gradle

gradle 没有找到手动安装第三方库的方法，但是 gradle 可以直接使用 maven 的库！

```
repositories {
    mavenLocal() // 直接使用本地 maven 仓库 
}
```

> 使用 mavenLocal() 时 Gradle 默认会按以下顺序去查找本地的 maven 仓库：
> 
> USER_HOME/.m2/settings.xml  >>  M2_HOME/conf/settings.xml  >>  USER_HOME/.m2/repository。
> 
> 注意，环境变量要加入 M2_HOME， 我们配环境时很多时候都是使用 MAVEN_HOME 或者直接在 path 中输入 bin 路径了，导致 mavenLocal 无法生效。

**maven 的环境变量名为 M2_HOME**

**gradle 的环境变量名问 GRADLE_USER_HOME**

## 安装位置

idea 中 maven 的默认安装位置 `～/.m2/wrapper/dists`，默认仓库位置  `~/.m2/repository`

android studio 中 gradle 的默认安装位置 `～/.gradle/wrapper/dists`，默认仓库位置 `~/.gradle/caches/modules-2/files-2.1`



