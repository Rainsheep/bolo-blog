title: 挖矿病毒kdevtmpfsi
date: '2020-03-24 17:36:24'
updated: '2020-03-24 18:24:26'
tags: [Linux]
permalink: /articles/2020/03/24/1585042584843.html
---
服务器中病毒了，top 发现 kdevtmpfsi 进程跑了 CPU 的 90+%。

解决方法：

1. 防火墙关闭非必要端口
2. `ps -aux | grep kinsing` 此进程为守护进程，记录 PID
3. `ps -aux | grep kdevtmpfsi` 记录 PID
4. `find / -name kdevtmpfsi` 进程文件，删除
5. `find / -name kinsing` 进程文件，删除
6. `kill -9 PID` 杀死两个进程
7. `crontab -l` 查看定时任务
8. `crontab -e` 删除定时任务
9. 清除 `/root/.ssh/` 下的公钥文件，`rm -f authorized_keys`
