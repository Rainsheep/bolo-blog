title: AS 使用 gradle
date: '2021-11-17 14:18:48'
updated: '2021-11-17 14:18:48'
tags: [android]
permalink: /articles/2021/11/17/1637129928168.html
---
参考文献：
[Gradle 配置 环境变量 ](https://www.cnblogs.com/baiqiantao/p/6890674.html#%E7%8E%AF%E5%A2%83%E5%8F%98%E9%87%8F-gradle_home)

[（Gradle笔记）win10+Gradle7.1.1安装和配置(aliyun全局)](https://blog.csdn.net/qq_39038178/article/details/118896980)

# 1. 概念

## 1.1 GRADLE_HOME

`GRADLE_HOME`指的是你需要配置的`环境变量`，此环境变量仅用于添加到`Path`中，添加到`Path`之后，在任意目录中都可以执行`gradle`命令。

![image-20211117140542257](https://oss.rainsheep.cn/blog/image-20211117140542257-1637129142-dc4.png)

## 1.2 GRADLE_USER_HOME

`GRADLE_USER_HOME`指的是你需要配置的`环境变量`，在命令行中输入的以`gradlew`的开头的命令时，会使用此环境变量所指定的位置来存放下载的`gradle`。下载的`gradle`版本由项目中的`project/gradle/wrapper/gradle-wrapper.properties`决定。

![20201202213501](https://oss.rainsheep.cn/blog/20201202213501-1637129014-805.png)

```
#Mon Nov 16 00:55:48 CST 2020
distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
distributionUrl=https\://services.gradle.org/distributions/gradle-6.5-all.zip
```

注意：必须是`gradlew`开头的命令，不能是`gradle`开头的命令

- `gradle`开头的命令说明你想使用的是配置在环境变量`GRADLE_HOME`当中的`\bin\gradle`
- `gradlew`开头的命令说明你想使用的是`gradle wrapper`(单词的含义为`gradle`+`w`)

![image-20211117140716587](https://oss.rainsheep.cn/blog/image-20211117140716587-1637129236-af4.png)

> 注意：`GRADLE_USER_HOME`不要指向你在本地自己下载解压的`gradle`。

## 1.3 AS 的 Gradle user home

`Gradle user home` 指的是 AS 中关于 gradle 的配置，该配置只是给 AS 使用的。

当你在 AS 中点击 gradle 相关的`图形按钮`时会使用`Gradle user home`指定的目录下载`project/gradle/wrapper/gradle-wrapper.properties`指定的gradle版本。

简言之：在 AS 中的各种图形化操作都是使用这个目录去保存下载的gradle。

> 注意：`Gradle user home`不要指向你在本地自己下载解压的`gradle`。

## 1.4 Use from gradle

`Use gradle from`也是 AS 中关于gradle的配置，该配置同样也只是给 AS 使用的：

- 当`Use gradle from`的值勾选`gradle-wrapper.properties`时，`AS`使用`gradle-wrapper.properties`指定的gradle版本。
- 当`Use gradle from`的值勾选`Specified location`时，`AS`使用指定目录下的gradle版本。

![image-20211117141042178](https://oss.rainsheep.cn/blog/image-20211117141042178-1637129442-8d4.png)

> 勾选`Specified location`时，`gradlew`命令所使用的`gradle`版本仍由`gradle-wrapper.properties`决定。

和`Gradle user home`的区别在于：

- `Gradle user home`是针对所有project统一设置的`gradle`下载路径
- `Use gradle from`是让当前project使用本地指定路径下载好的`gradle`版本

如果嫌`gradle`下载慢，就可以勾选`Specified location`使用指定本地下载好的`gradle`版本，这样瞬间就构建完成了。

# 2. gradle 配置

## 2.1 环境变量配置

```bash
# gradle
export GRADLE_HOME=/Users/rainsheep/software/gradle
export GRADLE_USER_HOME=/Users/rainsheep/.gradle
export PATH=$GRADLE_HOME/gradle-7.1.1/bin:$PATH
```

## 2.2 全局配置阿里云仓库

在Gradle本地仓库 `.gradle` 目录下新建文件名为：`init.gradle`

```
allprojects{
    repositories {
        def ALIYUN_REPOSITORY_URL = 'https://maven.aliyun.com/repository/public/'
        def ALIYUN_JCENTER_URL = 'https://maven.aliyun.com/repository/jcenter/'
        def ALIYUN_GOOGLE_URL = 'https://maven.aliyun.com/repository/google/'
        def ALIYUN_GRADLE_PLUGIN_URL = 'https://maven.aliyun.com/repository/gradle-plugin/'
        all { ArtifactRepository repo ->
            if(repo instanceof MavenArtifactRepository){
                def url = repo.url.toString()
                if (url.startsWith('https://repo1.maven.org/maven2/')) {
                    project.logger.lifecycle "Repository ${repo.url} replaced by $ALIYUN_REPOSITORY_URL."
                    remove repo
                }
                if (url.startsWith('https://jcenter.bintray.com/')) {
                    project.logger.lifecycle "Repository ${repo.url} replaced by $ALIYUN_JCENTER_URL."
                    remove repo
                }
                if (url.startsWith('https://dl.google.com/dl/android/maven2/')) {
                    project.logger.lifecycle "Repository ${repo.url} replaced by $ALIYUN_GOOGLE_URL."
                    remove repo
                }
                if (url.startsWith('https://plugins.gradle.org/m2/')) {
                    project.logger.lifecycle "Repository ${repo.url} replaced by $ALIYUN_GRADLE_PLUGIN_URL."
                    remove repo
                }
            }
        }
        maven { url ALIYUN_REPOSITORY_URL }
        maven { url ALIYUN_JCENTER_URL }
        maven { url ALIYUN_GOOGLE_URL }
        maven { url ALIYUN_GRADLE_PLUGIN_URL }
    }
}
```

## 2.3 AS 配置

![20210720000153526](https://oss.rainsheep.cn/blog/20210720000153526-1637129862-fc6.png)

出现如下，表示成功

![20210720005748320](https://oss.rainsheep.cn/blog/20210720005748320-1637129894-576.png)

