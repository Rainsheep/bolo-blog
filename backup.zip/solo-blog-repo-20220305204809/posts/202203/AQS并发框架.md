title: AQS 并发框架
date: '2022-03-05 17:05:43'
updated: '2022-03-05 17:05:43'
tags: [java, 多线程]
permalink: /articles/2022/03/05/1646471143500.html
---
参考文档：[深入理解Java并发框架AQS系列（二）：AQS框架简介及锁概念](https://www.cnblogs.com/xijiu/p/14522224.html)

# 1. AQS 框架和概念

## 1.1 思考

我们去学习一个知识点或开启一个新课题时，最好是带着问题去学习，这样针对性比较强，且印象比较深刻，主动思考带给我们带来了无穷的好处

抛开AQS，设想以下问题：

- Q：如果我们遇到 thread 无法获取所需资源时，该如何操作？
- A：不断重试呗，一旦资源释放可快速尝试获取
- Q：那如果资源持有时长较长，不断循环获取，是否比较浪费CPU ？
- A：的确，那就让线程休息1秒钟，再尝试获取，这样就不会导致CPU空转了
- Q：那如果资源在第0.1秒时被释放，那线程岂不是要白白等待0.9秒了 ？
- A：实在不行就让当前线程挂起，等释放资源的线程去通知当前线程，这样就不存在等待时间长短的问题了
- Q：但如果资源持有时间很短，每次都挂起、唤醒线程成为了一个很大的开销
- A：那就依情况而定，lock时间短的，就不断循环重试，时间长的就挂起
- Q：如何界定lock的时间长短？还有就是如果lock的时间不固定，也无法预期呢？
- A：唔。。。这是个问题
- Q：如果线程等待期间，我想放弃呢？
- A：。。。。。。
- Q：还有很多问题
  
  - 如果我想动态增加资源呢？
  - 如何我不想产生饥饿，而保证加锁的有序性呢？
  - 或者我要支持/不支持可重入特性呢？
  - 我要查看所有等待资源的线程状态呢？
  - 。。。。。。

我们发现，一个简单的等待资源的问题，牵扯出后续诸多庞杂且无头绪的问题；加锁不仅依赖一套完善的框架体系，还要具体根据使用场景而定，才能接近最优解；那我们即将要引出的AQS能完美解决上述这些问题吗？

答案是肯定的：不能

其实 Doug Lea 也意识到问题的复杂性，不可能出一个超级工具来解决所有问题，所以他把 AQS 设计为一个 abstract 类，并提供一系列子类去解决不同场景的问题，例如 `ReentrantLock`、`Semaphore` 等；当我们发现这些子类也不能满足我们加锁需求时，我们可以定义自己的子类，通过重写两三个方法，寥寥几行代码，实现强大的功能，这一切都得益于 AQS 作者敏锐的前瞻性

指的一提的是，虽然我们可以用某个子类去实现另一个子类所提供的功能（例如使用 `Semaphore` 替代 `CountDownLatch`），但其易用、简洁、高效性等能否达到理想效果，都值得商榷；就好比在陆地上穿着雪橇走路，虽能前进，却低效易摔跤

## 1.2 并发框架

AQS 是什么，AbstractQueuedSynchronizer 类如其名，抽象的队列式的同步器，AQS 定义了一套多线程访问共享资源的同步器框架，许多同步类实现都依赖于它，如常用的 ReentrantLock/Semaphore/CountDownLatch。

它维护了一个 volatile int state（代表共享资源）和一个 FIFO 线程等待队列（多线程争用资源被阻塞时会进入此队列）。state 的访问方式有三种:

* getState()
* setState()
* compareAndSetState()

本小节仅带大家对AQS架构有个初步了解，在后文的独占锁、共享锁等中会详细阐述。下图为AQS框架的主体结构

![2109301-20210312100329988-1019373521](https://oss.rainsheep.cn/blog/2109301-20210312100329988-1019373521-1646460015-4ea.png)

从上图中我们看到了 AQS 中非常关键的一个概念：“阻塞队列”。即 AQS 的理念是当线程无法获取资源时，提供一个 FIFO 类型的有序队列，用来维护所有处于“等待中”的线程。看似无解可击的框架设计，同时也牵出另外的一个问题：阻塞队列一定高效吗?

当“同步块逻辑”执行很快时，我们列出两种场景

- 场景1：直接使用 AQS 框架，例如试用其子类 `ReentrantLock`，遇到资源争抢，放阻塞队列
- 场景2：因为锁占用时间短，无限重试

针对这2种场景，我们写测试用例比较一下

```java
package com.example.springboottest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.AbstractQueuedSynchronizer;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @author likangning
 * @since 2021/3/9 上午8:58
 */
@SpringBootTest
public class CompareTest {

  // 自己实现 AQS 框架，使用无限重试的方式，
  private class MyReentrantLock extends AbstractQueuedSynchronizer {
    // 参数是个状态标记，可以自定义，可参考可重入锁
    protected final boolean tryAcquire(int acquires) {
      final Thread current = Thread.currentThread();
      while (true) {
        int c = getState();
        if (c == 0) {
          // 原子操作
          if (compareAndSetState(0, acquires)) {
            setExclusiveOwnerThread(current);
            return true;
          }
        }
      }
    }

    // 参数要与锁定的时候的 acquires 相同
    protected final boolean tryRelease(int releases) {
      int c = getState() - releases;
      if (Thread.currentThread() != getExclusiveOwnerThread())
        throw new IllegalMonitorStateException();
      boolean free = false;
      if (c == 0) {
        free = true;
        setExclusiveOwnerThread(null);
      }
      // 原子操作
      setState(c);
      return free;
    }
  }

  /**
   * 使用实现 AQS 框架的 ReentrantLock
   */
  @Test
  public void test1() throws InterruptedException {
    ReentrantLock reentrantLock = new ReentrantLock();
    long begin = System.currentTimeMillis();
    ExecutorService executorService = Executors.newCachedThreadPool();
    for (int i = 0; i < 2; i++) {
      executorService.submit(() -> {
        for (int j = 0; j < 50000000; j++) {
          reentrantLock.lock();
          doBusiness();
          reentrantLock.unlock();
        }
      });
    }
    executorService.shutdown();
    // 堵塞，直到线程池运行完毕
    executorService.awaitTermination(Long.MAX_VALUE, TimeUnit.MILLISECONDS);
    System.out.println("ReentrantLock cost : " + (System.currentTimeMillis() - begin));
  }

  /**
   * 无限重试
   */
  @Test
  public void test2() throws InterruptedException {
    MyReentrantLock myReentrantLock = new MyReentrantLock();
    long begin = System.currentTimeMillis();
    ExecutorService executorService = Executors.newCachedThreadPool();
    for (int i = 0; i < 2; i++) {
      executorService.submit(() -> {
        for (int j = 0; j < 50000000; j++) {
          myReentrantLock.tryAcquire(1);
          doBusiness();
          myReentrantLock.tryRelease(1);
        }
      });
    }
    executorService.shutdown();
    // 堵塞，直到线程池运行完毕
    executorService.awaitTermination(Long.MAX_VALUE, TimeUnit.MILLISECONDS);
    System.out.println("MyReentrantLock cost : " + (System.currentTimeMillis() - begin));
  }

  private void doBusiness() {
    // 空实现，模拟程序快速运行
  }
}
```

上例，虽然`MyReentrantLock`继承了`AbstractQueuedSynchronizer`，但没有使用其阻塞队列。我们每种情况跑5次，看下两者在耗时层面的表现

|        类         | 耗时1 | 耗时2 | 耗时3 | 耗时4 | 耗时5 | 平均耗时（ms） |
| :---------------: | :---- | :---- | :---- | :---- | :---- | :------------- |
|  `ReentrantLock`  | 11425 | 12301 | 12289 | 10262 | 11461 | 11548          |
| `MyReentrantLock` | 8717  | 8957  | 10283 | 8445  | 8928  | 9066           |

上例只是拿独占锁举例，共享锁也同理。可以简单概括为：线程挂起、唤醒的时间占整个加锁周期比重较大，导致每次挂起、唤醒已经成为一种负担。当然此处并不是说 AQS 设计有什么缺陷，只是想表达并没有一种万能的框架能应对所有情况，一切都要靠使用者灵活理解、应用。

## 1.3 类结构及如何使用

AQS 类内部结构

![2109301-20210315110701067-122196209](https://oss.rainsheep.cn/blog/2109301-20210315110701067-122196209-1646470465-ac7.png)

因后文还会反复涉及，此处仅罗列2点

- `private volatile int state` 重要属性，一般不论是实现独占锁还是共享锁，都要进行 CAS 操作的字段。独占锁时，如果通过 cas 将其从 0 改变为 1 的话，那么标记加锁成功；而在共享锁时，则表示支持并发数的最大值。
- `isHeldExclusively()` 标记是否持有线程：AQS虽然为抽象类，但其继承了类AbstractOwnableSynchronizer，用来标记加锁线程，但AQS本身不依赖这个属性，也不会设置这个属性，实现类如果需要可以直接重新此方法。一般实现可重入特性需要重写该方法

而我们常用的锁并发类，基本上都是AQS的子类或通过组合方式实现，可见AQS在Java并发体系的重要性

![2109301-20210312100356854-1934745395](https://oss.rainsheep.cn/blog/2109301-20210312100356854-1934745395-1646470772-37f.png)

至于如何使用，是需要区分子类是想实现独占锁还是共享锁

- 独占锁
  - `tryAcquire()`
  - `tryRelease()`
  - `isHeldExclusively()` -- 可不实现
- 共享锁
  - `tryAcquireShared()`
  - `tryReleaseShared()`

AQS 本身是一个 abstract 类，将主要并发逻辑进行了封装，我们定义自己的并发控制类，仅需要实现其中的两三个方法即可。而在对外( public 方法)表现形式上，可依据自己的业务特性来定义；例如 Semaphore 定义为 acquire、 release，而 ReentrantLock 定义为 lock 、unlock

# 2. 独占锁

# 3. 共享锁

# 4. 条件队列



