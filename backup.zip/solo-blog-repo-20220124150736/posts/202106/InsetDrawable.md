title: InsetDrawable
date: '2021-06-27 11:26:47'
updated: '2021-06-27 11:26:47'
tags: [android]
permalink: /articles/2021/06/27/1624764407357.html
---
## 1. 介绍

表示把一个 Drawable 嵌入到另外一个 Drawable 的内部，并且在内部留一些间距, 类似与 Drawable 的 padding 属性,但 padding 表示的是 Drawable 的内容与 Drawable 本身的边距! 而 InsetDrawable 表示的是两个 Drawable 与容器之间的边距, 当控件需要的背景比实际的边框 小的时候, 比较适合使用 InsetDrawable ,比如使用这个可以解决我们自定义 Dialog 与屏幕之间 的一个间距问题,相信做过的朋友都知道,即使我们设置了 layout_margin 的话也是没用的,这个时候就可以用到这个 InsetDrawable 了!只需为 InsetDrawable 设置一个 insetXxx 设置不同 方向的边距,然后为设置为 Dialog 的背景即可！

相关属性如下：

- drawable: 引用的 Drawable, 如果为空,必须有一个 Drawable 类型的子节点!
- visible: 初始可见状态
- insetLeft, insetRight, insetTop, insetBottm: 设置左右上下的边距

**xml 实现**

xml 定义 InsetDrawable, test.xml

```xml
<?xml version="1.0" encoding="utf-8"?>  
<inset xmlns:android="http://schemas.android.com/apk/res/android"  
    android:drawable="@drawable/test1"  
    android:insetBottom="10dp"  
    android:insetLeft="10dp"  
    android:insetRight="10dp"  
    android:insetTop="10dp" />
```

Activity_main.xml

```xml
<ImageView
    android:id="@+id/image_view"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="@drawable/test" />
```

**Java 实现**

```java
imageView.setBackground(bitmapDrawable);
```

**效果图**

![22768448.png](https://b3logfile.com/file/2021/06/22768448-7f9a5aeb.png)



