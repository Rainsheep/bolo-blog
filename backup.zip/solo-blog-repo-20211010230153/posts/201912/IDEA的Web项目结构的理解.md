title: IDEA的Web项目结构的理解
date: '2019-12-04 14:13:32'
updated: '2019-12-04 14:13:32'
tags: [软件教程]
permalink: /articles/2019/12/04/1575440012847.html
---
[参考链接](https://www.cnblogs.com/deng-cc/p/6416332.html)
