title: yml 语法
date: '2021-01-24 23:20:04'
updated: '2022-01-20 17:45:50'
tags: [yml]
permalink: /articles/2021/01/24/1611501604296.html
---
参考文档：
[yaml文件的 锚点& 与 引用*](https://blog.csdn.net/weixin_42252770/article/details/99705112)
[Yaml语法使用](https://www.cnblogs.com/yxfeng/p/10396288.html)

yml 或者 yaml 结尾的文件

## 1. 配置普通数据

* 语法：`key: value`
* 实例代码
  
  ```
  name: zhangsan
  ```
  
  > value 之前必须有一个空格

## 2. 配置对象数据

* 用缩进代表分级
* key 前面的空格个数不限定，在 yml 语法中，相同缩进代表同一个级别
* 实例代码
  
  ```yaml
  person: 
    name: haohao 
    age: 31 
    addr: beijing
  
  #或者（不常用）
  person: {name: haohao,age: 31,addr: beijing}
  ```

## 3. 配置 Map 数据

```yaml
map:
  key1: value1
  key2: value2
```

## 4. 配置数组数据 (List、Set)

* `- ` 代表一个数组元素
* value 与 `-` 之间有一个空格

```yaml
city:
  - beijing
  - tianjin
  - chongqing
  - shanghai
  
# 或者（不常用）
city: [beijing,tianjin,chongqing,shanghai]
```

当数组元素是对象的时候

```yaml
student:
  - name: tom
    age: 18
    addr: beijing
  - name: lucy
    age: 17
    addr: tianjin
    
# 或者（不常用）
student: [{name: tom,age: 18,addr: beijing},{name: lucy,age: 17,addr: tianjin}]
```

## 5. 锚点

> 当 yml 文件中出现多个重复内容时，可以通过 锚点 &  与引用 * ，实现引用锚点处内容的功能，从而在修改时，只需要修改锚点处的内容，即可在所有引用处生效

& 设置锚点的名称，`<<`表示“将给定的哈希合并到当前的哈希”， `*` 引用锚点的内容。

我们想实现

```yaml
user:
	host: 127.0.0.1
	db: 8
	
book:
	host: 127.0.0.1
	db: 9
	
comment:
	host: 127.0.0.1
	db: 10
```

有以下两种优化方式

**通过 <<**

```yaml
localhost: &localhost1
	host: 127.0.0.1
user:
	<<: *localhost1
	db: 8
	
book:
	<<: *localhost1
	db: 9
	
comment:
	<<: *localhost1
	db: 10
```

**不通过 <<**

```yaml
localhost: 
	host: &hostname 127.0.0.1
user:
	host: *hostname
	db: 8
	
book:
	host: *hostname
	db: 9
	
comment:
	host: *hostname
	db: 10
```

## 6. 复杂的键

**问号+空格** 表示复杂的键。当键是一个列表或键值表时，就需要使用本符号来标记

```
# 使用一个列表作为键
 ? [blue, reg, green]: Color
 # 等价于
 ? - blue
   - reg
   - gree
 : Color
```

## 7. 文本块

**使用 “|” 和文本内容缩进表示的块：保留块中已有的回车换行。相当于段落块**

```yaml
yaml: |
   JSON的语法其实是YAML的子集，大部分的JSON文件都可以被YAML的解释器解释。
   如果你想更深入的学习YAML，我建议你去 http://www.yaml.org 看看
```

**使用 “>” 和文本内容缩进表示的块：将块中回车替换为空格，最终连接成一行**

```yaml
# 可以使用空行来分段落
yaml: >
   JSON的语法其实是YAML的子集，
   大部分的JSON文件都可以被YAML的解释器解释。
```

**使用定界符“”（双引号）、‘’（单引号）或回车表示的块：最终表示成一行**

```yaml
yaml:     # 使用回车的多行，最终连接成一行。
   JSON的语法其实是YAML的子集，
   大部分的JSON文件都可以被YAML的解释器解释。
yaml:     # 使用了双引号，双引号的好处是可以转义，即在里面可以使用特殊符号
   "JSON的语法其实是YAML的子集，
   大部分的JSON文件都可以被YAML的解释器解释。"
```

**当数据中含有空格或任意特殊字符，需要使用引号来包裹任何包含冒号的哈希值,**

```yaml
foo: "somebody said I should put a colon here: so I did"   # 然后这个冒号将会被结尾.
```

## 8. 类型

```yaml
integer: 12345     # 整数标准形式
octal: 0o34        # 八进制表示，第二个是字母 o
hex: 0xFF          # 十六进制表示

float: 1.23e+3     # 浮点数
fixed: 13.67       # 固定小数
minmin: -.inf      # 表示负无穷
notNumber: .NaN    # 无效数字

null:              # 空值
boolean: [true, false] # 布尔值
string: ‘12345‘    # 字符串

date: 2015-08-23   # 日期
datetime: 2015-08-23T02:02:00.1z  # 日期时间
iso8601: 2015-08-23t21:59:43.10-05:00  # iso8601 日期格式
spaced: 2015-08-23 21:59:43.10 -5      # ?
```

**显式指定类型**

“!”（叹号）显式指示类型，或自定义类型标识。单叹号通常是自定义类型，双叹号是内置类型，例如：

```yaml
#下面是内置类型
!!int               # 整数类型
!!float             # 浮点类型
!!bool              # 布尔类型
!!str               # 字符串类型
!!binary            # 也是字符串类型
!!timestamp         # 日期时间类型
!!null              # 空值
!!set               # 集合
!!omap, !!pairs     # 键值列表或对象列表
!!seq               # 序列，也是列表
!!map               # 键值表
```



