title: maven profile
date: '2021-12-30 18:47:27'
updated: '2021-12-31 10:21:53'
tags: [java, maven]
permalink: /articles/2021/12/30/1640861247161.html
---
参考文档：
[maven（三）最详细的profile的使用](https://blog.csdn.net/java_collect/article/details/83870215)
[maven profile动态选择配置文件](https://www.cnblogs.com/0201zcr/p/6262762.html)

# 1. 前言

在开发过程中，我们的项目会存在不同的运行环境，比如开发环境、测试环境、生产环境，而我们的项目在不同的环境中，有的配置可能会不一样，比如数据源配置、日志文件配置、以及一些软件运行过程中的基本配置，那每次我们将软件部署到不同的环境时，都需要修改相应的配置文件，这样来回修改，很容易出错，而且浪费劳动力。

在前面的文章[springboot 多个配置文件](https://www.rainsheep.cn/articles/2021/12/30/1640862154579.html)，springboot 为我们提供了一种解决方案，而 maven 也提供了一种更加灵活的解决方案，就是 profile 功能。

# 2. 原理

## 2.1 profile 定义

先看一段 pom 文件中的 profile 定义

```xml
<profiles>
    <profile>
        <!--不同环境Profile的唯一id-->
        <id>dev</id>
        <properties>
            <!--profiles.active是自定义的字段（名字随便起），自定义字段可以有多个-->
            <profiles.active>dev</profiles.active>
        </properties>
    </profile>
    <profile>
        <id>prod</id>
        <properties>
            <profiles.active>prod</profiles.active>
        </properties>
        <activation>
            <activeByDefault>true</activeByDefault>
        </activation>
    </profile>
</profiles>
```

可以看到定义了多个 profile，每个 profile 都有唯一的 id，也包含 properties 属性。这里为每个 profile 都定义一个名为 profiles.active 的 properties，每个环境的值不同。当我们打包项目时，激活不同的环境，profiles.active字段就会被赋予不同的值。

## 2.2 项目目录

![image-20211231100112483](https://oss.rainsheep.cn/blog/image-20211231100112483-1640916072-203-1640917119-e34.png)

## 2.3 关键配置

配置完 profiles 后，我们还需要在 pom 中配置 resources 和 filters

```xml
<build>
    <!-- 根据被激活的 profiles.active 来选择配置文件 -->
    <filters>
        <filter>src/main/resources/application-${profiles.active}.properties</filter>
    </filters>
    <resources>
        <resource>
            <directory>src/main/resources</directory>
            <!--是否使用参数值代替参数名。参数值取自properties元素或者文件里配置的属性，文件在filters元素里列出。 -->
            <filtering>true</filtering>
            <!-- 打包时排除环境配置文件 -->
            <excludes>
                <exclude>**/application-*.properties</exclude>
            </excludes>
        </resource>
    </resources>
</build>
```

## 2.4 激活 profile

激活 profile 的方式有很多种

**默认激活**

```xml
<activeByDefault>true</activeByDefault>
```

当没有指明要激活哪个 profile 时，默认激活这个。

**maven 命令激活**

即在使用 maven 打包时通过 -P 参数，-P 后跟上 profile 的唯一 id，如

```bash
mvn package -Ptest
```

**通过 pom 文件里的 activation 属性**

```xml
<profile>
    <id>prod</id>
    <properties>
        <profiles.active>prod</profiles.active>
    </properties>
    <!--activation用来指定激活方式，可以根据jdk环境，环境变量，文件的存在或缺失-->
    <activation>
        <!--配置默认激活-->
        <activeByDefault>true</activeByDefault>
        <!--通过jdk版本-->
        <!--当jdk环境版本为1.5时，此profile被激活-->
        <jdk>1.5</jdk>
        <!--当jdk环境版本1.5或以上时，此profile被激活-->
        <jdk>[1.5,)</jdk>
        <!--根据当前操作系统-->
        <os>
            <name>Windows XP</name>
            <family>Windows</family>
            <arch>x86</arch>
            <version>5.1.2600</version>
        </os>
        <!--通过系统环境变量，name-value自定义-->
        <property>
            <name>env</name>
            <value>test</value>
        </property>
        <!--通过文件的存在或缺失-->
        <file>
            <missing>target/generated-sources/axistools/wsdl2java/
                        com/companyname/group</missing>
            <exists/>
        </file>
    </activation>
</profile>
```

**settings.xml 中使用 activeProfiles 指定(了解即可)**

即 mave 目录下的 settings.xml 也可以添加下面的代码来指定激活哪个 profile。

```xml
<activeProfiles>  
     <activeProfile>profileTest1</activeProfile>  
</activeProfiles>
```

## 2.5 配置文件引用变量

比如在 profile 中声明 server.port

```xml
<profiles>
    <profile>
        <id>prod</id>
        <properties>
            <profiles.active>prod</profiles.active>
            <server.port>8080</server.port>
        </properties>
        <activation>
            <activeByDefault>true</activeByDefault>
        </activation>
    </profile>
</profiles>
```

springBoot 项目可以使用声明的变量

```yaml
server:
  port: @server.port@
```

其他项目可以通过 `${server.port} `引用

