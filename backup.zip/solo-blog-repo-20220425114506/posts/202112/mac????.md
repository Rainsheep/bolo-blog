title: mac 终端命令
date: '2021-12-22 11:53:49'
updated: '2021-12-22 11:53:49'
tags: [mac]
permalink: /articles/2021/12/22/1640145229491.html
---
# 1. 用户和用户组操作

```bash
# 查看所有的组    (仅显示组名)
dscl . -list /Groups

# 查看所有的组    （显示所有组的详细信息）
dscl . -readall /Groups

# 查看所有组对应的ID    （仅显示组名与ID）
dscl . -list /Groups PrimaryGroupID

# 查看指定的组    （显示详细信息）
dscl . -read /Groups/组名                     

# 单独查看指定组中的所有用户
dscl . -read /Groups/组名 GroupMembership

# 查看所有的用户    (仅显示用户名)
dscl . -list /Users

# 查看所有用户对应的ID
dscl . -list /Users UniqueID

# 查看指定用户的详细信息
dscl . -read /Users/用户名

# 单独查看指定用户的ID
dscl . -read /Users/用户名 PrimaryGroupID

# 查看指定用户的ID与真实名字
dscl . -read /Users/用户名 PrimaryGroupID RealName

# 创建组
sudo dscl . create /Groups/组名

# 给创建的组创建ID       PrimaryGroupID
sudo dscl . -create /Groups/组名 gid 数字            （数字为ID，必须唯一）

# 给创建的组创建密码    Password
sudo dscl . -create /Groups/组名 passwd "密码"

# 给创建的组添加真实名字    RealName
sudo dscl . -append /Groups/组名 RealName 真实名字

# 创建用户
sudo dscl . -create /Users/用户名

# 创建UserShell
sudo dscl . -create /Users/用户名 UserShell /bin/bash

# 创建真实名字 RealName
sudo dscl . -create/Users/用户名 RealName "真实名字"

# 以下同理
sudo dscl . -create /Users/用户名  UniqueID "数字"
sudo dscl . -create /Users/用户名  PrimaryGroupID 数字
sudo dscl . -create /Users/用户名  NFSHomeDirectory /Users/用户名

# 修改用户密码
sudo dscl . -passwd /Users/用户名 "密码"

# 将某用户添加到某组中
sudo dscl . -append /Groups/组名 GroupMembership 用户名

# 删除组
sudo dscl . -delete /Groups/组名

# 将某用户从某组中删除
sudo dscl . -delete /Groups/某组 GroupMembership 用户名
```



