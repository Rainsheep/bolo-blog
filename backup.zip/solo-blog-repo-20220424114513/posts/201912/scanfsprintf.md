title: scanf,sprintf
date: '2019-12-03 20:46:30'
updated: '2019-12-03 20:46:30'
tags: [acm, 知识点总结]
permalink: /articles/2019/12/03/1575377189955.html
---
```cpp
/*scanf和printf原型为sscanf(screen,"%d",&n);和sprintf(screen,"%d",n);
sscanf(str，"%d",&n);将str中内容以%d的格式写到n中，sprintf(str,"%d",n);将n以%d的格式写到str字符数组中*/ 
#include<iostream>
#include<string>
#include<cstdio>
using namespace std;
int main()
{
	char s[100]="123";
	char ss[100];
	string str="123";
	int n;
	sscanf(str.c_str(),"%d",&n);//str.c_str(),将string转换为指针数组 
	sscanf (s,"%d",&n);//等效 
	sprintf(ss,"%d",n*10);
	cout<<n<<endl;
	cout<<ss<<endl;
}

```
