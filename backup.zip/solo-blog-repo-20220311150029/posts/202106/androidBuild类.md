title: android Build 类
date: '2021-06-21 17:47:02'
updated: '2021-06-21 17:47:02'
tags: [android]
permalink: /articles/2021/06/21/1624268822420.html
---
参考文献：[Android之Build类.（Android获取手机配置信息 ）](https://blog.csdn.net/gjy211/article/details/52015198?spm=1001.2014.3001.5506)

## 1. 类概述

android.os.Build：从系统属性中提取设备硬件和版本信息。

## 2. 内部类

Build.VERSION  各种版本字符串

Build.VERSION_CODES  目前已知的版本代码的枚举类

## 3. 常量

UNKNOWN  当一个版本属性不知道时所设定的值。其字符串值为 "unknown" .

## 4. 构造方法

Build()

## 5. 静态属性

* BOARD   主板
* BOOTLOADER 系统启动程序版本号
* BRAND  系统定制商
* CPU_ABI  cpu指令集
* CPU_ABI2 cpu指令集2
* DEVICE 设备参数
* DISPLAY  显示屏参数
* FINGERPRINT   唯一识别码
* HARDWARE   硬件名称
* HOST
* ID  修订版本列表
* MANUFACTURER  硬件制造商
* MODEL  版本即最终用户可见的名称
* PRODUCT 整个产品的名称
* SERIAL 硬件序列号
* TAGS  描述build的标签,如未签名，debug等等
* 18、TIME
* TYPE build的类型
* USER

```java
//BOARD 主板
String phoneInfo = "BOARD: " + android.os.Build.BOARD;
phoneInfo += ", BOOTLOADER: " + android.os.Build.BOOTLOADER;

//BRAND 运营商
phoneInfo += ", BRAND: " + android.os.Build.BRAND;
phoneInfo += ", CPU_ABI: " + android.os.Build.CPU_ABI;
phoneInfo += ", CPU_ABI2: " + android.os.Build.CPU_ABI2;

//DEVICE 驱动
phoneInfo += ", DEVICE: " + android.os.Build.DEVICE;

//DISPLAY 显示
phoneInfo += ", DISPLAY: " + android.os.Build.DISPLAY;

//指纹
phoneInfo += ", FINGERPRINT: " + android.os.Build.FINGERPRINT;

//HARDWARE 硬件
phoneInfo += ", HARDWARE: " + android.os.Build.HARDWARE;
phoneInfo += ", HOST: " + android.os.Build.HOST;
phoneInfo += ", ID: " + android.os.Build.ID;

//MANUFACTURER 生产厂家
phoneInfo += ", MANUFACTURER: " + android.os.Build.MANUFACTURER;

//MODEL 机型
phoneInfo += ", MODEL: " + android.os.Build.MODEL;
phoneInfo += ", PRODUCT: " + android.os.Build.PRODUCT;
phoneInfo += ", RADIO: " + android.os.Build.RADIO;
phoneInfo += ", RADITAGSO: " + android.os.Build.TAGS;
phoneInfo += ", TIME: " + android.os.Build.TIME;
phoneInfo += ", TYPE: " + android.os.Build.TYPE;
phoneInfo += ", USER: " + android.os.Build.USER;

//VERSION.RELEASE 固件版本
phoneInfo += ", VERSION.RELEASE: " + android.os.Build.VERSION.RELEASE;
phoneInfo += ", VERSION.CODENAME: " + android.os.Build.VERSION.CODENAME;

//VERSION.INCREMENTAL 基带版本
phoneInfo += ", VERSION.INCREMENTAL: " + android.os.Build.VERSION.INCREMENTAL;

//VERSION.SDK SDK版本
phoneInfo += ", VERSION.SDK: " + android.os.Build.VERSION.SDK;
phoneInfo += ", VERSION.SDK_INT: " + android.os.Build.VERSION.SDK_INT
```



