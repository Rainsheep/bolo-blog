title: BitmapDrawable
date: '2021-06-27 11:16:15'
updated: '2021-06-27 11:16:15'
tags: [android]
permalink: /articles/2021/06/27/1624763774994.html
---
## 1. 介绍

BitmapDrawable 是对 Bitmap 的一种封装,可以设置它包装的 bitmap 在 BitmapDrawable 区域中的绘制方式,有: 平铺填充,拉伸填或保持图片原始大小!以 `<bitmap>` 为根节点! 可选属性如下：

- src: 图片资源~
- antialias: 是否支持抗锯齿
- filter: 是否支持位图过滤,支持的话可以是图批判显示时比较光滑
- dither: 是否对位图进行抖动处理
- gravity: 若位图比容器小,可以设置位图在容器中的相对位置
- tileMode: 指定图片平铺填充容器的模式,设置这个的话, gravity 属性会被忽略,有以下可选值:  disabled (整个图案拉伸平铺), clamp (原图大小),  repeat (平铺), mirror (镜像平铺)

效果图：

![98559776.png](https://b3logfile.com/file/2021/06/98559776-cab4cdfb.png)

**xml 实现**

xml 定义 BitmapDrawable, bitmap.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<bitmap xmlns:android="http://schemas.android.com/apk/res/android"
    android:src="@drawable/ic_launcher"
    android:tileMode="mirror">

</bitmap>
```

Activity_main.xml

```xml
<ImageView
    android:id="@+id/image_view"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="@drawable/bitmap" />
```

**Java 实现**

```java
Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher);
BitmapDrawable bitmapDrawable = new BitmapDrawable(getResources(), bitmap);
bitmapDrawable.setTileModeXY(Shader.TileMode.MIRROR, Shader.TileMode.MIRROR);

imageView.setBackground(bitmapDrawable);
```



