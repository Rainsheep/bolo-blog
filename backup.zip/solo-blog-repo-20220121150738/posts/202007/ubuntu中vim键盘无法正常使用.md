title: ubuntu中vim键盘无法正常使用
date: '2020-07-17 09:13:12'
updated: '2020-07-17 09:13:12'
tags: [Linux]
permalink: /articles/2020/07/17/1594948392242.html
---
问题描述：上下左右方向键出现字母，backspace键不能删除字符

问题原因：ubuntu默认安装装的是vim tiny版本，而我们需要的是vim full版本

解决方法：

```
$sudo apt-get remove vim-common
$sudo apt-get install vim
```
