title: mac 安装 redis
date: '2021-09-03 22:35:48'
updated: '2021-09-03 22:35:48'
tags: [NOSQL]
permalink: /articles/2021/09/03/1630679748847.html
---
参考文献：

[mac安装redis](https://www.jianshu.com/p/6d1bb631b39d)

[mac下安装redis](https://www.cnblogs.com/kermitjam/p/11193466.html)

# mac 安装 redis

* redis 默认端口 6379
* 载mac版redis安装包,下载地址 https://redis.io/download
* ```
  解压:　　
      tar zxvf redis-4.0.14.tar.gz
  
  移动到:　　
      mv redis-4.0.14.tar.gz ~/software　　
  
  切换到:　　
      cd ~/software/redis-4.0.14/　　
  
  进入到解压后的文件夹下面,路径改成你自己的文件夹存放的路径
  
  编译测试: 
      sudo make test
  
  编译安装:　　
      sudo make install
  ```

# redis 启动与停止

* 启动：redis-server
* 停止：redis-cli shutdown

> 如果在启动的时候提示: Address already in use.意思你的 6379 端口被占用
> 
> ps -ef | grep -i redis 找到进程，kill -9 pid 即可

