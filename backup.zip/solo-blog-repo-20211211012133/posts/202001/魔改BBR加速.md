title: 魔改BBR加速
date: '2020-01-17 22:33:01'
updated: '2020-01-17 22:33:01'
tags: [Shadowsocks, ss]
permalink: /articles/2020/01/17/1579271581050.html
---
参考链接：
[南琴浪版暴力魔改BBR一键安装脚本附加速50倍效果图](https://ssr.tools/550)

### 1. 下载脚本并运行
>CentOS
```
wget --no-check-certificate https://raw.githubusercontent.com/tcp-nanqinlang/general/master/General/CentOS/bash/tcp_nanqinlang-1.3.2.sh
chmod +x tcp_nanqinlang-1.3.2.sh
bash tcp_nanqinlang-1.3.2.sh
```
附上脚本：
[tcpnanqinlang1.3.2.zip](https://img.hacpai.com/file/2020/01/tcpnanqinlang1.3.2-4d384a1d.zip)


### 2. 安装BBR
选择1安装内核
![选择1安装](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-01-17+22:26:15+p_20200117102609.png)

安装完成以后根据提示重启
![reboot](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-01-17+22:28:15+p_20200117102807.png)

重启以后选择2开启BBR加速
![开启算法](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-01-17+22:31:36+p_20200117103134.png)



