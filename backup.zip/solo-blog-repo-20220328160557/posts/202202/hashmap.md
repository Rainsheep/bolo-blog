title: hashmap
date: '2022-02-24 14:01:48'
updated: '2022-02-24 14:01:48'
tags: [java]
permalink: /articles/2022/02/24/1645682508771.html
---
参考文档：
[漫画：什么是ConcurrentHashMap？](https://zhuanlan.zhihu.com/p/31614308)
[漫画：什么是HashMap？](https://mp.weixin.qq.com/s?__biz=MzIxMjE5MTE1Nw==&mid=2653191907&idx=1&sn=876860c5a9a6710ead5dd8de37403ffc&chksm=8c990c39bbee852f71c9dfc587fd70d10b0eab1cca17123c0a68bf1e16d46d71717712b91509&scene=21#wechat_redirect)
[漫画：高并发下的HashMap](https://mp.weixin.qq.com/s?__biz=MzIxMjE5MTE1Nw==&mid=2653192000&idx=1&sn=118cee6d1c67e7b8e4f762af3e61643e&chksm=8c990d9abbee848c739aeaf25893ae4382eca90642f65fc9b8eb76d58d6e7adebe65da03f80d&scene=21#wechat_redirect)
[Hashmap实现原理及扩容机制详解](https://blog.csdn.net/lkforce/article/details/89521318)
[HashMap JDK1.7和1.8区别（完整版）](https://blog.csdn.net/Vince_Wang1/article/details/105888297)

# HashMap

## HashMap 基本知识

* hashmap 初始长度为 16，初始化的时候，传入参数不是 2 的幂数，也会自动设置为 2 的幂数
* hashmap 长度必须为 2 的幂数
  
  > 为什么是 2 的幂数?
  > 为了更快的计算 hash，index = hash(key) % length 效率太低，开发者采用位运算来计算 index = hash(key) & (length -1)，如果 length 不是 2 的幂数，会产生大量冲突
* 加载因数是 0.75，当前数量 * 加载因子 >= 容量的时候，就会扩容，容量翻倍，最大容量为 1 << 30。

## 1.7 和 1.8 区别

| 不同                     | JDK 1.7                                                      | JDK 1.8                                                      |
| ------------------------ | ------------------------------------------------------------ | ------------------------------------------------------------ |
| 存储结构                 | 数组 + 链表                                                  | 数组 + 链表 + 红黑树                                         |
| 初始化方式               | 单独函数：inflateTable（）                                   | 直接集成到了扩容函数resize（）中                             |
| hash值计算               | 扰动处理=9次扰动=4次位运算+5次异或运算                       | 扰动处理=2次扰动=1次位运算+1次异或运算                       |
| 存放数据的规则           | 无冲突时，存放数组；冲突时，存放链表                         | 无冲突时，存放数组；冲突&链表长度<8:存放单链表; 冲突&链表长度>8:树化并存放红黑树 |
| 插入数据方式             | 头插法（先讲原位置的数据移到后1位，再插入数据到该位置）      | 尾插法（直接插入到链表尾部/红黑树）                          |
| 扩容后存储位置的计算方式 | 全部按照原来方法进行计算（即hashCode -> 扰动函数 ->（h&length-1) | 按照扩容后的规律计算（即扩容后的位置=原位置or原位置+旧容量） |

## 存储方式

我们先看几个参数

```java
static final int DEFAULT_INITIAL_CAPACITY = 1 << 4; //默认初始容量
static final int MAXIMUM_CAPACITY = 1 << 30;  //最大容量2^30
static final float DEFAULT_LOAD_FACTOR = 0.75f; //默认加载因子 也就是0.75F
static final int TREEIFY_THRESHOLD = 8;  // 链表长度大于8时树化，数据8是由hashmap作者计算而出
static final int UNTREEIFY_THRESHOLD = 6;  //还原成链表的阈值
static final int MIN_TREEIFY_CAPACITY = 64;//最小树化容量
```

得出以下结论：

如果冲突的节点数已经达到8个，看是否需要改变冲突节点的存储结构，treeifyBin首先判断当前hashMap的长度，如果不足64，只进行resize，扩容table，同时最小树形化容量阈值：即 当哈希表中的容量 > 该值时，才允许树形化链表 （即 将链表 转换成红黑树）， 否则，若桶内元素太多时，则直接扩容，而不是树形化，为了避免进行扩容、树形化选择的冲突，这个值不能小于 4 * TREEIFY_THRESHOLD，这里就是64。
一定是在大于MIN_TREEIFY_CAPACITY的时候，才会树化，无论链表的长度是否大于 TREEIFY_THRESHOLD

**优点**

相比于jdk1.7的数组+链表结构，先看看hshMap在jdk 1.8的结构，如下图，用的是数组+链表+红黑树的结构，也叫哈希桶，在jdk 1.8之前都是数组+链表的结构，因为在链表的查询操作都是O(N)的时间复杂度，而且hashMap中查询操作也是占了很大比例的，如果当节点数量多，转换为红黑树结构，那么将会提高很大的效率，因为红黑树结构中，增删改查都是O(log n)。
![20200304215336689](https://oss.rainsheep.cn/blog/20200304215336689-1645680370-368.png)

但阈值的存在毫无疑问是必要的，红黑树虽然效率高，但红黑树本身是一个复杂的数据结构，涉及到自旋的操作，在链表节点数量比较少的时候，很明显链表增删改查更为合适，所以并不能直接采用红黑树

## 扰动函数

在JDK1.7中的扰动函数源码

```java
final int hash(Object k) {
    int h = hashSeed;
    if (0 != h && k instanceof String) {
        return sun.misc.Hashing.stringHash32((String) k);
    }

    h ^= k.hashCode();

    // This function ensures that hashCodes that differ only by
    // constant multiples at each bit position have a bounded
    // number of collisions (approximately 8 at default load factor).
    h ^= (h >>> 20) ^ (h >>> 12);
    return h ^ (h >>> 7) ^ (h >>> 4);
}
```

而在JDK1.8中

```java
static final int hash(Object key) {
    int h;
    return (key == null) ? 0 : (h = key.hashCode()) ^ (h >>> 16);
}
```

而至于为什么JDK1.8进行了缩减，可能是因为做多了离散分布提升不明显，还是为了效率考虑，进行了缩减。

## 插入方式

在1.7中使用的是头插法，1.8改成了尾插法，为了避免头插法导致的在多线程的情况下 hashmap 在 put 元素时产生的环形链表的问题，但 1.8 仍然存在数据覆盖的问题，所以仍然不是线程安全的

[JDK1.8数据覆盖](https://blog.csdn.net/swpu_ocean/article/details/88917958)
[JDK1.7环形链表](https://blog.csdn.net/dgutliangxuan/article/details/78779448?utm_medium=distribute.pc_relevant.none-task-blog-BlogCommendFromBaidu-1&depth_1-utm_source=distribute.pc_relevant.none-task-blog-BlogCommendFromBaidu-1)

# ConcurrentHashMap

* resize() 扩容
* rehash() 重新计算 hash

扩容的时候干了两件事

1. 创建一个新的Entry空数组，长度是原数组的2倍。
2. 遍历原Entry数组，把所有的Entry重新Hash到新数组。

但是多线程同时 resize 的时候就会造成线程不安全问题。

HashMap 线程安全的解决方案有 HashTable 或者 Collections.synchronizedMap，但无论读写，都会给整个集合加锁，有性能问题。

这时候我们使用 ConcurrentHashMap，兼顾了线程安全和性能。

## Segment

ConcurrentHashMap 的一个重要概念。

Segment是什么呢？Segment本身就相当于一个HashMap对象。

同HashMap一样，Segment包含一个HashEntry数组，数组中的每一个HashEntry既是一个键值对，也是一个链表的头节点。

单一的Segment结构如下：

![v2-16e5f4cd5259e2219613b2d75e817929_720w](https://oss.rainsheep.cn/blog/v2-16e5f4cd5259e2219613b2d75e817929_720w-1645682156-5d8.png)

像这样的Segment对象，在ConcurrentHashMap集合中有多少个呢？有2的N次方个，共同保存在一个名为segments的数组当中。

因此整个ConcurrentHashMap的结构如下：

![v2-614be9ff2b2042fc3e8b30c7e1a7243d_720w](https://oss.rainsheep.cn/blog/v2-614be9ff2b2042fc3e8b30c7e1a7243d_720w-1645682180-bfa.png)

可以说，ConcurrentHashMap是一个二级哈希表。在一个总的哈希表下面，有若干个子哈希表。

这样的二级结构，和数据库的水平拆分有些相似。

## 读写情况

ConcurrentHashMap优势就是采用了**锁分段技术**，每一个Segment就好比一个自治区，读写操作高度自治，Segment之间互不影响。

**Case1：不同Segment的并发写入**

![v2-e967fdf4e671fa2afa8ca97f8e600ca9_720w](https://oss.rainsheep.cn/blog/v2-e967fdf4e671fa2afa8ca97f8e600ca9_720w-1645682258-c23.png)

**Case2：同一Segment的一写一读**

![v2-6317419ee2e6a40d8cdd0f15ca202573_720w](https://oss.rainsheep.cn/blog/v2-6317419ee2e6a40d8cdd0f15ca202573_720w-1645682273-2f2.png)

**Case3：同一Segment的并发写入**

![v2-4343518fc5b0feecc827555043cb8b3c_720w](https://oss.rainsheep.cn/blog/v2-4343518fc5b0feecc827555043cb8b3c_720w-1645682291-f24.png)

由此可见，ConcurrentHashMap当中每个Segment各自持有一把锁。在保证线程安全的同时降低了锁的粒度，让并发操作效率更高。

## get

1. 为输入的Key做Hash运算，得到hash值。
2. 通过hash值，定位到对应的Segment对象
3. 再次通过hash值，定位到Segment当中数组的具体位置。

## put

1. 为输入的Key做Hash运算，得到hash值。
2. 通过hash值，定位到对应的Segment对象
3. 获取可重入锁
4. 再次通过hash值，定位到Segment当中数组的具体位置。
5. 插入或覆盖HashEntry对象。
6. 释放锁。

## size

ConcurrentHashMap的Size方法是一个嵌套循环，大体逻辑如下：

1. 遍历所有的Segment。
2. 把Segment的元素数量累加起来。
3. 把Segment的修改次数累加起来。
4. 判断所有Segment的总修改次数是否大于上一次的总修改次数。如果大于，说明统计过程中有修改，重新统计，尝试次数+1；如果不是。说明没有修改，统计结束。
5. 如果尝试次数超过阈值，则对每一个Segment加锁，再重新统计。
6. 再次判断所有Segment的总修改次数是否大于上一次的总修改次数。由于已经加锁，次数一定和上次相等。
7. 释放锁，统计结束。



