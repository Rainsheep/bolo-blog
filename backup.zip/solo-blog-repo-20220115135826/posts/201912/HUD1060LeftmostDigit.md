title: HUD-1060 Leftmost Digit
date: '2019-12-03 12:29:40'
updated: '2019-12-03 12:29:40'
tags: [acm, 模拟]
permalink: /articles/2019/12/03/1575347380440.html
---
题目链接：[HDU—1060](http://acm.hdu.edu.cn/showproblem.php?pid=1060)

对一个数num可写为 num=a*10^n , 即科学计数法，使a的整数部分即为num的最高位数字
numnum=10n * a 这里的n与上面的n不等
两边取对数： num*lg(num) = n + lg(a);
因为a<10，所以0<lg(a)<1
令x=n+lg(a); 则n为x的整数部分，lg(a)为x的小数部分
又x=num*lg(num);
a=10(x-n) = 10(x-int(x)))
再取a的整数部分即得num的最高位
总结：遇到大数无法处理的时候善于用logn(x);log(x)表示以e为底，logn(x)表示自定义底数

```c++
#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	int num,T,a;
	double n;
	cin>>T;
	while(T--)
	{
		cin>>num;
		n=num*log10(num);//num最大10位，n可能为19位 
		a=(int)pow(10,n-(__int64)(n));//int 不足以存n 
		cout<<a<<endl;
	}
}

```
