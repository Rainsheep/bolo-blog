title: 基于CentOS 6.5 Server - 64 Bit搭建ss
date: '2019-12-02 22:24:46'
updated: '2019-12-04 15:13:25'
tags: [Shadowsocks, ss]
permalink: /articles/2019/12/02/1575296686709.html
---
# 服务器端的搭建

#### 使用 root 用户，分别执行以下 3 条命令

```shell
$ wget --no-check-certificate -O shadowsocks-all.sh https://raw.githubusercontent.com/teddysun/shadowsocks_install/master/shadowsocks-all.sh  
$ chmod +x shadowsocks-all.sh  
$ ./shadowsocks-all.sh 2>&1 | tee shadowsocks-all.log

```

> 如果第一条执行不成功，则说明没有 wget ,先执行
> `$ yum -y install passed`

执行后，会提示输入源码语言，密码、端口、及加密方式等。（笔者这里端口使用 8989；源码选择的是 go 语言；加密方式我这里选择 aes-256-cfb；）

最终会显示以下效果，说明部署已完成：

```
Congratulations, your_shadowsocks_version install completed!  
Your Server IP        :11.11.11.11  
Your Server Port      :8989  
Your Password         :123456  
Your Encryption Method:aes-256-cfb  
    
Welcome to visit:https://teddysun.com/486.html  
Enjoy it
```

此时，脚本已经启动，也可以查看状态看脚本是否启动
启动脚本后面的参数含义，从左至右依次为：启动，停止，重启，查看状态。

Shadowsocks-Python 版：
`/etc/init.d/shadowsocks-python start | stop | restart | status`

ShadowsocksR 版：
`/etc/init.d/shadowsocks-r start | stop | restart | status`

Shadowsocks-Go 版：
`/etc/init.d/shadowsocks-go start | stop | restart | status`

Shadowsocks-libev 版：
`/etc/init.d/shadowsocks-libev start | stop | restart | status`

断开与服务器的连接，重新连接

#### 把 8989 端口设置为开放状态

打开防火墙配置文件：
`$ vim /etc/sysconfig/iptables`
如果没有，需要安装
`$ yum -y install VIM`

VIM 为一个编辑器，打开这个文件
打开后，按 i 下面出现 insert，光标移到上面文本内，插入下面这句：
`-A INPUT -p tcp -m state --state NEW -m tcp --dport 8989 -j ACCEPT`
插入后没有任何提醒，保存 VIM 就行，注意，此时不能强制关闭 VIM，会出错，先按 esc 减，紧接着按 shift+:（英文状态）输入 wq 保存退出即可

命令：  q 是关闭，q! 是强制关闭，wq 是保存关闭 ，wq!是强制保存关闭

保存后使更改生效，执行以下：
`$ service iptables save`

#### 开放云服务器端口（如果是阿里云服务器请继续看）

阿里云有安全组配置，需要进入阿里云管理界面找到安全组配置，把 8989 端口开放。否则外网依然无法方位该端口。

#### 开机自启

考虑到如果 VPS 被重启（实际上只会你自己重启……），所以我们将 shadowsocks 加入开机启动项，配置如下：

`VIM /etc/rc.local`
然后在 exit 0 之前加入
`sudo ssserver -c /etc/shadowsocks.json`
然后重启 VPS：
`reboot`
重启后查看进程：
`ps aux | grep shadowsocks`
如果 shadowsocks 正常运行，表明设置成功。
至此，服务器部署完成！

#### 卸载方法：使用 root 用户，执行以下命令即可

`$ ./shadowsocks-all.sh uninstall`

# 客户端的使用

#### windows 客户端

首先搜索 shadowsocks-windows，打开后根据你的服务器配置。
服务器地址：云服务器 ip、端口：之前配置的端口、加密方式要选择服务器选择的加密方式、本级代理端口 1080（可以改成别的）。

配置好后，在电脑右下角找到 ss，并点击启用。
至此，代理配置成功！

![20180403215302947.png](https://img.hacpai.com/file/2019/12/20180403215302947-67690525.png)


#### iPhone 代理配置

a.下载：
APP Store 中下载 SsrConnectPro（目前中国区可下载，没有被封）。

b.使用：
打开 App 后，点击右上角 + 号：

```
type：ss  
name : 随便起一个名字即可。笔者是：abcd  
server : 云服务器 ip  
port : 刚才配置的 ip。笔者是：8989  
password ：你服务器设置的密码  
proxyMethod：system  
method ：刚才配置的加密方式。笔者是：AES-256-CFB
```

点击“saveconfiguration”后进入 choos 页面，点击你刚刚创建的那个名字 abcd 即可。回到首页，找到你创建的代理并打开。
配置成功！经测试 google、YouTube 等网站打开很快，1080p 视频毫无压力。

#### Ubuntu 系统代理配置

a.安装 shadowsocks
`$ sudo apt install shadowsocks`

b.找到 config.json，并编辑代理配置

```
$ cd /etc/shadowsocks/
$ sudo VIM config.json  
{  
	"server":"x.x.x.x",    //ss服务器的ip  
	"server_port":8989, //ss服务器的端口，笔者这里配置的是8989  
 	"local_address": "127.0.0.1",  
	"local_port":1080,  //本机端口：可以换成别的  
	"password":"123456", //ss服务器密码  
	"timeout":300,  
	"method":"aes-256-cfb"//ss服务器配置的加密方式  
}
```

c.启动 shadowsocks，启动后控制台不要关闭
`$ sslocal -c config.json`

d.配置代理。
右上角-系统设置-网络-网络代理-手动。
Socks 主机：127.0.0.1    端口：1080
最后点击“应用到整个系统”，至此，配置完成。

e.让终端也走代理的方法:
在 ~/.bashrc 文件中增加以下两句，表示 bash 终端中的 http 和 https 的请求也通过 socks5 协议进行代理转发。

```
export http_proxy=&quot;socks5://127.0.0.1:1080&quot;  
export https_proxy=&quot;socks5://127.0.0.1:1080&quot;
```

#### 解决 CentOS 没有 iptables 的问题

1. 任意运行一条 iptables 防火墙规则配置命令：
   `iptables -P OUTPUT ACCEPT`
2. 对 iptables 服务进行保存：
   `service iptables save`

> 如果上述命令执行失败报出：The service command supports only basic LSB actions (start, stop, restart, try-restart, reload, force-reload, status). For other actions, please try to use systemctl.

解决方法：
`systemctl stop firewalld` 关闭防火墙
`yum install iptables-services` 安装或更新服务
再使用 `systemctl enable iptables` 启动 iptables
最后 `systemctl start iptables` 打开 iptables
再执行 `service iptables save`

3. 重启 iptables 服务：
   `service iptables restart`
   执行完毕之后/etc/syscofig/iptables 文件就有了
