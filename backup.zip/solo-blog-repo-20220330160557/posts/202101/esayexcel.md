title: esayexcel
date: '2021-01-25 22:33:30'
updated: '2021-01-25 22:33:30'
tags: [excel]
permalink: /articles/2021/01/25/1611585210447.html
---
参考文献：
[github](https://github.com/alibaba/easyexcel)
[官方文档](https://www.yuque.com/easyexcel/doc/easyexcel)

> 本文只涉及基本读取的入门案例，详细请查看官方文档

# 一、简介

Java 解析、生成 Excel 比较有名的框架有 Apache poi、jxl。但他们都存在一个严重的问题就是非常的耗内存，poi 有一套 SAX 模式的 API 可以一定程度的解决一些内存溢出的问题，但 POI 还是有一些缺陷，比如 07 版 Excel 解压缩以及解压后存储都是在内存中完成的，内存消耗依然很大。easyexcel 重写了 poi 对 07 版 Excel 的解析，能够原本一个 3M 的 excel 用 POI sax 依然需要 100M 左右内存降低到几 M，并且再大的 excel 不会出现内存溢出，03 版依赖 POI 的 sax 模式。在上层做了模型转换的封装，让使用者更加简单方便。

总结：easyexcel 是用来处理 Excel 的，基于 POI 并对 POI 做了封装。

# 二、读 Excel

**Excel 示例**

![image.png](https://b3logfile.com/file/2021/01/image-7ca69454.png)

**导入依赖**

```xml
<dependency>
    <groupId>com.alibaba</groupId>
    <artifactId>easyexcel</artifactId>
    <version>2.2.7</version>
</dependency>
```

**实体类**

我们需要创建一个实体类，easyexcel 会把每行数据封装为此类的对象。

Excel 表需要有表头，表头不会封装进对象。

```java
@Data
public class Node {
    private String school;
    private String classNum;
    private Double score;
}
```

我们可以指定自动映射的下标或者列名

```java
// 下标，从 0 开始
@Data
public class Node {
    @ExcelProperty(index = 1)
    private String school;
    @ExcelProperty(index = 2)
    private String classNum;
    @ExcelProperty(index = 6)
    private Double score;
}

// name
@Data
public class Node {
    @ExcelProperty("班级")
    private String classNum;
    @ExcelProperty("分数")
    private Double score;
}
```

> 这里不建议 index 和 name 同时用，要么一个对象只用 index，要么一个对象只用 name 去匹配

**监听器**

监听器的作用：每一行读取完或者所有数据读取完都会来回调，我们可以进行数据存储计算等操作

```java
public class DataListener extends AnalysisEventListener<Node> {

    /**
     * 这个每一条数据解析都会来调用
     */
    @Override
    public void invoke(Node node, AnalysisContext analysisContext) {
        System.out.println(node);
    }
    
    /**
     * 所有数据解析完成了 都会来调用
     */
    @Override
    public void doAfterAllAnalysed(AnalysisContext analysisContext) {
    }
}
```

**main 方法**

```java
public class Main {
    public static void main(String[] args) {
        String fileName = "test.xlsx";
        // 创建excel对应的实体对象
        // 由于默认一行行的读取 excel，所以需要创建 excel 一行一行的回调监听器，实体类 class
        // 直接读即可，监听器类 class
        EasyExcel.read(fileName, Node.class, new DataListener()).sheet().doRead();
    }
}
```



