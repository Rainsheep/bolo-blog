title: mac 禁用 app 更新
date: '2022-02-28 11:06:01'
updated: '2022-02-28 11:06:01'
tags: [mac]
permalink: /articles/2022/02/28/1646017561770.html
---
参考文献：[如何彻底禁止 macOS Big Sur 自动更新，去除更新标记和通知](https://sysin.org/blog/disable-macos-big-sur-update/#1-%E5%8F%96%E6%B6%88%E8%87%AA%E5%8A%A8%E6%9B%B4%E6%96%B0%E9%80%89%E9%A1%B9)

# 禁用单个 App 更新

打开 Finder （访达），浏览到侧边栏 Applications（应用程序），找到不需要更新的 App，点击右键 “显示包内容”，此时出现 Content 文件夹，展开该文件夹，可以看到下面有个 **_MASReceipt** 文件夹，直接将 **_MASReceipt** 文件夹删除，即可禁用该 App 自动检测 App Store 软件更新。

