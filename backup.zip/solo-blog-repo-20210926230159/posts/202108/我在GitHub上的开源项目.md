title: 我在 GitHub 上的开源项目
date: '2021-08-15 21:36:11'
updated: '2021-08-15 21:36:11'
tags: [开源, GitHub]
permalink: /github
---
![GitHub Repo](https://www.rainsheep.cn/images/github_repo.jpg)

### 1. [community](https://github.com/Rainsheep/community) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`1`](https://github.com/Rainsheep/community/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Rainsheep/community/network/members "分叉数")</span>

毕设项目，社团活动管理系统



---

### 2. [authority-management](https://github.com/Rainsheep/authority-management) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/Rainsheep/authority-management/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Rainsheep/authority-management/network/members "分叉数")</span>

权限管理系统



---

### 3. [bolo-blog](https://github.com/Rainsheep/bolo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/Rainsheep/bolo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Rainsheep/bolo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`https://www.rainsheep.cn`](https://www.rainsheep.cn "项目主页")</span>

✍️ 雨羊的个人博客 - 咸鱼不配拥有梦想



---

### 4. [heima-travel](https://github.com/Rainsheep/heima-travel) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/Rainsheep/heima-travel/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Rainsheep/heima-travel/network/members "分叉数")</span>

黑马旅游网



---

### 5. [mall-learning-1](https://github.com/Rainsheep/mall-learning-1) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/Rainsheep/mall-learning-1/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Rainsheep/mall-learning-1/network/members "分叉数")&nbsp;&nbsp;[🏠`http://www.macrozheng.com`](http://www.macrozheng.com "项目主页")</span>

mall学习教程，架构、业务、技术要点全方位解析。mall项目（40k+star）是一套电商系统，使用现阶段主流技术实现。涵盖了SpringBoot 2.3.0、MyBatis 3.4.6、Elasticsearch 7.6.2、RabbitMQ 3.7.15、Redis 5.0、MongoDB 4.2.5、Mysql5.7等技术，采用Docker容器化部署。



---

### 6. [pic-bed](https://github.com/Rainsheep/pic-bed) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/Rainsheep/pic-bed/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Rainsheep/pic-bed/network/members "分叉数")</span>

雨羊的github图床



---

### 7. [Rainsheep.github.io](https://github.com/Rainsheep/Rainsheep.github.io) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/Rainsheep/Rainsheep.github.io/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Rainsheep/Rainsheep.github.io/network/members "分叉数")&nbsp;&nbsp;[🏠`https://rainsheep.github.io/`](https://rainsheep.github.io/ "项目主页")</span>

博客的静态站点



---

### 8. [ShadowDrawable](https://github.com/Rainsheep/ShadowDrawable) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/Rainsheep/ShadowDrawable/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Rainsheep/ShadowDrawable/network/members "分叉数")</span>

Android 阴影的实现



---

### 9. [shell-safe-rm](https://github.com/Rainsheep/shell-safe-rm) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/Rainsheep/shell-safe-rm/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Rainsheep/shell-safe-rm/network/members "分叉数")</span>

😎 Safe-rm: A drop-in and much safer replacement of bash rm with nearly full functionalities and options of the rm command! Safe-rm will act exactly the same as the original rm command.



---

### 10. [solo-blog](https://github.com/Rainsheep/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/Rainsheep/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Rainsheep/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`https://www.rainsheep.cn`](https://www.rainsheep.cn "项目主页")</span>

✍️ 雨羊的个人博客 - 咸鱼不配拥有梦想



---

### 11. [vue-mall](https://github.com/Rainsheep/vue-mall) <kbd title="主要编程语言">Vue</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/Rainsheep/vue-mall/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Rainsheep/vue-mall/network/members "分叉数")</span>



