title: pom 文件
date: '2021-12-30 19:09:48'
updated: '2021-12-30 19:09:48'
tags: [maven]
permalink: /articles/2021/12/30/1640862588650.html
---
参考文档：[maven（二）pom文件详解](https://blog.csdn.net/java_collect/article/details/83963657?spm=1001.2014.3001.5501)

# 1. 什么是 POM 文件

POM( Project Object Model，项目对象模型 ) 是 Maven 工程的基本工作单元，是一个XML文件，包含了项目的基本信息，用于描述项目如何构建，声明项目依赖，等等。执行任务或目标时，Maven 会在当前目录中查找 POM。它读取 POM，获取所需的配置信息，然后执行目标。

POM 中可以指定以下配置：

* 项目依赖
* 插件
* 执行目标
* 项目构建 profile
* 项目版本
* 项目开发者列表
* 相关邮件列表信息

# 2. POM 文件各常用属性含义

## 2.1 项目基本信息

```xml
<project xmlns = "http://maven.apache.org/POM/4.0.0"
    xmlns:xsi = "http://www.w3.org/2001/XMLSchema-instance"
    xsi:schemaLocation = "http://maven.apache.org/POM/4.0.0
    http://maven.apache.org/xsd/maven-4.0.0.xsd">

    <!--声明项目描述符遵循哪一个POM模型版本。模型本身的版本很少改变，虽然如此，但它仍然是必不可少的，
    这是为了当Maven引入了新的特性或者其他模型变更的时候，确保稳定性。 -->
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.jun.cloud</groupId>
    <artifactId>cloud-parent</artifactId>
    <version>0.0.1-SNAPSHOT</version>
    <!--项目产生的构件类型，例如jar、war、ear、pom。插件可以创建他们自己的构件类型，所以前面列的不是全部构件类型 -->
    <packaging>pom</packaging>

    <!--项目的名称和详细描述, Maven产生的文档用,所以基本可以省略 -->
    <name>cloud-parent</name>
    <description>start project for Spring Boot</description>

    <!--父项目的坐标，父 POM 包含了一些可以被继承的默认设置-->
    <parent>
        <groupId>org.springframework.cloud</groupId>
        <artifactId>spring-cloud-starter-parent</artifactId>
        <version>Dalston.RELEASE</version>
        <!-- 父项目的pom.xml文件的相对路径。相对路径允许你选择一个不同的路径。默认值是../pom.xml。Maven首先在构建当前项目的地方寻找父项
           目的pom，其次在文件系统的这个位置（relativePath位置），然后在本地仓库，最后在远程仓库寻找父项目的pom。 -->
        <relativePath/>
        <!-- lookup parent from repository -->
    </parent>

    <!--包含的子模块-->
    <modules>
        <module>cloud-api</module>
        <module>cloud-common</module>
    </modules>
</project>
```

## 2.2 build 项目构建属性介绍

### 2.2.1 resources 资源路径列表

```xml
<build>
    <!--这个元素描述了项目相关的所有资源路径列表，例如和项目相关的属性文件，这些资源被包含在最终的打包文件里。 -->
    <resources>
        <!--这个元素描述了项目相关或测试相关的所有资源路径,可以有多个 -->
        <resource>
            <!-- 描述了资源的目标路径。该路径相对target/classes目录（例如${project.build.outputDirectory}）。举个例
                子，如果你想资源在特定的包里(org.apache.maven.messages)，你就必须该元素设置为org/apache/maven /messages。
                然而，如果你只是想把资源放到源码目录结构里，就不需要该配置。 -->
            <!--<targetPath />-->

            <!--是否使用参数值代替参数名。参数值取自properties元素或者文件里配置的属性，文件在filters元素里列出。 -->
            <filtering />

            <!--描述存放资源的目录，该路径相对POM路径 -->
            <directory>src/main/resources/</directory>
            <!--排除的模式列表，例如**/*.xml -->
            <excludes>
                <exclude>dev/*</exclude>
                <exclude>prod/*</exclude>
                <exclude>test/*</exclude>
            </excludes>
            <!--包含的模式列表，例如**/*.xml. -->
            <includes>
                <!--如果有其他定义通用文件，需要包含进来-->
                <!--<include>messages/*</include>-->
            </includes>
        </resource>
        <resource>
            <!--这里是关键！ 根据不同的环境，把对应文件夹里的配置文件打包-->
            <directory>src/main/resources/${profiles.active}</directory>
        </resource>
    </resources>

    <!--这个元素描述了单元测试相关的所有资源路径，例如和单元测试相关的属性文件。 -->
    <testResources>
        <!--这个元素描述了测试相关的所有资源路径，参见上方build/resources/resource元素的说明 -->
        <testResource>
            <targetPath />
            <filtering />
            <directory />
            <includes />
            <excludes />
        </testResource>
    </testResources>
</build>
```

### 2.2.2 plugins 插件列表

```xml
<build>
    <!--子项目可以引用的默认插件信息。该插件配置项直到被引用时才会被解析或绑定到生命周期。
        给定插件的任何本地配置都会覆盖这里的配置 -->
    <pluginManagement>
        <plugins>
            <!--同下方的插件描述-->
            <plugin>

            </plugin>
        </plugins>
    </pluginManagement>


    <!--使用的插件列表 。 -->
    <plugins>
        <!--plugin元素包含描述插件所需要的信息。 -->
        <plugin>

            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-maven-plugin</artifactId>
            <version />

            <!--是否从该插件下载Maven扩展（例如打包和类型处理器），由于性能原因，只有在真需要下载时，该元素才被设置成enabled。 -->
            <extensions />

            <!--在构建生命周期中  执行  一组目标的配置。每个目标可能有不同的配置。 -->
            <executions>
                <!--execution元素包含了插件执行需要的信息 -->
                <execution>
                    <!--执行目标的标识符，用于标识构建过程中的目标，或者匹配继承过程中需要合并的执行目标 -->
                    <!--<id />-->
                    <!--绑定了目标的构建生命周期阶段，如果省略，目标会被绑定到源数据里配置的默认阶段 -->
                    <phase />
                    <!--配置的执行目标 -->
                    <goals>
                        <goal>repackage</goal>
                    </goals>
                    <!--配置是否被传播到子POM -->
                    <inherited>false</inherited>
                    <!--作为DOM对象的配置 -->
                    <configuration />
                </execution>
            </executions>

            <!--项目引入插件所需要的额外依赖 -->
            <dependencies>
                <!--参见dependencies/dependency元素 -->
                <!--<dependency>-->
                <!--</dependency>-->
            </dependencies>

            <!--任何配置是否被传播到子项目 -->
            <inherited />

            <!--作为DOM对象的配置 -->
            <configuration />
        </plugin>
    </plugins>
</build>
```

### 2.2.3 其他

```xml
<!--构建项目需要的信息 -->
<build>
    <!--该元素设置了项目源码目录，当构建项目的时候，构建系统会编译目录里的源码。该路径是相对于pom.xml的相对路径。 -->
    <sourceDirectory />

    <!--该元素设置了项目脚本源码目录，该目录和源码目录不同：绝大多数情况下，该目录下的内容 会被拷贝到输出目录(因为脚本是被解释的，而不是被编译的)。 -->
    <scriptSourceDirectory />

    <!--该元素设置了项目单元测试使用的源码目录，当测试项目的时候，构建系统会编译目录里的源码。该路径是相对于pom.xml的相对路径。 -->
    <testSourceDirectory />

    <!--被编译过的应用程序class文件和配置文件存放的目录。 -->
    <outputDirectory />

    <!--被编译过的测试class文件存放的目录。 -->
    <testOutputDirectory />

    <!--构建产生的所有文件（即类似target下的所有文件）存放的目录 -->
    <directory />

    <!--产生的构件的文件名（即jar包的名称），默认值是${artifactId}-${version}，如test-profiles-0.0.1-SNAPSHOT.jar。 -->
    <finalName />

    <!--使用来自该项目的一系列构建扩展 -->
    <extensions>
        <!--描述使用到的构建扩展。 -->
        <extension>
            <!--构建扩展的groupId -->
            <groupId />
            <!--构建扩展的artifactId -->
            <artifactId />
            <!--构建扩展的版本 -->
            <version />
        </extension>
    </extensions>

    <!--当项目没有规定目标（Maven2 叫做阶段）时的默认值 -->
    <defaultGoal />

    <!--当filtering开关打开时，使用到的过滤器属性文件列表 -->
    <filters />
</build>
```

## 2.3 profile 介绍

参考：[maven profile](https://www.rainsheep.cn/articles/2021/12/30/1640861247161.html)

## 2.4 repositories

```xml
<!--发现依赖和扩展的远程仓库列表。 -->
<repositories>
    <!--包含需要连接到远程仓库的信息 -->
    <repository>
        <!--远程仓库唯一标识符。可以用来匹配在settings.xml文件里配置的远程仓库 -->
        <id>banseon-repository-proxy</id>
        <!--远程仓库名称 -->
        <name>banseon-repository-proxy</name>
        <!--远程仓库URL，按protocol://hostname/path形式 -->
        <url>http://192.168.1.169:9999/repository/</url>

        <!--如何处理远程仓库里发布版本的下载 -->
        <releases>
            <!--true或者false表示该仓库是否为下载某种类型构件（发布版，快照版）开启。 -->
            <enabled />
            <!--该元素指定更新发生的频率。Maven会比较本地POM和远程POM的时间戳。这里的选项是：always（一直），daily（默认，每日），interval：X（这里X是以分钟为单位的时间间隔），或者never（从不）。 -->
            <updatePolicy />
            <!--当Maven验证构件校验文件失败时该怎么做：ignore（忽略），fail（失败），或者warn（警告）。 -->
            <checksumPolicy />
        </releases>

        <!-- 如何处理远程仓库里快照版本的下载。有了releases和snapshots这两组配置，POM就可以在每个单独的仓库中，为每种类型的构件采取不同的 
                策略。例如，可能有人会决定只为开发目的开启对快照版本下载的支持。参见repositories/repository/releases元素 -->
        <snapshots>
            <enabled />
            <updatePolicy />
            <checksumPolicy />
        </snapshots>

        <!-- 用于定位和排序构件的仓库布局类型-可以是default（默认）或者legacy（遗留）。Maven 2为其仓库提供了一个默认的布局；然 
                而，Maven 1.x有一种不同的布局。我们可以使用该元素指定布局是default（默认）还是legacy（遗留）。 -->
        <layout>default</layout>
    </repository>
</repositories>
```

实例如：

```xml
<repositories>
    <repository>
        <id>spring-snapshots</id>
        <name>Spring Snapshots</name>
        <url>https://repo.spring.io/snapshot</url>
        <snapshots>
            <enabled>true</enabled>
        </snapshots>
    </repository>
    <repository>
        <id>spring-milestones</id>
        <name>Spring Milestones</name>
        <url>https://repo.spring.io/milestone</url>
        <snapshots>
            <enabled>false</enabled>
        </snapshots>
    </repository>
</repositories>
```

## 2.5 dependencies 依赖

```xml
<!--该元素描述了项目相关的所有依赖。 这些依赖组成了项目构建过程中的一个个环节。它们自动从项目定义的仓库中下载。 -->
<dependencies>
    <dependency>

        <groupId>org.apache.maven</groupId>
        <artifactId>maven-artifact</artifactId>
        <!--依赖的版本号。 在Maven 2里, 也可以配置成版本号的范围。 -->
        <version>3.8.1</version>

        <!--依赖范围。在项目发布过程中，帮助决定哪些构件被包括进来。欲知详情请参考依赖机制。
			- compile ：默认范围，用于编译
			- provided：类似于编译，但支持你期待jdk或者容器提供，类似于classpath
            - runtime: 在执行时需要使用
            - test: 用于test任务时使用
            - optional: 当项目自身被依赖时，标注依赖是否传递。用于连续依赖时使用 -->
        <scope>test</scope>


        <!--当计算传递依赖时， 从依赖构件列表里，列出被排除的依赖构件集。
			即告诉maven你只依赖指定的项目，不依赖项目的依赖。此元素主要用于解决版本冲突问题 -->
        <exclusions>
            <exclusion>
                <artifactId>spring-core</artifactId>
                <groupId>org.springframework</groupId>
            </exclusion>
        </exclusions>

        <!--可选依赖，如果你在项目B中把C依赖声明为可选，你就需要在依赖于B的项目（例如项目A）中显式的引用对C的依赖。可选依赖阻断依赖的传递性。 -->
        <optional>true</optional>
    </dependency>
</dependencies>



<!-- 继承自该项目的所有子项目的默认依赖信息。这部分的依赖信息不会被立即解析,而是当子项目声明一个依赖（必须描述group ID和 artifact 
        ID信息），如果group ID和artifact ID以外的一些信息没有描述，则通过group ID和artifact ID 匹配到这里的依赖，并使用这里的依赖信息。 -->
<dependencyManagement>
    <dependencies>
        <!--参见dependencies/dependency元素 -->
        <dependency>
                ......
        </dependency>
    </dependencies>
</dependencyManagement>
```

## 2.6 distributionManagement 发布

```xml
<!--项目分发信息，在执行mvn deploy后表示要发布的位置。有了这些信息就可以把网站部署到远程服务器或者把构件部署到远程仓库。 -->
<distributionManagement>
    <repository>
        <id>nexus-releases</id>
        <url>http://192.168.0.237:8081/nexus/content/repositories/releases</url>
    </repository>

    <!--构件的快照部署到哪里？如果没有配置该元素，默认部署到repository元素配置的仓库 -->
    <snapshotRepository>
        <id>nexus-snapshots</id>
        <url>http://192.168.0.237:8081/nexus/content/repositories/snapshots</url>
    </snapshotRepository>
</distributionManagement>
```



