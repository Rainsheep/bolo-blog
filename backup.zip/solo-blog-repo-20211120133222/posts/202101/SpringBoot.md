title: SpringBoot
date: '2021-01-25 21:10:32'
updated: '2021-06-24 13:28:50'
tags: [springboot, spring]
permalink: /articles/2021/01/25/1611580232845.html
---
推荐阅读：

[肝了一周总结的SpringBoot实战教程，太实用了！](https://mp.weixin.qq.com/s?__biz=MzU1Nzg4NjgyMw==&mid=2247487905&idx=1&sn=f1fcd573f0466e3d09c7018c094ed21f&scene=21#wechat_redirect)

# 一、SpringBoot 基础

## 1. SpringBoot 简介

### 1.1 Spring 缺点

* 配置复杂
* 依赖管理比较麻烦，费时费力

### 1.2 SpringBoot 特点

* 起步依赖，就是将具备某种功能的坐标打包到一起，并提供一些默认的功能
* 自动配置，开箱即用，没有代码生成，也无需 xml 配置

## 2. SpringBoot 快速入门

### 2.1 手动创建项目

**创建基本 maven 工程**

**添加 SpringBoot 起步依赖**

SpringBoot 要求，项目要继承 SpringBoot 的起步依赖 spring-boot-starter-parent

```xml
<parent>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-parent</artifactId>
    <version>2.0.1.RELEASE</version>
</parent>
```

SpringBoot 要集成 SpringMVC 进行 Controller 的开发，所以项目要导入 web 的启动依赖

```xml
<dependencies>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
</dependencies>
```

**编写 SpringBoot 引导类**

要通过 SpringBoot 提供的引导类起步 SpringBoot 才可以进行访问

```java
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// 声明此类是引导类
@SpringBootApplication
public class MySpringBootApplication {
  public static void main(String[] args) {
    // 启动程序，传入引导类字节码对象
    SpringApplication.run(MySpringBootApplication.class);
  }
}
```

> 我们需要将引导类放置在项目的根包目录下，与 comtroller,service,dao 包平级，springboot 会自动扫描与引导类平级的包及其子目录下文件的注解

**然后编写 controller ，即可发现能够使用**

### 2.2 自动生成项目

使用 idea 新建项目的时候不要选择 maven，选择左边的 Spring Initializr

根据需求勾选需要组件即可

**自动生成的 ServletInitializer 说明**

ServletInitializer.java

```java
public class ServletInitializer extends SpringBootServletInitializer {

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(SpringSecurityApplication.class);
    }
    
}
```

Springboot 启动方式有多种，常用的就是 application 启动类启动，直接 run 即可。

我们也可以使用外置 tomcat 启动，这时候就使用到了此类，此类需要继承 SpringBootServletInitializer 类并复写 configure() 方法，SpringBootServletInitializer 的执行过程，简单来说就是通过 SpringApplicationBuilder 构建并封装 SpringApplication 对象，并最终调用 SpringApplication 的 run 方法的过程。

SpringBootServletInitializer 就是原有的 web.xml 文件的替代。

### 2.3 自动生成项目依赖说明

#### 2.3.1 Developer Tools

**Spring Boot Devtools**

热部署使用，具体请看 2.4

**Spring Configuration Processor**

spring boot 默认使用 yml/properties 中的配置，但有时候要用传统的 xml 或 其他配置文件，这时候就需要用到 spring configuration processor。
在配置类开头加上 `@PropertySource("classpath:your.xml")`，其余用法与加载 yml 的配置一样

@PropertySource 中的属性

* value：指明加载配置文件的路径。
* ignoreResourceNotFound：指定的配置文件不存在是否报错，默认是false。当设置为 true 时，若该文件不存在，程序不会报错。实际项目开发中，最好设置 ignoreResourceNotFound 为 false。
* encoding：指定读取属性文件所使用的编码，我们通常使用的是UTF-8。

@ConfigurationProperties 设定前缀，这样就不用在每个属性前面设置 `@Value("${user.*}")` 了

```java
@ConfigurationProperties(prefix = "user")
@PropertySource(value = {"classpath:resources/user.xml"},
        ignoreResourceNotFound = false, encoding = "UTF-8")
// 自动读取配置文件中的 user.name,user.age 赋给对应变量
public class User {
    private String name;
    private int age;
}
```

#### 2.3.2 Web

**Spring Web**

构建 web 项目，使用 spring mvc 框架，使用 tomcat 当做默认服务器

### 2.4 SpringBoot 工程热部署

**添加依赖**

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-devtools</artifactId>
</dependency>
```

**开启自动编译**

Idea -> settings -> build、execution、deployment -> compiler -> 勾选 Build project automatically

**设置注册表**

然后 shift+ctrl+alt+/ -> 选择 registry -> 勾选 compiler.automake.allow.when.runing

## 3. SpringBoot 原理分析

### 3.1 分析 spring-boot-starter-parent

查看 pom.xml 中，parent 标签中 spring-boot-starter-parent， 跳转到了 spring-boot-starter-parent 的 pom.xml，重点部分如下

```xml
<parent>
  <groupId>org.springframework.boot</groupId>
  <artifactId>spring-boot-dependencies</artifactId>
  <version>2.4.2</version>
</parent>

<resource>
  <directory>${basedir}/src/main/resources</directory>
  <filtering>true</filtering>
  <includes>
    <include>**/application*.yml</include>
    <include>**/application*.yaml</include>
    <include>**/application*.properties</include>
  </includes>
</resource>
```

我们发现自动扫描了 resources 中以 application 开头的三个配置文件，我们一般使用 yml 来替换默认配置，注意，如果我们既使用了 yml 也使用了 properties，则properties 配置会覆盖 yml 配置。

我们继续查看 spring-boot-starter-parent 的 parent，spring-boot-dependencies

```xml
<properties>
    <activemq.version>5.15.3</activemq.version>
    <antlr2.version>2.7.7</antlr2.version>
    <appengine-sdk.version>1.9.63</appengine-sdk.version>
    <artemis.version>2.4.0</artemis.version>
    <aspectj.version>1.8.13</aspectj.version>
    <assertj.version>3.9.1</assertj.version>
    <atomikos.version>4.0.6</atomikos.version>
    <bitronix.version>2.1.4</bitronix.version>
    <build-helper-maven-plugin.version>3.0.0</build-helper-maven-plugin.version>
    <byte-buddy.version>1.7.11</byte-buddy.version>
</properties>
<dependencyManagement>
    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot</artifactId>
            <version>2.0.1.RELEASE</version>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-test</artifactId>
            <version>2.0.1.RELEASE</version>
        </dependency>
    </dependencies>
</dependencyManagement>
<build>
    <pluginManagement>
        <plugins>
            <plugin>
                <groupId>org.jetbrains.kotlin</groupId>
                <artifactId>kotlin-maven-plugin</artifactId>
                <version>${kotlin.version}</version>
            </plugin>
            <plugin>
                <groupId>org.jooq</groupId>
                <artifactId>jooq-codegen-maven</artifactId>
                <version>${jooq.version}</version>
            </plugin>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
                <version>2.0.1.RELEASE</version>
            </plugin>
        </plugins>
    </pluginManagement>
</build>
```

从上面的 pom.xml 中我们可以发现，一部分坐标的版本、依赖管理、插件管理已经定义好，所以我们的 SpringBoot 工程继承 spring-boot-starter-parent 后已经具备版本锁定等配置了。所以起步依赖的作用就是进行依赖的传递。

### 3.2 分析 spring-boot-starter-web

查看 pom.xml 中的 spring-boot-starter-web，跳转到了spring-boot-starter-web 的pom.xml，xml 配置如下（只摘抄了部分重点配置）：

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd" xmlns="http://maven.apache.org/POM/4.0.0"
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <dependencies>
    <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter</artifactId>
      <version>2.4.2</version>
      <scope>compile</scope>
    </dependency>
    <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter-json</artifactId>
      <version>2.4.2</version>
      <scope>compile</scope>
    </dependency>
    <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter-tomcat</artifactId>
      <version>2.4.2</version>
      <scope>compile</scope>
    </dependency>
    <dependency>
      <groupId>org.springframework</groupId>
      <artifactId>spring-web</artifactId>
      <version>5.3.3</version>
      <scope>compile</scope>
    </dependency>
    <dependency>
      <groupId>org.springframework</groupId>
      <artifactId>spring-webmvc</artifactId>
      <version>5.3.3</version>
      <scope>compile</scope>
    </dependency>
  </dependencies>
</project>
```

从上面的 spring-boot-starter-web 的 pom.xml 中我们可以发现，spring-boot-starter-web 就是将 web 开发要使用的 spring-web、spring-webmvc 等坐标进行了“打包”，这样我们的工程只要引入 spring-boot-starter-web 起步依赖的坐标就可以进行 web 开发了，同样体现了依赖传递的作用。

### 3.3 自动配置原理解析

查看启动类的注解 @SpringBootApplication，源码如下

```java
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
@SpringBootConfiguration
@EnableAutoConfiguration
@ComponentScan(excludeFilters = { @Filter(type = FilterType.CUSTOM, classes = TypeExcludeFilter.class),
		@Filter(type = FilterType.CUSTOM, classes = AutoConfigurationExcludeFilter.class) })
public @interface SpringBootApplication {
	@AliasFor(annotation = EnableAutoConfiguration.class)
	Class<?>[] exclude() default {};
}
```

* @SpringBootConfifiguration：等同与 @Confifiguration，既标注该类是 Spring的一个配置类
* @EnableAutoConfifiguration：SpringBoot 自动配置功能开启

查看注解 @EnableAutoConfifiguration

```java
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
@AutoConfigurationPackage
@Import(AutoConfigurationImportSelector.class)
public @interface EnableAutoConfiguration {}
```

其中，`@Import(AutoConfifigurationImportSelector.class)` 导入了AutoConfifigurationImportSelector 类，查看源码

```java
protected AutoConfigurationEntry getAutoConfigurationEntry(AnnotationMetadata annotationMetadata) {
    if (!isEnabled(annotationMetadata)) {
        return EMPTY_ENTRY;
    }
    AnnotationAttributes attributes = getAttributes(annotationMetadata);
    List<String> configurations = getCandidateConfigurations(annotationMetadata, attributes);
    configurations = removeDuplicates(configurations);
    Set<String> exclusions = getExclusions(annotationMetadata, attributes);
    checkExcludedClasses(configurations, exclusions);
    configurations.removeAll(exclusions);
    configurations = getConfigurationClassFilter().filter(configurations);
    fireAutoConfigurationImportEvents(configurations, exclusions);
    return new AutoConfigurationEntry(configurations, exclusions);
}

protected List<String> getCandidateConfigurations(AnnotationMetadata metadata, AnnotationAttributes attributes) {
    List<String> configurations = SpringFactoriesLoader.loadFactoryNames(getSpringFactoriesLoaderFactoryClass(), getBeanClassLoader());
    Assert.notEmpty(configurations, "No auto configuration classes found in META-INF/spring.factories. If you " + "are using a custom packaging, make sure that file is correct.");
    return configurations;
}
```

其中，SpringFactoriesLoader.loadFactoryNames 方法的作用就是从 `META-INF/spring.factories` 文件中读取指定类对应的类名称列表

![image.png](https://b3logfile.com/file/2021/01/image-3346dcac.png)

如下：

```
# Auto Configure
org.springframework.boot.autoconfigure.EnableAutoConfiguration=\
org.springframework.boot.autoconfigure.admin.SpringApplicationAdminJmxAutoConfiguration,\
org.springframework.boot.autoconfigure.aop.AopAutoConfiguration,\
org.springframework.boot.autoconfigure.amqp.RabbitAutoConfiguration,\
org.springframework.boot.autoconfigure.batch.BatchAutoConfiguration,\
org.springframework.boot.autoconfigure.cache.CacheAutoConfiguration,\
```

上面配置文件存在大量的以 Confifiguration 为结尾的类名称，这些类就是存有自动配置信息的类，而 SpringApplication 在获取这些类名后再加载。

我们以 ServletWebServerFactoryAutoConfiguration 为例来分析源码：

```java
@Configuration(proxyBeanMethods = false)
@AutoConfigureOrder(Ordered.HIGHEST_PRECEDENCE)
@ConditionalOnClass(ServletRequest.class)
@ConditionalOnWebApplication(type = Type.SERVLET)
@EnableConfigurationProperties(ServerProperties.class)
@Import({ ServletWebServerFactoryAutoConfiguration.BeanPostProcessorsRegistrar.class,
		ServletWebServerFactoryConfiguration.EmbeddedTomcat.class,
		ServletWebServerFactoryConfiguration.EmbeddedJetty.class,
		ServletWebServerFactoryConfiguration.EmbeddedUndertow.class })
public class ServletWebServerFactoryAutoConfiguration {}
```

其中，`@EnableConfifigurationProperties(ServerProperties.class)` 代表加载 ServerProperties 服务器配置属性类

源码如下：

```java
@ConfigurationProperties(prefix = "server", ignoreUnknownFields = true)
public class ServerProperties {
	private Integer port;
	private InetAddress address;
}
```

其中，`prefifix = "server"` 表示 SpringBoot 配置文件中的前缀，SpringBoot 会将配置文件中以 server 开始的属性映射到该类的字段中。映射关系如下：

![image.png](https://b3logfile.com/file/2021/01/image-884bbd2a.png)

然后查看 spring-boot-autoconfigure 下的 `META-INF/spring-configuration-metadata.json` ,能够发现如下默认配置

```json
{
	"name": "server.port",
	"type": "java.lang.Integer",
	"description": "Server HTTP port.",
	"sourceType": "org.springframework.boot.autoconfigure.web.ServerProperties",
	"defaultValue": 8080
}
```

我们可以自定义配置文件来替换默认配置。

## 4. SpringBoot 的配置文件

SpringBoot 是基于约定的，所以很多配置都有默认值，但如果想使用自己的配置替换默认配置的话，一般使用 application.properties 或者 application.yml（application.yaml）进行配置。

SpringBoot 默认会从 resources 目录下加载 application.properties 或 application.yml（application.yaml）文件

配置信息的查询，上面有提及从源码中查找的方式，也可以从文档查找

文档URL：https://docs.spring.io/spring-boot/docs/2.0.1.RELEASE/reference/htmlsingle/#common-application-properties

常用的配置摘抄如下：

```yaml
# QUARTZ SCHEDULER (QuartzProperties) 
spring.quartz.jdbc.initialize-schema=embedded # Database schema initialization mode. 
spring.quartz.jdbc.schema=classpath:org/quartz/impl/jdbcjobstore/tables_@@platform@@.sql # Path to the SQL file to use to initialize the database schema. 
spring.quartz.job-store-type=memory # Quartz job store type.
spring.quartz.properties.*= # Additional Quartz Scheduler properties.

# ---------------------------------------- 
# WEB PROPERTIES 
# ---------------------------------------- 

# EMBEDDED SERVER CONFIGURATION (ServerProperties) 
server.port=8080 # Server HTTP port. 
server.servlet.context-path= # Context path of the application. 
server.servlet.path=/ # Path of the main dispatcher servlet. 

# HTTP encoding (HttpEncodingProperties) 
spring.http.encoding.charset=UTF-8 # Charset of HTTP requests and responses. Added to the "Content-Type" header if not set explicitly. 

# JACKSON (JacksonProperties) 
spring.jackson.date-format= # Date format string or a fully-qualified date format class name. For instance, `yyyy-MM-dd HH:mm:ss`. 

# SPRING MVC (WebMvcProperties) 
spring.mvc.servlet.load-on-startup=-1 # Load on startup priority of the dispatcher servlet. 
spring.mvc.static-path-pattern=/** # Path pattern used for static resources. 
spring.mvc.view.prefix= # Spring MVC view prefix. 
spring.mvc.view.suffix= # Spring MVC view suffix. 

# DATASOURCE (DataSourceAutoConfiguration & DataSourceProperties) 
spring.datasource.driver-class-name= # Fully qualified name of the JDBC driver. Auto- detected based on the URL by default. 
spring.datasource.password= # Login password of the database. 
spring.datasource.url= # JDBC URL of the database. 
spring.datasource.username= # Login username of the database. 

# JEST (Elasticsearch HTTP client) (JestProperties) 
spring.elasticsearch.jest.password= # Login password. 
spring.elasticsearch.jest.proxy.host= # Proxy host the HTTP client should use. 
spring.elasticsearch.jest.proxy.port= # Proxy port the HTTP client should use. 
spring.elasticsearch.jest.read-timeout=3s # Read timeout. 
spring.elasticsearch.jest.username= # Login username.
```

我们可以通过配置 application.poperties 或者 application.yml 来修改 SpringBoot 的默认配置

例如

```
# application.properties 文件
server.port=8888 
server.servlet.context-path=demo

# application.yml 文件
server: 
  port: 8888 
  servlet: 
    context-path: /demo
```

## 5. 配置文件与配置类的属性映射方式

### 5.1 @Value

我们可以通过 @Value 注解将配置文件中的值映射到一个 Spring 管理的 Bean 的字段上。

例如：

application.yml 配置如下：

```
person: 
  name: zhangsan 
  age: 18
```

实体 Bean 代码如下：

```java
@Controller
public class QuickStartController { 
    @Value("${person.name}") 
    private String name; 
    @Value("${person.age}") 
    private Integer age; 
    
    @RequestMapping("/quick") 
    @ResponseBody public String quick(){ 
        return "springboot 访问成功! name="+name+",age="+age; 
    } 
}
```

### 5.2 @ConfigurationProperties

通过注解 `@ConfifigurationProperties(prefifix="配置文件中的key的前缀")` 可以将配置文件中的配置自动与实体进行映射。

application.yml 配置如下：

```
person: 
  name: zhangsan 
  age: 18
```

实体 Bean 代码如下：

```java
@Controller
@ConfigurationProperties(prefix = "person")
public class QuickStartController { 
    private String name; 
    private Integer age; 
    
    @RequestMapping("/quick") 
    @ResponseBody public String quick(){ 
        return "springboot 访问成功! name="+name+",age="+age; 
    } 
}
```

## 6. SpringBoot 整合其他技术

### 6.1  整合 Mybatis

**添加依赖**

```xml
<!--mybatis起步依赖-->
<dependency>
    <groupId>org.mybatis.spring.boot</groupId>
    <artifactId>mybatis-spring-boot-starter</artifactId>
    <version>1.1.1</version>
</dependency>
<!-- MySQL连接驱动 -->
<dependency>
    <groupId>mysql</groupId>
    <artifactId>mysql-connector-java</artifactId>
</dependency>
```

**配置连接信息**

application.properties

```
#DB Configuration: 
spring.datasource.driverClassName=com.mysql.jdbc.Driver 
spring.datasource.url=jdbc:mysql://127.0.0.1:3306/test?useUnicode=true&characterEncoding=utf8 
spring.datasource.username=root 
spring.datasource.password=root
```

**编写业务**

**在 application.properties 中添加 mybatis 的信息 **

```
#spring集成Mybatis环境 
#pojo别名扫描包 
mybatis.type-aliases-package=com.itheima.domain 
#加载Mybatis映射文件 
mybatis.mapper-locations=classpath:mapper/*Mapper.xml
```

### 6.2 整合 Junit

**添加依赖**

```xml
<!--测试的起步依赖-->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-test</artifactId>
    <scope>test</scope>
</dependency>
```

**编写测试类**

```java
package com.itheima.test;

import com.itheima.MySpringBootApplication;
import com.itheima.domain.User;
import com.itheima.mapper.UserMapper;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = MySpringBootApplication.class)
public class MapperTest {

  @Autowired
  private UserMapper userMapper;

  @Test
  public void test() {
    List<User> users = userMapper.queryUserList();
    System.out.println(users);
  }
}
```

* SpringRunner 继承自 SpringJUnit4ClassRunner，使用哪一个 Spring 提供的测试测试引擎都可以。
* @SpringBootTest 的属性指定的是引导类的字节码对象

### 6.3 整个 Redis

**添加依赖**

```xml
<!-- 配置使用redis启动器 -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-redis</artifactId>
</dependency>
```

**配置连接信息**

```
# Redis 
spring.redis.host=127.0.0.1 
spring.redis.port=6379
```

**测试**

```java
@RunWith(SpringRunner.class)
@SpringBootTest(classes = SpringbootJpaApplication.class)
public class RedisTest {

  @Autowired
  private UserRepository userRepository;

  @Autowired
  private RedisTemplate<String, String> redisTemplate;

  @Test
  public void test() throws JsonProcessingException { //从redis缓存中获得指定的数据
    String userListData = redisTemplate.boundValueOps("user.findAll").get();
    //如果redis中没有数据的话
    if (null == userListData) {
      //查询数据库获得数据
      List<User> all = userRepository.findAll();
      //转换成json格式字符串
      ObjectMapper om = new ObjectMapper();
      userListData = om.writeValueAsString(all);
      //将数据存储到redis中，下次在查询直接从redis中获得数据，不用在查询数据库
      redisTemplate.boundValueOps("user.findAll").set(userListData);
      System.out.println("===============从数据库获得数据===============");
    } else {
      System.out.println("===============从redis缓存中获得数据===============");
    }
    System.out.println(userListData);
  }
}
```

### 6.4 整合 Spring Data JPA

**添加依赖**

```xml
<!-- springBoot JPA的起步依赖 -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-jpa</artifactId>
</dependency>
<!--jdk9需要导入如下坐标-->
<dependency>
    <groupId>javax.xml.bind</groupId>
    <artifactId>jaxb-api</artifactId>
    <version>2.3.0</version>
</dependency>
```

**配置文件**

application.properties

```
#DB Configuration: 
spring.datasource.driverClassName=com.mysql.jdbc.Driver 
spring.datasource.url=jdbc:mysql://127.0.0.1:3306/test?useUnicode=true&characterEncoding=utf8 
spring.datasource.username=root 
spring.datasource.password=root 

#JPA Configuration: 
spring.jpa.database=MySQL 
spring.jpa.show-sql=true 
spring.jpa.generate-ddl=true 
spring.jpa.hibernate.ddl-auto=update 
spring.jpa.hibernate.naming_strategy=org.hibernate.cfg.ImprovedNamingStrategy
```

**创建实体类**

```java
@Entity
public class User {
  // 主键
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id; // 用户名
  private String username; // 密码
  private String password; // 姓名
  private String name;
  //此处省略setter和getter方法... ...
}
```

**编写 UserRepository**

```java
public interface UserRepository extends JpaRepository<User, Long> {
  public List<User> findAll();
}
```

**编写测试类**

```java
@RunWith(SpringRunner.class)
@SpringBootTest(classes = MySpringBootApplication.class)
public class JpaTest {

  @Autowired
  private UserRepository userRepository;

  @Test
  public void test() {
    List<User> users = userRepository.findAll();
    System.out.println(users);
  }
}
```



