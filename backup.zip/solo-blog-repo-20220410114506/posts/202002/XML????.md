title: XML 学习笔记
date: '2020-02-24 03:42:00'
updated: '2021-01-04 18:00:25'
tags: [java, 学习笔记]
permalink: /articles/2020/02/24/1582486920030.html
---
### 1. XML 概念

* Extensible Markup Language 可扩展标记语言。
* 可扩展：标签都是自定义的。
* 功能：存储数据
  * 用于配置文件
  * 用于在网络中传输
* XML 与 HTML 的区别
  * XML 标签都是自定义的，HTML 标签是预定义。
  * XML 的语法严格，HTML 语法松散。
  * XML 是存储数据的，HTML 是展示数据。

### 2. 语法

* 基本语法：
  
  * XML 文档的后缀名 `.xml`
  * XML **第一行**必须定义为文档声明
  * XML 文档中有且仅有一个根标签
  * **属性值**必须使用引号(单双都可)引起来
  * 标签必须正确关闭（有闭合标签或者自闭合）
  * XML 标签名称**区分大小写**
* 快速入门：
  
  ```xml
  <?xml version='1.0' encoding='UTF-8' ?>
  <users>
      <user id='1'>
          <name>zhangsan</name>
          <age>23</age>
          <gender>male</gender>
          <br/>
      </user>
  
      <user id='2'>
          <name>lisi</name>
          <age>24</age>
          <gender>female</gender>
      </user>
  </users>
  ```

### 3. 组成部分

* 文档声明：
  * 格式：`<?xml 属性列表 ?>`
  * 属性列表：
    * version：版本号，必须的属性
    * encoding：编码方式。告知解析引擎当前文档使用的字符集，默认值：ISO-8859-1
    * standalone：是否独立（了解）
      * yes：不依赖其他文件
      * no：依赖其他文件
* 指令（了解）：结合 css 的，现已经不使用
  * `<?xml-stylesheet type="text/css" href="a.css" ?>`，将 XML 像 HTML 一样结合 CSS 将数据展示在网页上面。
* 标签：标签名称自定义的
  * 名称可以包含字母、数字以及其他的字符
  * 名称不能以数字或者标点符号开始
  * 名称不能以字母 xml（或者 XML、Xml 等等）开始
  * 名称不能包含空格
  * `<content:name>` 有冒号的话，前面是命名空间，后边是标签名。标签名是不能有冒号的
* 属性：
  * id 属性值唯一
* 文本
  * CDATA 区：在该区域中的数据会被原样展示，(因为直接写一些符合需要转义，比如大于号，小于号)
    * 格式：` <![CDATA[ 数据 ]]>`

### 4. 约束

* 约束：规定 XML 文档的书写规则。![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-02-23+19:28:12+约束.bmp)
* 作为框架的使用者(程序员)：
  
  * 能够在 XML 中引入约束文档
  * 能够简单的读懂约束文档
* 约束的分类：
  
  * DTD：一种简单的约束技术
  * Schema：一种复杂的约束技术（重点）
    * Schema 约束定义在 `.xsd` 文件中
* 读 DTD （读懂即可，无需编写）
  
  ```
  <!ELEMENT students (student*) >
  <!ELEMENT student (name,age,sex)>
  <!ELEMENT name (#PCDATA)>
  <!ELEMENT age (#PCDATA)>
  <!ELEMENT sex (#PCDATA)>
  <!ATTLIST student number ID #REQUIRED>
  
  第一行表示：students 为根标签，标签中可以包含0个或多个 student 标签
  第二行表示：student 标签中有三个标签，分别为 name、age、sex
  第三行表示：name 标签中有一个字符串
  最后一行表示：student 标签有一个属性 number，number的类型为 ID (唯一的)，且 ID 是必须有的
  ```
* DTD的引入：
  
  * 外部 DTD：将约束的规则定义在外部的 `.dtd` 文件中，通过下面语句引入
    * 本地：`<!DOCTYPE 根标签名 SYSTEM "dtd文件的位置">`
    * 网络：`<!DOCTYPE 根标签名 PUBLIC "dtd文件名字" "dtd文件的位置URL">`
  * 内部 DTD：将约束规则定义在 XML 文档中（了解即可）
    * `<!DOCTYPE students [ DTD约束内容 ]>`
* DTD 的缺点：规定不了字符串的内容，没办法约束，Schema 可以约束。
* 读 Schema （简单读懂即可）
  
  ```xml
  <?xml version="1.0"?>
  <xsd:schema xmlns="http://www.itcast.cn/xml"
          xmlns:xsd="http://www.w3.org/2001/XMLSchema"
          targetNamespace="http://www.itcast.cn/xml" elementFormDefault="qualified">
  	<!-- 定义根元素students,类型为studentsType  -->	
      <xsd:element name="students" type="studentsType"/>
  	<!-- 说明复杂类型studentsType  -->
      <xsd:complexType name="studentsType">
          <xsd:sequence>
  			<!-- studentsType类型的标签中顺序出现student(类型为studentType)，最少出现0次，最多无限制 -->
              <xsd:element name="student" type="studentType" minOccurs="0" maxOccurs="unbounded"/>
          </xsd:sequence>
      </xsd:complexType>
  	<!-- 说明复杂类型studentType  -->
      <xsd:complexType name="studentType">
          <xsd:sequence>
  			<!-- studentType类型的标签中顺序出现name(string类型)、age(ageType类型)、sex(sexType类型) -->
              <xsd:element name="name" type="xsd:string"/>
              <xsd:element name="age" type="ageType" />
              <xsd:element name="sex" type="sexType" />
          </xsd:sequence>
  		<!-- 此类型的标签(student标签)有一个必须的属性number(类型为numberType) -->
          <xsd:attribute name="number" type="numberType" use="required"/>
      </xsd:complexType>
  	<!-- 说明简单类型sexType，为string类型，值为枚举male,female -->
      <xsd:simpleType name="sexType">
          <xsd:restriction base="xsd:string">
              <xsd:enumeration value="male"/>
              <xsd:enumeration value="female"/>
          </xsd:restriction>
      </xsd:simpleType>
  	<!-- 说明简单类型ageType，为integer类型，最小值为0，最大值为256 -->
      <xsd:simpleType name="ageType">
          <xsd:restriction base="xsd:integer">
              <xsd:minInclusive value="0"/>
              <xsd:maxInclusive value="256"/>
          </xsd:restriction>
      </xsd:simpleType>
  	<!-- 说明简单类型numberType，为string类型，符合正则表达式value -->
      <xsd:simpleType name="numberType">
          <xsd:restriction base="xsd:string">
              <xsd:pattern value="heima_\d{4}"/>
          </xsd:restriction>
      </xsd:simpleType>
  </xsd:schema>
  ```
* Schema 的引入
  
  * 填写 XML 文档的根元素
  * 定义 xsi 开头的命名空间，`xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"`
  * 为每一个 xsd 约束声明一个前缀，作为标识
  * 引入 xsd 文件命名空间，`xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd"`
  * ```xml
    <?xml version="1.0" encoding="UTF-8"?>
    <beans xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
           xmlns="http://www.springframework.org/schema/beans"
           xmlns:mvc="http://www.springframework.org/schema/mvc"
           xsi:schemaLocation="
            http://www.springframework.org/schema/beans
            http://www.springframework.org/schema/beans/spring-beans.xsd
            http://www.springframework.org/schema/mvc
            http://www.springframework.org/schema/mvc/spring-mvc.xsd">
    ```
  
  ---
  
  * xmlns：XML Name Space，命名空间
  * 命名空间：首先介绍一下 XML 中标签的命名空间的概念。
    命名空间就是标签的前缀，没有前缀的标签，使用的是默认的命名空间。
    命名空间是用来解决标签命名冲突的（多个名字相同的标签在不同的约束文件中）。
    指定一个标签的命名空间：命名空间 + 冒号(:) + 标签名，如`<mvc:name>`
    每一个命名空间都需要有一个 xsd （XML Schema Definition）文件与之对应。
  * 默认命名空间，就是 `xlmns=""` ，如果未声明，默认值为 `http://www.w3.org/2000/xmlns/`，没有前缀的标签使用的就是默认命名空间。
  * `xmlns:xsi`：定义了以 xsi 开头的命名空间，如果值是 `http://www.w3.org/2001/XMLSchema-instance`，该命名空间就可以在 XML 文件中直接使用，而无需指定 xsd 文件，是标准核心命名空间之一，xsi 前缀可以更改成别的字符串。
  * xmlns:xyz：用来定义具有前缀（xyz）的命名空间，为了使命名空间不发生命名上的冲突，一般都采用网址的形式，作为命名空间的值，使用前缀作为命名空间的简写。
  * 命名空间的前缀不能为 xml。
  * `xsi:schemaLocation`：schemaLocation 是 `http://www.w3.org/2001/XMLSchema-instance` 命名空间下的属性，这个属性定义了除了该命名空间外的其他命名空间与其 xsd 文件的位置，格式为 `命名空间 命名空间的 xsd 文件`。
  * xsd 文件中的 targetNamespace 属性：该属性声明了本 XML Schema 文档中定义的元素是属于 targetNamespace 属性指定的命名空间(URI)下的。
  * xml 使用 schema 约束的时候，要想让约束起作用，xml 中与此 xsd 文件对应的命名空间的值需要与 xsd 文件中的 targetNamespace 属性的值一样。

### 5. 解析

* 解析：操作 XML 文档，将文档中的数据读取到内存中。
* 操作 XML 文档：
  
  * 解析(读取)：将文档中的数据读取到内存中。
  * 写入：将内存中的数据保存到 XML 文档中。持久化的存储。
* 解析 XML 的方式：
  
  * DOM：将标记语言文档一次性加载进内存，在内存中形成一颗 DOM 树
    * 优点：操作方便，可以对文档进行CRUD的所有操作
    * 缺点：占内存
  * SAX：逐行读取，基于事件驱动的。
    * 优点：不占内存。
    * 缺点：只能读取，不能增删改。
* XML 常见的解析器：
  
  * JAXP：SUN 公司提供的解析器，支持 DOM 和 SAX 两种思想。
  * DOM4J：一款非常优秀的解析器。
  * Jsoup：jsoup 是一款Java 的HTML解析器，可直接解析某个URL地址、HTML文本内容。它提供了一套非常省力的API，可通过DOM，CSS以及类似于jQuery的操作方法来取出和操作数据。可以用来解析 XML。
  * PULL：Android操作系统内置的解析器，SAX 方式的。
* Jsoup 的使用步骤：
  
  * 导入 jar 包
  * 获取 Document 对象
  * 获取对应的标签 Element 对象
  * 获取数据
  * ```java
    import org.jsoup.Jsoup;
    import org.jsoup.nodes.Document;
    import org.jsoup.nodes.Element;
    import org.jsoup.select.Elements;
    
    import java.io.File;
    import java.io.IOException;
    
    public class JsoupDemo1 {
        public static void main(String[] args) throws IOException {
            //2.获取Document对象，根据xml文档获取
            //2.1获取student.xml的path
            String path = JsoupDemo1.class.getClassLoader().getResource("students.xml").getPath();
            //2.2解析xml文档，加载文档进内存，获取dom树--->Document
            Document document = Jsoup.parse(new File(path), "utf-8");
            //3.获取元素对象 Element
            Elements elements = document.getElementsByTag("name");
    
            System.out.println(elements.size());
            //3.1获取第一个name的Element对象
            Element element = elements.get(0);
            //3.2获取数据
            String name = element.text();
            System.out.println(name);
        }
    }
    ```
* Jsoup：工具类，可以解析 HTML 或 XML 文档，返回 Document
  
  * `parse(File in, String charsetName)`：解析 xml 或 html 文件，加载文档进内存，获取 DOM 树
  * `parse(String html)`：解析 xml 或 html 字符串，字符串即为 xml 或 html 文档中的内容，不常用
  * `parse(URL url, int timeoutMillis)`：通过网络路径获取指定的 html 或 xml 的文档
    * URL 可通过 `new URL("网址")` 来获取
* Document：文档对象。代表内存中的 DOM 树，继承 Element，下面方法来自 Element
  
  * `getElementById(String id)`：根据 id 属性值获取唯一的 element 对象，多用于解析 HTML
  * `getElementsByTag(String tagName)`：根据标签名称获取元素对象集合
  * `getElementsByAttribute(String key)`：根据属性名称获取元素对象集合
  * `getElementsByAttributeValue(String key, String value)`：根据对应的属性名和属性值获取元素对象集合
* Elements：元素 Element 对象的集合。继承 `ArrayList<Element>`
* Element：元素对象
  
  * 获取子对象，只能获取此元素下面的子元素对象
    * `getElementById(String id)`：根据 id 属性值获取唯一的 element 对象
    * `getElementsByTag(String tagName)`：根据标签名称获取元素对象集合
    * `getElementsByAttribute(String key)`：根据属性名称获取元素对象集合
    * `getElementsByAttributeValue(String key, String value)`：根据对应的属性名和属性值获取元素对象集合
  * 获取属性值：
    * `String attr(String key)`：根据属性名称获取属性值
  * 获取文本内容：
    * `String text()`：获取所有字标签的纯文本内容
    * `String html()`：获取标签体的所有内容(包括子标签的标签和文本内容)，类似于 innerHTML
* Node：节点对象
  
  * 是 Document 和 Element 的父类，包含了很多有关增删改的方法
* 快捷查询方式：selector选择器
  
  * 使用方法：`Elements select(String cssQuery)`，是 Element 中的对象，一般用 document 来调用，查询整个文档，因为 Document extends Element
  * 参数：与 CSS 选择器类似，参考 Selector 类中定义的语法
  * ```java
    import org.jsoup.Jsoup;
    import org.jsoup.nodes.Document;
    import org.jsoup.nodes.Element;
    import org.jsoup.select.Elements;
    
    import java.io.File;
    import java.io.IOException;
    
    public class JsoupDemo5 {
        public static void main(String[] args) throws IOException {
            //1.获取student.xml的path
            String path = JsoupDemo5.class.getClassLoader().getResource("student.xml").getPath();
            //2.获取Document对象
            Document document = Jsoup.parse(new File(path), "utf-8");
    
            //3.查询name标签
            Elements elements = document.select("name");
            System.out.println(elements);
            //4.查询id值为itcast的元素
            Elements elements1 = document.select("#itcast");
            System.out.println(elements1);
            //5.获取student标签并且number属性值为heima_0001的age子标签
            //5.1.获取student标签并且number属性值为heima_0001
            Elements elements2 = document.select("student[number=\"heima_0001\"]");
            System.out.println(elements2);
            //5.2获取student标签并且number属性值为heima_0001的age子标签
            Elements elements3 = document.select("student[number=\"heima_0001\"] > age");
            System.out.println(elements3);
        }
    }
    ```
* 快捷查询方式：Xpath
  
  * Xpath：XPath 即为 XML 路径语言，它是一种用来确定 XML（标准通用标记语言的子集）文档中某部分位置的语言。
  * 使用 Jsoup 的 Xpath 需要额外导入 jar 包。
  * 查询 w3cshool 参考手册，使用 Xpath 的语法完成查询。
  * ```java
    import cn.wanghaomiao.xpath.exception.XpathSyntaxErrorException;
    import cn.wanghaomiao.xpath.model.JXDocument;
    import cn.wanghaomiao.xpath.model.JXNode;
    import org.jsoup.Jsoup;
    import org.jsoup.nodes.Document;
    import org.jsoup.select.Elements;
    
    import java.io.File;
    import java.io.IOException;
    import java.util.List;
    
    public class JsoupDemo6 {
        public static void main(String[] args) throws IOException, XpathSyntaxErrorException {
            //1.获取student.xml的path
            String path = JsoupDemo6.class.getClassLoader().getResource("student.xml").getPath();
            //2.获取Document对象
            Document document = Jsoup.parse(new File(path), "utf-8");
            //3.根据document对象，创建JXDocument对象
            JXDocument jxDocument = new JXDocument(document);
            //4.结合xpath语法查询
            //4.1查询所有student标签
            List<JXNode> jxNodes = jxDocument.selN("//student");
            for (JXNode jxNode : jxNodes) {
                System.out.println(jxNode);
            }
            //4.2查询所有student标签下的name标签
            List<JXNode> jxNodes2 = jxDocument.selN("//student/name");
            for (JXNode jxNode : jxNodes2) {
                System.out.println(jxNode);
            }
            //4.3查询student标签下带有id属性的name标签
            List<JXNode> jxNodes3 = jxDocument.selN("//student/name[@id]");
            for (JXNode jxNode : jxNodes3) {
                System.out.println(jxNode);
            }
            //4.4查询student标签下带有id属性的name标签 并且id属性值为itcast
            List<JXNode> jxNodes4 = jxDocument.selN("//student/name[@id='itcast']");
            for (JXNode jxNode : jxNodes4) {
                System.out.println(jxNode);
            }
        }
    }
    ```
* pull 解析：安卓用的 pull 解析，和 sax 方式类似，一行一行读取，用于读取 xml，不能修改 xml，内置 `next()` 方法，可以主动结束事件处理，sax 方式不能控制结束，只能读完文档。
  
  * kxml 解析 xml，所需 jar 包：kxml + xmlpull
  * ```java
    public void pullTest() throws Exception {
        ArrayList<Book> books = null;
        Book book = null;
        // 获取工厂
        XmlPullParserFactory parserFactory = XmlPullParserFactory.newInstance();
        // 获取到xml的解析器
        XmlPullParser parser = parserFactory.newPullParser();
        // 给解析器设置一个输入源
        // 第一个参数输入流 第二个参数 文档用到的字符编码集
        parser.setInput(new FileInputStream(new File("book.xml")), "utf-8");
        // 获取当前事件类型
        int eventType = parser.getEventType();
        boolean flag = true;
        while (eventType != XmlPullParser.END_DOCUMENT && flag) {
            switch (eventType) {
                case XmlPullParser.START_TAG:
                    //开始标签
                    //parser.getName 获取当前事件对应的元素名字
                    if ("书架".equals(parser.getName())) {
                        //创建一个集合
                        books = new ArrayList<>();
                    } else if ("书".equals(parser.getName())) {
                        //创建一个book 对象
                        book = new Book();
                    } else if ("书名".equals(parser.getName())) {
                        //给book 对象设置书名的属性
                        book.setTitle(parser.nextText()); //parser.nextText()获取当前节点的下一个文本内容
                    } else if ("作者".equals(parser.getName())) {
                        //给book 对象设置作者的属性
                        book.setAuthor(parser.nextText());
                    } else if ("售价".equals(parser.getName())) {
                        //给book 对象设置售价的属性
                        book.setPrice(parser.nextText());
                    }
                    break;
                case XmlPullParser.END_TAG:
                    //结束标签
                    if ("书".equals(parser.getName())) {
                        //把book 对象添加到集合中
                        books.add(book);
                        flag = false;
                    }
                    break;
            }
    
            // 调用parser.next方法解析下一个元素 用这个结果来更新eventType 如果解析到文档结束那么就会推出循环
            // 如果不更新这个eventType 就是死循环
            eventType = parser.next();
        }
    
        //遍历集合
        for (Book book1 : books) {
            System.out.println(book1);
        }
    }
    ```



