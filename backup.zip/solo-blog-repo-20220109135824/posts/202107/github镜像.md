title: github 镜像
date: '2021-07-20 14:24:51'
updated: '2021-07-20 14:24:51'
tags: [git]
permalink: /articles/2021/07/20/1626762290965.html
---
### github 镜像

| 名称         | 地址                           |
| :----------- | :----------------------------- |
| fastgit.org  | https://doc.fastgit.org/       |
| gitclone.com | https://gitclone.com/          |
| gitee        | https://gitee.com/mirrors      |
| cnpmjs.org   | https://github.com.cnpmjs.org/ |



