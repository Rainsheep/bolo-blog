title: java 时间
date: '2022-03-15 14:35:30'
updated: '2022-03-15 14:35:30'
tags: [java]
permalink: /articles/2022/03/15/1647326130371.html
---
# 1. 名词解释

## 1.1 UTC

Coordinated Universal Time协调世界时, 是个世界标准时间。

## 1.2 GMT

GMT（Greenwich Mean Time，格林威治时间)是时区时间。

GMT = UTC +0, 和 UTC 的值是一样的。

```
Tue Mar 15 03:25:32 GMT 2022
```

## 1.3 CST

北京时间，CST = GMT + 8

```
Tue Mar 15 11:27:12 CST 2022
```

## 1.4 T

连接 date 和 time 的字符，没有意义。

```
2022-03-15T03:27:12.556410
```

# 2. 时区问题

> 使用 Java 处理时间时，我们可能会经常发现时间不对，比如相差 8 个小时等等，其真实原因便是 TimeZone。只有正确合理的运用 TimeZone，才能保证系统时间无论何时都是准确的。

上文提到的 gmt 和 cst 就是时区。

## 2.1 timestamp

我们先说下时间戳

```java
Date date = new Date();
Date date2 = Calendar.getInstance().getTime();
long time = date.getTime();
```

Date 对象本身所存储的毫秒数可以通过 date.getTime() 方法得到；该函数返回自 1970年1月1日 00:00:00 GMT 以来此对象表示的毫秒数。**它与时区和地域没有关系(其实可以认为是GMT时间)**

## 2.2 TimeZone

TimeZone 对象给我们的是原始的偏移量，也就是与 GMT 相差的微秒数，即 TimeZone 表示时区偏移量，本质上以毫秒数保存与 GMT 的差值。

获取 TimeZone 可以通过时区 ID，如 "America/New_York"，也可以通过 GMT+/-hh:mm 来设定，例如北京时间可以表示为 GMT+8:00。

TimeZone.getRawOffset() 方法可以用来得到当前时区的标准时间到 GMT 的偏移量。上段提到的 "America/New_York" 和  "GMT+8:00" 两个时区的偏移量分别为 -18000000 和 28800000。

```java
TimeZone timeZone = TimeZone.getTimeZone("GMT+8");
TimeZone timeZone1 = TimeZone.getTimeZone("GMT+8:00");
TimeZone timeZone2 = TimeZone.getTimeZone("Asia/Shanghai");
System.out.println(timeZone2.getRawOffset());
```

## 2.2 Calendar

Calendar 是两个和时区相关的东西，Calendar 的 getInstance() 方法有参数为 TimeZone 和 Locale 的重载，可以使用指定时区和语言环境获得一个日历。无参则使用默认时区和语言环境(系统默认，从系统获取)获得日历。

### 2.2.1 Locale 对 Calendar 的影响

Locale 对 calendar 时间没什么影响，我们一般用不到，影响体现在下面两个地方。

1. Locale 使 DateFormat 按所配置的地区特性来输出文字(例如中国,美国,法国不同地区对日期的表示格式不一样, 中国可能是2001年10月5日)
2. Local 对 calendar.getFirstDayOfWeek() 有影响，不用地区的每周第一天是不相同的，美国是周末，法国是周一。

### 2.2.2 TimeZone 对 Calendar 的影响

TimeZone 对 Calendar 获取到的时间有直接的影响，最常见的就是 8 小时问题。

```java
Date date = new Date(1391174450000L); // 2014-1-31 21:20:50
System.out.println(date); // Fri Jan 31 21:20:50 CST 2014

Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
calendar.setTime(date);
System.out.println(calendar.get(Calendar.HOUR_OF_DAY) + ":" + calendar.get(Calendar.MINUTE)); // 13:20
```

可以看到，首先我们使用 系统时区来获取时间，获取到 CST 时间，然后使用 GMT 获取时间，两个时间差了 8 个 小时。

我们可以在项目中设置统一时区，来防止不同操作系统造成时区差。

> 设置完时区后，我们不能用 calendar.getTime() 来直接获取 Date 日期，因为此时的日期与一开始 setTime 时是相同值，要想获取某时区的时间，正确的做法是用 calendar.get() 方法。

## 2.3 Date

上文我们好几处用到了 Date 对象，Date 本身是没有时区概念的，就是一个时间戳。

但我们将 Date 格式化字符串和将字符串解析为 Date 对象的时候，是涉及到时区概念的。

**格式化 Date 为字符串**

```java
Date date = new Date();
// 默认是系统时区
System.out.println(date); // Tue Mar 15 14:04:01 CST 2022
// 修改默认时区
TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
System.out.println(date);  // Tue Mar 15 06:04:01 GMT 2022

Date date1 = new Date();
// 默认是系统时区
SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
System.out.println(dateFormat.format(date1)); // 2022-03-15 06:05:08
// 设置时区
dateFormat.setTimeZone(TimeZone.getTimeZone("GMT+1:00"));
System.out.println(dateFormat.format(date1)); // 2022-03-15 07:05:08
```

**解析字符串为 Date**

```java
String dateStr = "2019-12-10 08:00:00";
// 默认是系统时区
SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
Date date1 = dateFormat.parse(dateStr);
System.out.println(date1.getTime()); // 1575936000000

// 设置时区
dateFormat.setTimeZone(TimeZone.getTimeZone("GMT+1:00"));
Date date2 = dateFormat.parse(dateStr);
System.out.println(date2.getTime()); // 1575961200000
```

> 可见时区不同，解析出的时间戳是不相同的

# 3. DateTimeFormatter

参考：[【Java 8 新特性】Java DateTimeFormatter 日期时间格式化器](https://blog.csdn.net/qq_31635851/article/details/120132776)

我们之前使用 SimpleDateFormat 来格式化日期，java 8 之后，可使用 DateTimeFormatter。它是不可变的，且线程安全。

SimpleDateFormat 线程不安全。

```java
DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MMM-dd HH:mm:ss"); 
// 格式化
String dateTime = formatter.format(LocalDateTime.now());
System.out.println(dateTime); //2018-Dec-21 11:14:12 
// 解析
LocalDateTime ldt = LocalDateTime.parse("2018-Dec-20 08:25:30", formatter);
System.out.println(ldt); //2018-12-20T08:25:30
```

# 4. LocalDateTime

参考：[再也不为日期烦恼——LocalDate的使用](https://blog.csdn.net/u011055819/article/details/80070429)

java 8 新特性

* LocalDate: 只对年月日处理
* LocalTime：只对时分秒纳秒处理
* LocalDateTime：同时处理年月日时分秒

基础用法：

```java
LocalDateTime today = LocalDateTime.now();
int dayOfMonth = today.getDayOfMonth();
String date = today.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
```

LocalDate 更加强大的地方还没展示：

```java
// 取本月第1天：
		LocalDate firstDayOfThisMonth = today.with(TemporalAdjusters.firstDayOfMonth()); // 2018-04-01
		// 取本月第2天：
		LocalDate secondDayOfThisMonth = today.withDayOfMonth(2); // 2018-04-02
		// 取本月最后一天，再也不用计算是28，29，30还是31：
		LocalDate lastDayOfThisMonth = today.with(TemporalAdjusters.lastDayOfMonth()); // 2018-04-30
		// 取下一天：
		LocalDate firstDayOfNextMonth = lastDayOfThisMonth.plusDays(1); // 变成了2018-05-01
		// 取2017年1月第一个周一：
		LocalDate firstMondayOf2017 = LocalDate.parse("2017-01-01").with(TemporalAdjusters.firstInMonth(DayOfWeek.MONDAY)); // 2017-01-02
```



