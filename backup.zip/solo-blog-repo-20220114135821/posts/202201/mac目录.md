title: mac 目录
date: '2022-01-14 13:52:44'
updated: '2022-01-14 13:52:44'
tags: [mac]
permalink: /articles/2022/01/14/1642139564007.html
---
* /bin : bin 是 binary 的简写，主要是一些系统必备的工具比如，cp, ls, mv, rm, sh 等
* /sbin : sbin 是管理员用于管理系统的一些必备命令，比如常用的，ifconfig, mount, reboot, shutdown 等
* /usr : 目录下面的基本都是系统自带第三方和用户安装的第三方软件的安装目录
* /usr/bin : 用户和管理员都需要用到的一些第三方软件
* /usr/sbin : 管理员可以用到的一些第三方的软件
* /usr/local : 用户自己安装的一些第三方软件所在位置
* /usr/local/bin : 此目录下一般都是用户自己安装的一些软件的二进制文件入口
* /usr/local/etc : 一些第三方软件的配置信息，比如说 nginx，就在此目录：/usr/local/etc/nginx
* /etc : 用于存放系统配置文件的地方，如用户密码文件 /etc/passwd，目录指向的实际目录是：/private/etc
* /tmp : 临时文件存放目录，其权限为所有人任意读写。目录指向的实际目录是  /private/tmp
* /var : 存放经常变化的文件，如日志文件，目录指向的实际目录是 /private/var
* /Applications : 基本一些 gui 应用程序都在此目录
* /Users : 用户目录，存放用户的一些文档，资料信息
* /System : 只包含一个名为 Library 的目录，这个子目录中存放了系统的绝大部分组件，如各种 framework，以及内核模块，字体文件等等。
* /Library : 系统的数据文件、帮助文件、文档等等

