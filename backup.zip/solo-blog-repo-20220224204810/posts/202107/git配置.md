title: git 配置
date: '2021-07-29 17:45:13'
updated: '2021-07-29 17:45:13'
tags: [git]
permalink: /articles/2021/07/29/1627551913784.html
---
### ssh 配置

**生成秘钥**

在 `~/.ssh` 下，如果没有 id_rsa, id_rsa.pub 两个文件

```
ssh-keygen -t rsa -C "username"
```

* 此 username 可以是任意字符串，服务端用此字符串来作为公钥的 key，没啥实际作用。
* 然后将公钥 pub 添加到服务端，连接的时候服务端会根据 key 去寻找对应的公钥用来解密认证。

**对不同服务器使用不同秘钥（选）**

在 `~/.ssh/config` 配置

```
host gerrit
    user USERNAME
    hostname gerrit.test.com
    port 29418
    identityfile ~/.ssh/id_rsa
host gerrit-mirror
    user USERNAME
    hostname gerrit-mirror.test.com
    port 29418
    identityfile ~/.ssh/id_rsa
```

### 认证方式

一般来说，认证方式 有 ssh 和 http 两种，ssh 用秘钥认证。
https 则用账号密码，或者个人令牌认证，个人令牌一般可以在服务端生成。

### git 配置

参考：[git config配置](https://www.cnblogs.com/fireporsche/p/9359130.html)

#### git 配置优先级

3 类：

* 仓库级别 local 【优先级最高】
* 用户级别 global【优先级次之】
* 系统级别 system【优先级最低】

我们一般使用 global 就好

git 仓库级别对应的配置文件是对应仓库下的 `.git/config`

git 用户级别对应的配置文件是用户宿主目录下的 `~/.gitconfig`

git 系统级别对应的配置文件是 git 安装目录下的 `/etc/gitconfig`

#### 查看 git 配置

* `git config --local -l` 查看仓库配置，必须要进入到具体的目录下
* `git config --global -l` 查看用户配置
* `git config --system -l` 查看系统配置
* `git config -l` 查看所有配置，依次是系统级别、用户级别、仓库级别

#### 常用配置选项

- git config -e 编辑配置文件
  
  - git config --local -e 编辑仓库级别配置文件
  - git config --global -e 编辑用户级别配置文件
  - git config --system -e 编辑系统级别配置文件
- git config 添加配置项目
  
  ```
  git config --global user.email “you@example.com”
  git config --global user.name “Your Name”
  ```

#### 增加配置项

```
git config [--local|--global|--system] --add section.key value
```

#### 获取配置项

```
git config [--local|--global|--system] --get section.key
```

#### 删除配置项

```
git config [--local|--global|--system] --unset section.key
```



