title: 使用 Maven 插件为 SpringBoot 应用构建 Docker 镜像
date: '2021-10-25 13:35:13'
updated: '2021-10-25 13:35:13'
tags: [maven, springboot]
permalink: /articles/2021/10/25/1635140113377.html
---
参考文档：

[使用Maven插件为SpringBoot应用构建Docker镜像](http://www.macrozheng.com/#/reference/docker_maven)
[Docker 在 Mac 下的 2375 端口](https://blog.csdn.net/poxiao58/article/details/115456455?spm=1001.2101.3001.6650.1&utm_medium=distribute.pc_relevant.none-task-blog-2%7Edefault%7ECTRLIST%7Edefault-1.no_search_link&depth_1-utm_source=distribute.pc_relevant.none-task-blog-2%7Edefault%7ECTRLIST%7Edefault-1.no_search_link)
[Docker开启Remote API 访问 2375端口](https://www.cnblogs.com/hongdada/p/11512901.html)

## 1. 创建私有镜像仓库

```
docker run -d -p 5000:5000 --restart=always --name registry2 registry:2
```

## 2. Docker 开启远程 api

**Linux**

修改 `daemon.json` 的配置

```shell
vim /etc/docker/daemon.json

{
  "hosts": ["tcp://0.0.0.0:2375", "unix:///var/run/docker.sock"]
}
```

重启 docker 服务

**mac**

处于安全原因，Docker Mac 客户端并没有开启 2375 端口的配置，我们可以用 socat 来 fork 一个端口出来执行

```
docker run -it -d --name=socat -p 2375:2375 -v    /var/run/docker.sock:/var/run/docker.sock bobrik/socat TCP4-LISTEN:2375,fork,reuseaddr UNIX-CONNECT:/var/run/docker.sock
```

重启 docker 服务

## 3. 使用 maven 构建镜像

**添加 docker-maven-plugin 依赖**

```xml
<plugin>
    <groupId>com.spotify</groupId>
    <artifactId>docker-maven-plugin</artifactId>
    <version>1.1.0</version>
    <executions>
        <execution>
            <id>build-image</id>
            <phase>package</phase>
            <goals>
                <goal>build</goal>
            </goals>
        </execution>
    </executions>
    <configuration>
        <imageName>mall-tiny/${project.artifactId}:${project.version}</imageName>
        <dockerHost>http://192.168.3.101:2375</dockerHost>
        <baseImage>java:8</baseImage>
        <entryPoint>["java", "-jar","/${project.build.finalName}.jar"]
        </entryPoint>
        <resources>
            <resource>
                <targetPath>/</targetPath>
                <directory>${project.build.directory}</directory>
                <include>${project.build.finalName}.jar</include>
            </resource>
        </resources>
    </configuration>
</plugin>
```

相关配置说明：

- executions.execution.phase: 此处配置了在 maven 打包应用时构建 docker 镜像；
- imageName：用于指定镜像名称，mall-tiny 是仓库名称，`${project.artifactId}` 为镜像名称，`${project.version}` 为镜像版本
- dockerHost：打包后上传到的 docker 服务器地址；
- baseImage：该应用所依赖的基础镜像，此处为 java；
- entryPoint：docker 容器启动时执行的命令；
- resources.resource.targetPath：将打包后的资源文件复制到该目录；
- resources.resource.directory：需要复制的文件所在目录，maven 打包的应用 jar 包保存在 target 目录下面；
- resources.resource.include：需要复制的文件，打包好的应用 jar 包。

然后 package maven 即可

