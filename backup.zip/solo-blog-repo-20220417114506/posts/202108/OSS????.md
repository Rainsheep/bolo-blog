title: OSS 搭建图床
date: '2021-08-03 23:10:10'
updated: '2021-08-03 23:10:10'
tags: [软件教程]
permalink: /articles/2021/08/03/1628003410168.html
---
参考文档：

[PicGo+Github 图床](https://www.rainsheep.cn/articles/2020/01/01/1577855003862.html)

[作为过来人的我是如何写博客的？](https://caochenlei.blog.csdn.net/article/details/109752298)

[整合篇：零基础学习与使用OSS](https://caochenlei.blog.csdn.net/article/details/113006985)

### 背景

很早就想用 oss 搭个图床了，但一直不想折腾。。。直到现在，看到了大佬的博客，突然发现 picgo 和 typora 还能这样配合，搞一个。

以前用 picgo+github 搭建过一个图床，但奈何 github 容量限制和网速原因，放弃了，一直使用 solo 官方的 oss，还是有点不方便的。

大佬使用 gitee 作为图床，不用考虑网速原因了，但 1m 限制和防盗链的风险，算了。

我还是买一个 oss 吧，去阿里云一看。。。。 真 tmd 的便宜。

### oss 购买

购买教程参考 [整合篇：零基础学习与使用OSS](https://caochenlei.blog.csdn.net/article/details/113006985)

登录阿里云官网，开通 对象存储 OSS，然后购买资源包，资源包类型选 标准(LRS)存储包就行，大小和时长自己选，我买了 5 年 40G ,50 大洋。

### OSS 配置

**获取 AccessKey**

RAM 控制台 -> 用户 -> 创建用户 -> 勾选编程访问

访问密钥，只显示一次，请记录。

> 注意：AccessKey Secret 只在创建时显示，不提供查询，请妥善保管。如果 AccessKey 泄露或丢失，则需要创建新的 AccessKey，最多可以创建2个 AccessKey。

**授权**

授予此用户 管理对象存储服务(OSS)权限 和 只读访问对象存储服务(OSS)权限权限。

**创建 Bucket**

你可以理解这个存储空间（Bucket）就像我们电脑上的一块块的硬盘（C盘、D盘），只不过这是阿里云以云服务的形式提供我们可以自己规划使用的。

下图仅供参考，根据自己需求选。

![50814a634bc43dc3fdc838d6e7e34576](https://b3logfile.com/file/2021/08/solo-fetchupload-5011424378222511909-1f4243cc.png)

**创建存储目录**

在此 Bucket 下创建一个 blog 文件夹，存储博客图片。

**绑定域名**

此操作可选，也可以不做。

根据官方文档 传输管理 -> 域名管理，绑定域名 -> 上传 https 证书即可。

### PicGo 配置

![image-20210803230137860](https://b3logfile.com/file/2021/08/solo-fetchupload-3796087767860101395-42f76748.png)

* KeyId 和 KeySecret 上面有说明
* 存储空间名即为创建的 Bucket 名字
* 指定存储路径为创建的文件夹名

![image-20210803230341501](https://b3logfile.com/file/2021/08/solo-fetchupload-2508744909803925092-0a72cac2.png)

PicGo -> 设置 Server 打开

![image-20210803230449338](https://b3logfile.com/file/2021/08/solo-fetchupload-4839345326899145890-26dff531.png)

**关于 oss 文件名重复的解决方案**

> OSS  上传的文件名肯定是不能重复的

安装 rename-file 插件，重写 上传的图片的文件名

![image-20210803230557142](https://b3logfile.com/file/2021/08/solo-fetchupload-580399718165698233-bd88e6ff.png)

根据自己需求配置，具体参考插件文档

![image-20210803230639798](https://b3logfile.com/file/2021/08/solo-fetchupload-6146015814974467937-01ed295f.png)

### Typora 配置

![image-20210803230807186](https://b3logfile.com/file/2021/08/solo-fetchupload-6639326731356365657-41d95a6a.png)

配置完之后，点击验证图片上传选项，看是否成功。

好了，现在写博客的时候，直接把图片拉到 typora 即可自动上传，舒服了。

