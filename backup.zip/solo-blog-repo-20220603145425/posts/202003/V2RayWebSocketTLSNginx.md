title: V2Ray+WebSocket+TLS+Nginx
date: '2020-03-11 12:42:27'
updated: '2022-06-02 23:23:27'
tags: [Shadowsocks, ss]
permalink: /articles/2020/03/11/1583901747768.html
---
## 安装 V2Ray

提前准备：

1. 1台VPS，如搬瓦工、谷歌云、Vultr等。
2. 1个域名，付费（推荐Namesilo）或免费申请Freenom，之后解析到你的VPS IP上。
   脚本适用于：Debian 9+ / Ubuntu 18.04+ / Centos7+

### 一、一键脚本安装 V2Ray+WebSocket+TLS+Nginx

Vmess+websocket+TLS+Nginx+Website：

```shell
wget -N --no-check-certificate -q -O install.sh "https://raw.githubusercontents.com/wulabing/V2Ray_ws-tls_bash_onekey/master/install.sh" && chmod +x install.sh && bash install.sh
```

### 二、BBR

参考：https://www.jianshu.com/p/09069a354f02

> 内核要求: 5.5, centos 7.6

#### 2.1 安装内核

安装 elrepo 并升级内核

```
rpm --import https://www.elrepo.org/RPM-GPG-KEY-elrepo.org
yum install https://www.elrepo.org/elrepo-release-7.el7.elrepo.noarch.rpm
yum --enablerepo=elrepo-kernel install kernel-ml -y
```

安装完成后使用下面命令查看当前已安装的内核

```
awk -F\' '$1=="menuentry " {print i++ " : " $2}' /etc/grub2.cfg
```

返回

```
0 : CentOS Linux (5.18.1-1.el7.elrepo.x86_64) 7 (Core)
1 : CentOS Linux (3.10.0-1160.66.1.el7.x86_64) 7 (Core)
2 : CentOS Linux (3.10.0-957.21.3.el7.x86_64) 7 (Core)
3 : CentOS Linux (0-rescue-149440bfb3fb443c9ec859e2714615c1) 7 (Core)
4 : CentOS Linux (0-rescue-4913bf8729dd48efa6db0b3f2b251530) 7 (Core)
5 : CentOS Linux (0-rescue-3f19b46f14dd47b7b760167faa8b14eb) 7 (Core)
6 : CentOS Linux (0-rescue-df8b983086ae46e1bed740034974dabd) 7 (Core)
7 : CentOS Linux (0-rescue-d34e5c1676654b108067d6abd4fe6481) 7 (Core)
```

选择 0 作为内核

```
grub2-set-default 0
reboot
```

#### 2.2 设置 bbr

```shell
# 编辑配置文件
vi /etc/sysctl.conf

# 添加如下内容
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr

# 加载系统参数（正常情况下会输出我们之前加入的内容）
sysctl -p
```

#### 2.3 验证bbr是否已经开启

```shell
# 输入
lsmod | grep bbr
# 输出
tcp_bbr 20480 2
```

### 三、脚本启动方式

启动 V2ray：`systemctl start v2ray`

停止 V2ray：`systemctl stop v2ray`

启动 Nginx：`systemctl start nginx`

停止 Nginx：`systemctl stop nginx`

四、脚本相关目录

Web 目录：`/home/wwwroot/levis`

V2ray 服务端配置：`/etc/v2ray/config.json`

V2ray 客户端配置: 执行安装时所在目录下的 `v2ray_info.txt`

Nginx 目录： `/etc/nginx`

证书目录: `/data/v2ray.key` 和 `/data/v2ray.crt`

### 四、客户端配置

最新版本下载地址：https://github.com/2dust/v2rayN/releases

百度云链接：
链接：https://pan.baidu.com/s/1jWgKzKFnsGk7AKXpFaJXAw
提取码：luqo

### 五、更新后无法链接

参考：[V2ray 新装或更新后无法链接](https://www.nixonli.com/24335.html)

新版本问题

修改文件:  `/etc/systemd/system/v2ray.service`
ExecStart那一行修改成: `ExecStart=/usr/bin/env v2ray.vmess.aead.forced=false /usr/bin/v2ray/v2ray -config /etc/v2ray/config.json`
再运行:

```
systemctl daemon-reload
v2ray restart
```

