title: Linux 安装 mysql
date: '2020-08-06 23:16:22'
updated: '2021-10-21 16:22:19'
tags: [Linux]
permalink: /articles/2020/08/06/1596726982689.html
---
## 1. Ubuntu 安装 mysql

参考文献：[Ubuntu 安装mysql和简单操作](https://www.cnblogs.com/lfri/p/10437694.html)

> 系统：ubuntu 16.04

### 1.1 安装

ubuntu上安装mysql非常简单只需要几条命令就可以完成。

```
sudo apt-get install mysql-server          //服务端
sudo apt-get install mysql-client          //客户端
sudo apt-get install libmysqlclient-dev    //程序编译时链接的库
```

安装过程中会提示设置密码什么的，注意设置了不要忘了，安装完成之后可以使用如下命令来检查是否安装成功：

```
sudo netstat -tap | grep mysql
```

通过上述命令检查之后，如果看到有mysql 的socket处于 listen 状态则表示安装成功。然后输入下面命令登陆：

```
mysql -u root -p
```

-u 表示选择登陆的用户名， -p 表示登陆的用户密码，上面命令输入之后会提示输入密码，此时输入密码就可以登录到mysql。

![1365470201902261535592661446493610.png](https://b3logfile.com/file/2020/08/1365470201902261535592661446493610-f370d4f1.png)

### 1.2 管理

说明：通过这种方式安装好之后开机自启动都已经配置好，和命令行上的环境变量，无需手动配置。

安装好之后会创建如下目录：

数据库目录：`/var/lib/mysql/`

配置文件：`/usr/share/mysql`（命令及配置文件） ，`/etc/mysql`（如：my.cnf）

相关命令：`/usr/bin`(mysqladmin mysqldump等命令) 和`/usr/sbin`

启动脚本：`/etc/init.d/mysql`（启动脚本文件mysql的目录）

```
#服务管理
#启动
sudo service mysql start
#停止
sudo service mysql stop
#服务状态
sudo service mysql status
```

### 1.3 卸载

```
#首先使用以下命令删除MySQL服务器：
sudo apt-get remove mysql-server
#然后，删除随MySQL服务器自动安装的任何其他软件：
sudo apt-get autoremove
#卸载其他组件：
sudo apt-get remove <<package-name>>
#查看从MySQL APT存储库安装的软件包列表：
dpkg -l | grep mysql | grep ii
```

## 2. Centos 安装 mysql

参考文献：[CentOS7下使用YUM安装MySQL5.6](https://zhuanlan.zhihu.com/p/83470848)



