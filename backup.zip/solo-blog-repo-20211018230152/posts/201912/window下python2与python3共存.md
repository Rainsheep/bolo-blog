title: window下python2与python3共存
date: '2019-12-04 14:02:08'
updated: '2019-12-04 14:02:08'
tags: [windows, python]
permalink: /articles/2019/12/04/1575439328865.html
---
<details>
	<summary>参考链接</summary>
	<a href="https://www.cnblogs.com/zhengyihan1216/p/6011640.html">在同一台电脑上同时安装Python2和Python3</a><br>
	<a href="https://www.cnblogs.com/shabbylee/p/6792555.html">当同时安装Python2和Python3后，如何兼容并切换使用详解（比如pip使用）</a><br>
	<a href="https://blog.csdn.net/cjeric/article/details/73518782">运行pip报错：Fatal error in launcher: Unable to create process using</a><br>
	<a href="https://blog.csdn.net/xiaotao_1/article/details/79828234">pycharm修改python interpreter的注意事项</a><br>
</details>
本文章主要解决了：

1. python2 和 python3，pip2 和 pip3 在 windows 下共存问题
2. python2 和 python3，pip2 和 pip3 的调用问题
3. pycharm 下切换解释器

# python 环境的安装

此处仅简单提下 python3 和 python2 的安装问题，不在详细提及，有需要自行百度。
官网下载 python2 和 python3 环境安装，python3 勾选自动配环境，python2 需要手动配置环境，主要安装在不同目录。

# python2 和 python3 的调用区别

**方法一（推荐）：** 安装完 python2 和 python3 以后，解释器的名字都是 python.exe，直接在 cmd 运行 python 只能出现一个，没办法区别调用。

此方法参考：[当同时安装Python2和Python3后，如何兼容并切换使用详解（比如pip使用）](https://www.cnblogs.com/shabbylee/p/6792555.html)

当需要使用 python2 的时候，使用命令
`py -2`

安装时
`py -2 -m pip install xxx`

当需要使用 python3 的时候，使用命令
`py -3`

安装时
`py -3 -m pip install xxx`

运行 python2 脚本的时候，可以使用
`py -2 xxx.py`

也可以在脚本前面加上
`#! python2`

python3 同理，不在累述。

**方法二：此方法不推荐使用，容易出现问题。**

就是将 python 安装目录下的 python.exe 改为 python2.exe 或者 python3.exe
比如讲 python2 目录下的 python.exe 重命名为 python2.exe，这时候使用 python 命令调用的是 python3，使用 python2 命令调用 python2，此方法会给下面的 pip 调用造成影响，下面也会给出此方法的解决方案。

# pip 的安装

此处不再累述，自行百度，使用 python2 和 python3 相对命令分别进行安装即可，需要注意的是需要配置环境变量。（我的 python2 需要配，python3 不需要配，不知道为啥，反正调用不了的话就去配置环境变量）

# pip2 和 pip3 的调用

pip2 和 pip3 安装完以后，我去可以看到 python2 和 python3 的安装目录下的 Scripts 目录里分别有以下文件
![20190317131102263.png](https://img.hacpai.com/file/2019/12/20190317131102263-b1df365e.png)

![20190317131213424.png](https://img.hacpai.com/file/2019/12/20190317131213424-fd257ee5.png)

使用 pip、pip2、pip2.7 都可以调用 python2
使用 pip、pip3、pip3.7 都可以调用 python3
为了区分两者，我们分别在 cmd 里面使用

```
pip2 --version
pip3 --version
```

来调用两者；

在这里，如果你使用的是上面的方法一，直接调用不会出错，如果你使用的是方法了，修改了名字，那么你调用的时候就会出错。
调用出错的解决方法，用下面的相对应的命令，去强制重新安装你重命名的目录下的 pip

```
python2  -m pip install --upgrade --force-reinstall pip
python3  -m pip install --upgrade --force-reinstall pip
```

此处参考：[运行pip报错：Fatal error in launcher: Unable to create process using ](https://blog.csdn.net/cjeric/article/details/73518782)

# pycharm 里切换解释器

File-&gt;setting-&gt;project-&gt;project Interpreter(项目解释器)

![20190317135154646.png](https://img.hacpai.com/file/2019/12/20190317135154646-f4c251f4.png)

选择要修改解释器的项目，进行解释器的添加

![20190317135253328.png](https://img.hacpai.com/file/2019/12/20190317135253328-1728ca72.png)

选择 system interpreter 在右边选择需要的解释器后点确定就行了。

![20190317135529683.png](https://img.hacpai.com/file/2019/12/20190317135529683-c175e3a2.png)

此处解释一下 virtualenv environment 和 system interpreter 的区别，第一个是一个虚拟的解释器，会基于系统安装的解释器在 pycharm 下面新建一个虚拟解释器，可以提高效率，具体自己百度，此处本人不需要，直接选用了系统的解释器。

至此，python2 和 python3 已经安装完毕，可以使用一下命令分别取调用 python2 和 python3，pip2 和 pip3

```
py -2
py -3
pip2
pip3
```
