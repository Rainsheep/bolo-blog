title: Linux中进程的后台运行
date: '2020-01-05 00:05:41'
updated: '2020-01-05 00:05:41'
tags: [Linux]
permalink: /articles/2020/01/05/1578153941569.html
---
参考链接：
[nohup 和 &](https://www.cnblogs.com/testzcy/p/9852463.html)
[nohup和&后台运行，进程查看及终止](https://blog.csdn.net/themanofcoding/article/details/81948094)
[Linux系统把程序放后台运行，后台执行不退出，退出终端仍运行进程，继续运行（centos & nohup jobs）](https://blog.csdn.net/envon123/article/details/82144401)

> 将进程挂后台可以使用 screen，此处不做讲解，参考[Centos下screen命令](https://www.rainsheep.top/articles/2020/01/04/1578152561987.html)

### &

`命令 &`：进程在后台运行
例如：当执行 ./a.out & 的时候，即使你用 ctrl+c,  那么 a.out 照样运行（因为对 SIGINT 信号免疫）。但是要注意， 如果你直接关掉 shell 后， 那么， a.out 进程就会消失。

### nohup

`nohup 命令`：不挂断的运行命令。

无论是否将 nohup 命令的输出重定向到终端，输出都将附加到当前目录的 nohup.out 文件中。
如果当前目录的 nohup.out 文件不可写，输出重定向到 $HOME/nohup.out 文件中。
如果没有文件能创建或打开以用于追加，那么 Command 参数指定的命令不可调用。

nohup 的意思是忽略 SIGHUP 信号，所以当运行 nohup ./a.out 的时候，**正常关闭 shell**, 那么 a.out 进程还是存在的（对 SIGHUP 信号免疫）。 但是， 要注意， 如果你直接在 shell 中用 Ctrl C, 那么， a.out 进程也是会消失的（因为对 SIGINT 信号不免疫）。

**注意：使用 nohup 后，应确保用 exit 命令退出当前账户，非常正常退出或结束当前会话（比如直接退出 shell），在后台运行的作业也会终止。**

### 后台运行进程

一般情况下，使用`nohup 命令 &`

流程：

1. 把程序放后台运行，简单的话，只要在命令后面加一个“&”， 如： `php test.php &`
2. 或者在运行命令后，按一下 Ctrl+Z，如运行 `php test.php `后，按一下 Ctrl+Z，也可以放置在后台运行
3. 程序在后台运行了，但还是看到输出信息，可以用管道命令把输出定向到 /dev/null，如：`php test.php >/dev/null`
4. 普通的输出信息看不到了，但还是看到一些信息，如错误信息等，需要再添加 `2>&1` 命令，如：`php test.php >/dev/null 2>&1`
5. 程序在后台运行了，但退出当前会话，发现程序还是停止了，此时要用 nohup 命令，如：`nohup php test.php >/dev/null 2>&1 `
6. 使用 nohup 后，**应确保用 exit 命令退出当前账户**，非常正常退出或结束当前会话，在后台运行的作业也会终止
7. 命令在后台运行了，怎么查看？使用 jobs 命令可列出当前会话的后台任务，jobs -l 能查看到 PID，进而可以用 kill 终止某个任务
8. 所以是终命令一般是：`nohup php test.php >/dev/null 2>&1 &`

解释：

1. /dev/null 是什么？
   /dev/null:表示的是一个黑洞，通常用于丢弃不需要的数据输出，或者用于输入流的空文件。
2. 上面命令中“2>&1”，这里的 2 和 1 是啥？
   其中 0、1、2 分别代表如下含义：
   0 – stdin (standard input)
   1 – stdout (standard output)
   2 – stderr (standard error)
