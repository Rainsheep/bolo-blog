title: ' map的详细用法: 转'
date: '2019-12-03 20:18:16'
updated: '2019-12-03 20:18:16'
tags: [STL, 知识点总结]
permalink: /articles/2019/12/03/1575375496539.html
---
# map 的详细用法:

map 是 STL 的一个关联容器，它提供一对一（其中第一个可以称为关键字，每个关键字只能在 map 中出现一次，第二个可能称为该关键字的值）的数据处理能力，由于这个特性，它完成有可能在我们处理一对一数据的时候，在编程上提供快速通道。这里说下 map 内部数据的组织，map 内部自建一颗红黑树(一种非严格意义上的平衡二叉树)，这颗树具有对数据自动排序的功能，所以在 map 内部所有的数据都是有序的，后边我们会见识到有序的好处。

下面举例说明什么是一对一的数据映射。比如一个班级中，每个学生的学号跟他的姓名就存在着一一映射的关系，这个模型用 map 可能轻易描述，很明显学号用 int 描述，姓名用字符串描述(本篇文章中不用 char *来描述字符串，而是采用 STL 中 string 来描述),下面给出 map 描述代码：

`map<int, string> mapStudent;`

# map 的构造函数

map 共提供了 6 个构造函数，这块涉及到内存分配器这些东西，略过不表，在下面我们将接触到一些 map 的构造方法，这里要说下的就是，我们通常用如下方法构造一个 map：
`map<int, string> mapStudent;`

# 数据的插入

在构造 map 容器后，我们就可以往里面插入数据了。这里讲三种插入数据的方法：

第一种：用 insert 函数插入 pair 数据，下面举例说明(以下代码虽然是随手写的，应该可以在 VC 和 GCC 下编译通过，大家可以运行下看什么效果，在 VC 下请加入这条语句，屏蔽 4786 警告  #pragma warning (disable:4786) )

```c++
#include <map>
#include <string>
#include <iostream>
using namespace std;
int main()
{
       map<int, string> mapStudent;//pair<int,string>p;p=make_pair(v1,v2); 
       mapStudent.insert(pair<int, string>(1, "student_one"));
       mapStudent.insert(pair<int, string>(2, "student_two"));
       mapStudent.insert(pair<int, string>(3, "student_three"));
       map<int, string>::iterator  iter;
       for(iter = mapStudent.begin(); iter != mapStudent.end(); iter++)
       {
          cout<<iter->first<<"  "<<iter->second<<endl;
       }
}

```

```c++
make_pair()//返回类型为对应的pair类型
无需写出类别，就可以生成一个pair对象
例：
make_pair(1,'@')
而不必费力的写成
pair<int ,char>(1,'@')

```

第二种：用 insert 函数插入 value_type 数据，下面举例说明

```c++
#include <map>
#include <string>
#include <iostream>
using namespace std;
int main()
{
       map<int, string> mapStudent;
       mapStudent.insert(map<int, string>::value_type (1, "student_one"));
       mapStudent.insert(map<int, string>::value_type (2, "student_two"));
       mapStudent.insert(map<int, string>::value_type (3, "student_three"));
       map<int, string>::iterator  iter;
       for(iter = mapStudent.begin(); iter != mapStudent.end(); iter++)
       {
           cout<<iter->first<<" "<<iter->second<<endl;
       }
}

```

第三种：用数组方式插入数据，下面举例说明

```c++
#include <map>
#include <string>
#include <iostream>
using namespace std;
int main()
{
       map<int, string> mapStudent;
       mapStudent[1] =  "student_one";
       mapStudent[2] =  "student_two";
       mapStudent[3] =  "student_three";
       map<int, string>::iterator  iter;
       for(iter = mapStudent.begin(); iter != mapStudent.end(); iter++)
       {
          cout<<iter->first<<"   "<<iter->second<<endl;
       }
}

```

以上三种用法，虽然都可以实现数据的插入，但是它们是有区别的，当然了第一种和第二种在效果上是完成一样的，用 insert 函数插入数据，在数据的插入上涉及到集合的唯一性这个概念，即当 map 中有这个关键字时，insert 操作是插入数据不了的，但是用数组方式就不同了，它可以覆盖以前该关键字对应的值，用程序说明

```c++
mapStudent.insert(map<int, string>::value_type (1, "student_one"));
mapStudent.insert(map<int, string>::value_type (1, "student_two"));
```

上面这两条语句执行后，map 中 1 这个关键字对应的值是&quot;student_one&quot;，第二条语句并没有生效，那么这就涉及到我们怎么知道 insert 语句是否插入成功的问题了，可以用 pair 来获得是否插入成功，程序如下

```c++
Pair<map<int, string>::iterator, bool> Insert_Pair;
Insert_Pair = mapStudent.insert(map<int, string>::value_type (1, "student_one"));

```

我们通过 pair 的第二个变量来知道是否插入成功，它的第一个变量返回的是一个 map 的迭代器，如果插入成功的话 Insert_Pair.second 应该是 true 的，否则为 false。

下面给出完成代码，演示插入成功与否问题

```c++
#include <map>
#include <string>
#include <iostream>
using namespace std;
int main()
{
       map<int, string> mapStudent;
       Pair<map<int, string>::iterator, bool> Insert_Pair;
       Insert_Pair ＝ mapStudent.insert(pair<int, string>(1, "student_one"));
       If(Insert_Pair.second == true)
       {
             cout<<"Insert Successfully"<<endl;
       }
       Else
       {
              cout<<"Insert Failure"<<endl;
       }
       Insert_Pair ＝ mapStudent.insert(pair<int, string>(1, "student_two"));
       If(Insert_Pair.second == true)
       {
              cout<<"Insert Successfully"<<endl;
       }
       Else
       {
              cout<<"Insert Failure"<<endl;
       }
       map<int, string>::iterator  iter;
       for(iter = mapStudent.begin(); iter != mapStudent.end(); iter++)
       {
            cout<<iter->first<<"   "<<iter->second<<endl;
       }
}

```

大家可以用如下程序，看下用数组插入在数据覆盖上的效果

```c++
#include <map>
#include <string>
#include <iostream>
using namespace std;
int main()
{
       map<int, string> mapStudent;
       mapStudent[1] =  "student_one";
       mapStudent[1] =  "student_two";
       mapStudent[2] =  "student_three";
       map<int, string>::iterator  iter;
       for(iter = mapStudent.begin(); iter != mapStudent.end(); iter++)
       {
          cout<<iter->first<<"   "<<iter->second<<endl;
       }
}

```

# map 的大小

在往 map 里面插入了数据，我们怎么知道当前已经插入了多少数据呢，可以用 size 函数，用法如下：
`int nSize = mapStudent.size();`

# 数据的遍历

这里也提供三种方法，对 map 进行遍

第一种：应用前向迭代器，上面举例程序中到处都是了，略过不表

第二种：应用反相迭代器，下面举例说明，要体会效果，请自个动手运行程序

```c++
#include <map>
#include <string>
#include <iostream>
using namespace std;
int main()
{
       map<int, string> mapStudent;
       mapStudent.insert(pair<int, string>(1, "student_one"));
       mapStudent.insert(pair<int, string>(2, "student_two"));
       mapStudent.insert(pair<int, string>(3, "student_three"));
       map<int, string>::reverse_iterator  iter;
       for(iter = mapStudent.rbegin(); iter != mapStudent.rend(); iter++)
       {
          cout<<iter->first<<"   "<<iter->second<<endl;
       }
}

```

第三种：用数组方式，程序说明如下

```c++
#include <map>
#include <string>
#include <iostream>
using namespace std;
int main()
{
       map<int, string> mapStudent;
       mapStudent.insert(pair<int, string>(1, "student_one"));
       mapStudent.insert(pair<int, string>(2, "student_two"));
       mapStudent.insert(pair<int, string>(3, "student_three"));
       int nSize = mapStudent.size()
//此处有误，应该是 for(int nIndex = 1; nIndex <= nSize; nIndex++) 
//by rainfish
       for(int nIndex = 0; nIndex < nSize; nIndex++)
       {
           cout<<mapStudent[nIndex]<<end;
       }
}


```

# 数据的查找（包括判定这个关键字是否在 map 中出现）

在这里我们将体会，map 在数据插入时保证有序的好处。
要判定一个数据（关键字）是否在 map 中出现的方法比较多，这里标题虽然是数据的查找，在这里将穿插着大量的 map 基本用法。
这里给出三种数据查找方法
第一种：用 count 函数来判定关键字是否出现，其缺点是无法定位数据出现位置,由于 map 的特性，一对一的映射关系，就决定了 count 函数的返回值只有两个，要么是 0，要么是 1，出现的情况，当然是返回 1 了
第二种：用 find 函数来定位数据出现位置，它返回的一个迭代器，当数据出现时，它返回数据所在位置的迭代器，如果 map 中没有要查找的数据，它返回的迭代器等于 end 函数返回的迭代器，程序说明

```c++
#include <map>
#include <string>
#include <iostream>
using namespace std;
int main()
{
       map<int, string> mapStudent;
       mapStudent.insert(pair<int, string>(1, "student_one"));
       mapStudent.insert(pair<int, string>(2, "student_two"));
       mapStudent.insert(pair<int, string>(3, "student_three"));
       map<int, string>::iterator iter;
       iter = mapStudent.find(1);
       if(iter != mapStudent.end())
      {
           cout<<"Find, the value is "<<iter->second<<endl;
       }
       Else
       {
           cout<<"Do not Find"<<endl;
       }
}

```

第三种：这个方法用来判定数据是否出现，是显得笨了点，但是，我打算在这里讲解
Lower_bound 函数用法，这个函数用来返回要查找关键字的下界(是一个迭代器)
Upper_bound 函数用法，这个函数用来返回要查找关键字的上界(是一个迭代器)
例如：map 中已经插入了 1，2，3，4 的话，如果 lower_bound(2)的话，返回的 2，而 upper-bound（2）的话，返回的就是 3
Equal_range 函数返回一个 pair，pair 里面第一个变量是 Lower_bound 返回的迭代器，pair 里面第二个迭代器是 Upper_bound 返回的迭代器，如果这两个迭代器相等的话，则说明 map 中不出现这个关键字，程序说明

```c++
#include <map>
#include <string>
#include <iostream>
using namespace std;
int main()
{
       map<int, string> mapStudent;
       mapStudent[1] =  "student_one";
       mapStudent[3] =  "student_three";
       mapStudent[5] =  "student_five";
       map<int, string>::iterator  iter;
       iter = mapStudent.lower_bound(2);
      {
       //返回的是下界3的迭代器
       cout<<iter->second<<endl;
       }
       iter = mapStudent.lower_bound(3);
       {
       //返回的是下界3的迭代器
       cout<<iter->second<<endl;
       }
        iter = mapStudent.upper_bound(2);
       {
       //返回的是上界3的迭代器
        cout<<iter->second<<endl;
       }
       iter = mapStudent.upper_bound(3);
      {
       //返回的是上界5的迭代器
       cout<<iter->second<<endl;
}
      Pair<map<int, string>::iterator, map<int, string>::iterator> mapPair;
      mapPair = mapStudent.equal_range(2);
      if(mapPair.first == mapPair.second)
      {
          cout<<"Do not Find"<<endl;
       }
       Else
       {
            cout<<"Find"<<endl;
        }
       mapPair = mapStudent.equal_range(3);
       if(mapPair.first == mapPair.second)
       {
            cout<<"Do not Find"<<endl;
        }
       Else
       {
           cout<<"Find"<<endl;
       }
}

```

# 数据的清空与判空

清空 map 中的数据可以用 clear()函数，判定 map 中是否有数据可以用 empty()函数，它返回 true 则说明是空 map

# 数据的删除

这里要用到 erase 函数，它有三个重载了的函数，下面在例子中详细说明它们的用法

```c++
#include <map>
#include <string>
#include <iostream>
using namespace std;
int main()
{
       map<int, string> mapStudent;
       mapStudent.insert(pair<int, string>(1, "student_one"));
       mapStudent.insert(pair<int, string>(2, "student_two"));
       mapStudent.insert(pair<int, string>(3, "student_three"));
       //如果你要演示输出效果，请选择以下的一种，你看到的效果会比较好
       //如果要删除1,用迭代器删除
       map<int, string>::iterator iter;
       iter = mapStudent.find(1);
       mapStudent.erase(iter);
       //如果要删除1，用关键字删除
       int n = mapStudent.erase(1);//如果删除了会返回1，否则返回0
       //用迭代器，成片的删除
       //一下代码把整个map清空
       mapStudent.earse(mapStudent.begin(), mapStudent.end());
       //成片删除要注意的是，也是STL的特性，删除区间是一个前闭后开的集合
     //自个加上遍历代码，打印输出吧
}

```

# 其他一些函数用法

这里有 swap,key_comp,value_comp,get_allocator 等函数，感觉到这些函数在编程用的不是很多，略过不表，有兴趣的话可以自个研究

# 排序

这里要讲的是一点比较高深的用法了,排序问题，STL 中默认是采用小于号来排序的，以上代码在排序上是不存在任何问题的，因为上面的关键字是 int 型，它本身支持小于号运算，在一些特殊情况，比如关键字是一个结构体，涉及到排序就会出现问题，因为它没有小于号操作，insert 等函数在编译的时候过不去，下面给出两个方法解决这个问题
第一种：小于号重载，程序举例

```c++
#include <map>
#include <string>
uing namespace std;
Typedef struct tagStudentInfo
{
       int      nID;
       String   strName;
}StudentInfo, *PStudentInfo;  //学生信息
int main()
{
       int nSize;
       //用学生信息映射分数
       map<StudentInfo, int>mapStudent;
       map<StudentInfo, int>::iterator iter;
       StudentInfo studentInfo;
       studentInfo.nID = 1;
       studentInfo.strName = "student_one"
       mapStudent.insert(pair<StudentInfo, int>(studentInfo, 90));
       studentInfo.nID = 2;
       studentInfo.strName = "student_two";
       mapStudent.insert(pair<StudentInfo, int>(studentInfo, 80));
       for (iter=mapStudent.begin(); iter!=mapStudent.end(); iter++)
         cout<<iter->first.nID<<endl<<iter->first.strName<<endl<<iter->second<<endl;
}

```

以上程序是无法编译通过的，只要重载小于号，就 OK 了，如下：

```c++
Typedef struct tagStudentInfo
{
       int      nID;
       String   strName;
       Bool operator < (tagStudentInfo const& _A) const
       {
              //这个函数指定排序策略，按nID排序，如果nID相等的话，按strName排序
              If(nID < _A.nID)  return true;
              If(nID == _A.nID) return strName.compare(_A.strName) < 0;
              Return false;
       }
}StudentInfo, *PStudentInfo;  //学生信息

```

第二种：仿函数的应用，这个时候结构体中没有直接的小于号重载，程序说明

```c++
#include <map>
#include <string>
using namespace std;
Typedef struct tagStudentInfo
{
       int      nID;
       String   strName;
}StudentInfo, *PStudentInfo;  //学生信息
class sort
{
       Public:
       Bool operator() (StudentInfo const &_A, StudentInfo const &_B) const
       {
              If(_A.nID < _B.nID) return true;
              If(_A.nID == _B.nID) return _A.strName.compare(_B.strName) < 0;
              Return false;
       }
};
int main()
{
       //用学生信息映射分数
       map<StudentInfo, int, sort>mapStudent;
       StudentInfo studentInfo;
       studentInfo.nID = 1;
       studentInfo.strName = "student_one";
       mapStudent.insert(pair<StudentInfo, int>(studentInfo, 90));
       studentInfo.nID = 2;
       studentInfo.strName = "student_two";
       mapStudent.insert(pair<StudentInfo, int>(studentInfo, 80));
}

```

# 另外

由于 STL 是一个统一的整体，map 的很多用法都和 STL 中其它的东西结合在一起，比如在排序上，这里默认用的是小于号，即 less&lt;&gt;，如果要从大到小排序呢，这里涉及到的东西很多，在此无法一一加以说明。
还要说明的是，map 中由于它内部有序，由红黑树保证，因此很多函数执行的时间复杂度都是 log2N 的，如果用 map 函数可以实现的功能，而 STL  Algorithm 也可以完成该功能，建议用 map 自带函数，效率高一些。
下面说下，map 在空间上的特性，否则，估计你用起来会有时候表现的比较郁闷，由于 map 的每个数据对应红黑树上的一个节点，这个节点在不保存你的数据时，是占用 16 个字节的，一个父节点指针，左右孩子指针，还有一个枚举值（标示红黑的，相当于平衡二叉树中的平衡因子），我想大家应该知道，这些地方很费内存了。
