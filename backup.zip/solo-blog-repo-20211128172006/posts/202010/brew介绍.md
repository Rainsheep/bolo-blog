title: brew 介绍
date: '2020-10-31 00:16:54'
updated: '2021-10-20 19:34:23'
tags: [mac]
permalink: /articles/2020/10/31/1604074614109.html
---
### 1. brew 简介

#### 1.1 术语介绍

Homebrew 的两个术语：

- Formulae：软件包，包括了这个软件的依赖、源码位置及编译方法等；
- Casks：已经编译好的应用包，如图形界面程序等。

#### 1.2 文件夹

Homebrw 相关的几个文件夹用途(/usr/local/)：

- bin：用于存放所安装程序的启动链接（相当于快捷方式）
- etc：brew安装程序的配置文件默认存放路径
- Library：Homebrew 系统自身文件夹
- Cellar：通过brew安装的程序将以 [程序名/版本号] 存放于本目录下

### 2. brew 控制服务

```
# 查看系统通过 brew 安装的服务
brew services list
# 清除已卸载无用的启动配置文件
brew services cleanup
# 启动服务
brew services start <formula>
# 关闭服务
brew services stop <formula>
# 重启服务
brew services restart <formula>
```

### 3. 安装卸载

> 通过brew安装的文件会自动设置环境变量，所以不用担心命令行不能启动的问题。

```
# 显示 brew 版本信息
brew --version/-v
# 安装指定软件
brew install  <formula>
# 卸载指定软件
brew uninstall <formula>
# 显示所有已安装软件
brew list
# 搜索软件
brew search TEXT|/REGEX/
# 显示软件信息
brew info <formula>
# 安装应用包
brew cask install
```

> brew install 是下载源码解压，然后 ./configure && make install ，同时会包含相关依存库，并自动配置好各种环境变量。
> brew cask 是针对已经编译好了的应用包（.dmg/.pkg）下载解压，然后放在统一的目录中（Caskroom），省掉了自己下载、解压、安装等步骤。
> 
> 简单来说，
> 
> - brew install 用来安装一些不带界面的命令行工具和第三方库。
> - brew cask install 用来安装一些带界面的应用软件。

### 4. 升级软件相关

```
# 自动升级homebrew（从github下载最新版本）
brew update
# 检测已有新版本的软件
brew outdated 
# 升级所有软件
brew upgrade  
# 升级指定的软件
brew upgrade <formula>
# 禁止指定软件升级
brew pin <formula> 
# 解锁禁止升级
brew unpin <formula> 
# 升级所有的软件包，包括未清理干净的旧版本的包
brew upgrade --all
```

### 5. 清理相关

```
# 列出需要清理的内容
brew cleanup -n 
# 清理指定的软件过时包
brew cleanup <formula> 
# 清理所有的过时软件
brew cleanup 
# 卸载指定软件
brew unistall <formula> 
# 彻底卸载指定软件，包括旧版本
brew unistall <fromula> --force
```

