title: android 开源库
date: '2021-06-25 19:39:54'
updated: '2021-06-25 19:39:54'
tags: [android]
permalink: /articles/2021/06/25/1624621194815.html
---
常用开源库：[Android 常用开源库总结](https://www.jianshu.com/p/1c40d3aacc2f)

安卓 UI 库：[awesome-android-ui](https://github.com/wasabeef/awesome-android-ui)

