title: IDEA导入eclipse项目教程
date: '2019-12-04 14:30:04'
updated: '2019-12-04 14:30:04'
tags: [软件教程]
permalink: /articles/2019/12/04/1575441004370.html
---
1、导入项目

![20190701112349548.png](https://img.hacpai.com/file/2019/12/20190701112349548-3b44eba5.png)

也可以选择这个

![2019070111371788.png](https://img.hacpai.com/file/2019/12/2019070111371788-6d78eb5a.png)

2、选择项目位置

![20190701112436465.png](https://img.hacpai.com/file/2019/12/20190701112436465-f9ddc50e.png)

3、从 Eclipse 导入

![20190701112504331.png](https://img.hacpai.com/file/2019/12/20190701112504331-d99dbc7d.png)

4、 选择项目的目录位置

如果想在 eclipse 的文件和 idea 的文件同步, 那么在 Keep project and module files in 这个框中的内容和 eclipse 的项目文件中的内容一致即可

![20190701113104183.png](https://img.hacpai.com/file/2019/12/20190701113104183-3aca4fec.png)

5、 选择项目

![20190701112700973.png](https://img.hacpai.com/file/2019/12/20190701112700973-1c51d2b7.png)

6、保持工程的代码样式,选择 next 即可

![20190701113148436.png](https://img.hacpai.com/file/2019/12/20190701113148436-6906544d.png)

7、jdk 的配置, 选择默认的即可. 点击 finish 后, 即可生成工程.

![2019070111323084.png](https://img.hacpai.com/file/2019/12/2019070111323084-60329dce.png)

8、 报错

![20190701113635201.png](https://img.hacpai.com/file/2019/12/20190701113635201-3b37f17e.png)

OK 即可

9、打开项目结构

![20190701113825273.png](https://img.hacpai.com/file/2019/12/20190701113825273-f5ced606.png)

10、之后在 project structure 中的 Modeule 中的 Dependencies, 删除如下报红的模块，并选择 SDK

![20190701113941655.png](https://img.hacpai.com/file/2019/12/20190701113941655-db6dd425.png)![20190701114046736.png](https://img.hacpai.com/file/2019/12/20190701114046736-56021c85.png)

11、接着在 Libraries 中选择 lib , 即放 jar 包的位置

![20190701114129641.png](https://img.hacpai.com/file/2019/12/20190701114129641-a0d78d35.png)

![20190701114214487.png](https://img.hacpai.com/file/2019/12/20190701114214487-fb2e5e5e.png)

12、之后在 Modules 中的 Dependencies 中, 添加该 jar 包

![20190701114246756.png](https://img.hacpai.com/file/2019/12/20190701114246756-de7cf41f.png)

13、之后, 配置 Tomcat 的 jar 包, 否则会报缺少 servlet 的错误

![20190701114400328.png](https://img.hacpai.com/file/2019/12/20190701114400328-b62c27b6.png)

![20190701114418935.png](https://img.hacpai.com/file/2019/12/20190701114418935-338b5ff0.png)

14、接着在 facets 中, 点击加号, 选择 web, 配置 web.xml

![20190701114504412.png](https://img.hacpai.com/file/2019/12/20190701114504412-5d70eed2.png)

15、在如下的页面中, 配置 web.xml 的位置和网页文件的目录的位置.
web.xml 和 Web 资源目录的位置是错误的,需要重新配置.

![20190701114708855.png](https://img.hacpai.com/file/2019/12/20190701114708855-af021893.png)

修改如下

![2019070111475214.png](https://img.hacpai.com/file/2019/12/2019070111475214-cfb95637.png)

16、接着配置 Artifacts, 选择 Web Application: Exploded

![20190701115014602.png](https://img.hacpai.com/file/2019/12/20190701115014602-c999d439.png)

17、然后配置 Tomcat 运行即可

![20190701115135432.png](https://img.hacpai.com/file/2019/12/20190701115135432-c7d268e9.png)

![20190701115146611.png](https://img.hacpai.com/file/2019/12/20190701115146611-fe286567.png)
