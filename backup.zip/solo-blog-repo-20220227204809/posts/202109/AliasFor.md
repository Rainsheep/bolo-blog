title: '@AliasFor'
date: '2021-09-03 11:44:02'
updated: '2021-09-03 11:44:02'
tags: [java]
permalink: /articles/2021/09/03/1630640642592.html
---
参考文献：

[Spring中的@AliasFor标签](https://blog.csdn.net/wolfcode_cn/article/details/80654730)

## 1. 基础知识

### 1.1 源码

```java
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD})
@Documented
public @interface AliasFor {
    @AliasFor("attribute")
    String value() default "";

    @AliasFor("value")
    String attribute() default "";

    Class<? extends Annotation> annotation() default Annotation.class;
}
```

> value 和 attribute 互为别名，作用一样

### 1.2 别名

@AliasFor 可以为属性起别名

```java
public @interface RequestMapping {
 
    @AliasFor("path")
    String[] value() default {};
}
```

### 1.3 显式覆盖元注解中属性

EnableAutoConfiguration.class

```java
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
@AutoConfigurationPackage
@Import({AutoConfigurationImportSelector.class})
public @interface EnableAutoConfiguration {
    String ENABLED_OVERRIDE_PROPERTY = "spring.boot.enableautoconfiguration";

    Class<?>[] exclude() default {};

    String[] excludeName() default {};
}
```

> 注意，@Inherited 可继承的，有属性 exclude

再来看 SpringBootApplication.class

```java
@SpringBootConfiguration
@EnableAutoConfiguration
@ComponentScan(
    excludeFilters = {@Filter(
    type = FilterType.CUSTOM,
    classes = {TypeExcludeFilter.class}
), @Filter(
    type = FilterType.CUSTOM,
    classes = {AutoConfigurationExcludeFilter.class}
)}
)
public @interface SpringBootApplication {
    @AliasFor(annotation = EnableAutoConfiguration.class)
    Class<?>[] exclude() default {};

    @AliasFor(
        annotation = ComponentScan.class,
        attribute = "basePackages"
    )
    String[] scanBasePackages() default {};
}
```

* @SpringBootApplication 的 exclude 属性代替了 EnableAutoConfiguration 的 exclude 属性
* @SpringBootApplication 的 scanBasePackages 代替了 ComponentScan 的 basePackages 属性



