title: MediaPlayer
date: '2021-03-23 14:43:28'
updated: '2021-03-23 14:43:28'
tags: [android]
permalink: /articles/2021/03/23/1616481808245.html
---
参考文献：

[Android 多媒体开发】 MediaPlayer 状态机 接口 方法 解析](https://hanshuliang.blog.csdn.net/article/details/38487967#t1)

[bilibili/ijkplayer](https://github.com/bilibili/ijkplayer)

## 一. MediaPlayer 状态机介绍

![20140822110649566.gif](https://b3logfile.com/file/2021/03/20140822110649566-4be321db.gif)

### 1. Idle (闲置) 状态 和 End (结束) 状态

![20140822151637246.png](https://b3logfile.com/file/2021/03/20140822151637246-f49924b2.png)

**MediaPlayer 对象声明周期** : 从 Idle 到 End 状态就是 MediaPlayer 整个生命周期;

* 生命周期开始 : 进入 Idle (闲置) 状态;
* 生命周期结束 : 进入 End (结束) 状态;

**Idle 和 End 状态转换 :**

* 进入 Idle 状态 : MediaPlayer 刚被创建 new MediaPlayer() 或者 调用了 reset() 方法之后, 进入 Idle (闲置) 状态;
* 进入 End 状态 : 在 Idle 状态调用 release() 方法后, 会进入 End (结束) 状态;

**两种进入 Idle 状态方法的差别** : 在 Idle 状态无法调用 getCurrentPosition(), getDuration(), getVideoHeight(), getVideoWidth(), setAudioStreamtype(int), setLooping(boolean), setVolume(float, float), pause(), start(), stop(), seekTo(), prepare(), prepareAsync()，方法都是错误的;

* new MediaPlayer() 进入 Idle 状态 : 此时 MediaPlayer 内部引擎和状态都没有改变, 调用上面的方法之后, 将无法调用 OnErrorListener.onError() 方法;
* reset() 进入 Idle 状态 :  此时如果调用上面的方法, 内部的引擎就会回调 OnErrorListener.onError() 方法;

**创建 和 重载 MediaPlayer 区别** :

* 创建 MediaPlayer : 通过 new MediaPlayer() 创建的对象处于 Idle (闲置) 状态;
* 重载 MediaPlayer : 通过 create() 方法创建的 MediaPlayer 对象处于 Prepare (准备) 状态;

**End (结束) 状态解析** :

* release() 方法作用 : 该方法会释放 播放引擎 中与 MediaPlayer 相关的资源;
* 释放唯一性资源 : 有些资源如 硬件加速组件 单态组件等都是唯一性的资源, 如果不释放掉, 之后的 Mediaplayer 都无法正常运行;
* 无法进行状态转换 : End 状态代表 MediaPlayer 生命周期结束, 在此状态不能转换成其它状态了;

### 2. Error (错误) 状态

![20140822151709039.png](https://b3logfile.com/file/2021/03/20140822151709039-daddea0f.png)

**Error 状态转换** : 当 MediaPlayer 出现一些错误如 格式错误, 分辨率过高等原因, 播放器引擎 就会调用 OnErrorListener.onError()方法;

* 进入 Error 状态 : 客户端调用 OnErrorListener.onError() 方法, 会进入 Error 状态;
* 离开 Error 状态 : 如果想要使用进入 Error 状态的 MediaPlayer, 可以使用 reset() 方法进入 Idle 状态;

**注册监听** : 编程注册一个 OnErrorListener 监听器, 用于获取 播放器引擎 内部发生的错误;

**注册方法** : 调用 MediaPlayer.setOnErrorListener(OnErrorListener) 方法, 注册 OnErrorListener;

**关于一些异常抛出** : 在不合法的地方调用方法, 会抛出 IllegalStateException 异常;

### 3. Initalized (初始化) 状态

![20140822152505593.png](https://b3logfile.com/file/2021/03/20140822152505593-ee61e2be.png)

**Initialized 状态转换** : 在 Idle 状态调用 setDataSource() 方法, MediaPlayer 会迁移到 Initialized 状态;

> 注意 : 只能是在 Idle 状态调用该方法, 如果在其它状态调用该方法, 会报出 IllegalStateException 异常;

### 4. Prepared (就绪) 和 Preparing (准备中) 状态

![20140822155757984.png](https://b3logfile.com/file/2021/03/20140822155757984-8031d9de.png)

**Prepared (就绪) 状态转换** :

* 从 Initialized 状态迁移 : 在 Initialized 状态调用 prepare() 方法, 如果方法成功返回, MediaPlayer 就会进入 Prepared 状态;
* 从 Preparing 状态迁移 : 在 Preparing 状态调用 OnPrepareListener.onPrepared() 方法迁移到 Prepared 状态;

**Preparing (准备中) 状态** : Initialized 状态调用 prepareAsync() 方法进入 Preparing 状态;

* 该状态执行的操作 : 在 Preparing 状态时, 播放器引擎会继续完成准备工作, 同步版本返回 或者 异步版本准备工作完成就会调用  OnPrepareListener.onPrepared() 方法进入 Prepared 状态;

**抛出异常** : 只有在 Initialized 方法中才能调用 prepare() 和 prepareAsync()方法, 在其它状态调用会报出 IllegalStateException 异常;

**Prepared 状态 MediaPlayer 可进行的操作** : 在这个状态 MediaPlayer 可以进行 音频视频属性 循环属性等操作;

### 5. Started (开始) 状态

![20140822161013659.png](https://b3logfile.com/file/2021/03/20140822161013659-24780b9b.png)

**Started 状态迁移** : 在 Prepared 状态调用 start() 方法, MediaPlayer 即迁移到了 Started 状态;

* 判断 MediaPlayer 是否在 Started 状态 : 在任何状态下调用 isPlaying() 方法, 可以判断 MediaPlayer 是否在 Started 状态;
* 跟踪缓冲状态 : 在 Started 状态, 调用 OnBufferingUpdateListener.onBufferingUpdate() 方法, 可以获取视频音频流的缓冲状态;

### 6. Paused (暂停) 状态

![20140822162645384.png](https://b3logfile.com/file/2021/03/20140822162645384-8b46225c.png)

**Paused (暂停) 状态迁移** : 在 Started 状态调用 pause() 方法, MediaPlayer 会进入 Paused 状态;

* 状态迁移时间 : Started 状态转换为 Paused 状态需要一定时间, 这个过程是异步的, 过一段时间之后 isPlaying() 状态才会改变;
* 回到 Started 状态 : 在 Paused 状态调用 start() 方法, 会进入 Started 状态;

### 7. Stopped (停止) 状态

![20140822164148421.png](https://b3logfile.com/file/2021/03/20140822164148421-f6941be6.png)

**Stopped 状态迁移** : 在 Prepared, Started, Paused, PlaybackCompleted 状态下 调用 stop() 方法, MediaPlayer 会迁移到 Stopped 状态;

### 8. 播放位置调整

![20140822170129703.png](https://b3logfile.com/file/2021/03/20140822170129703-fd823567.png)![201408221703216032.png](https://b3logfile.com/file/2021/03/20140822170321603_2-c6f797c6.png)
![20140822170149578.png](https://b3logfile.com/file/2021/03/20140822170149578-39806c37.png)

**seekTo() 方法说明** : 该方法异步, 调用后 播放器引擎还需要进行其它操作, 跳转才能完成;

* 进行的操作 : 播放器引擎会回调 OnSeekComplete.onSeekComplete()方法, 该方法通过 setOnSeekCompleteListener() 方法注册;
* seekTo() 方法调用状态 : 该方法可以在 Prepared, Started, Paused, PlaybackCompleted 状态进行调用;
* 获取播放位置 : 调用 getCurrentPosition() 方法, 可以获取当前播放的位置, 可以帮助播放器更新进度条;

### 9. PlaybackCompleted (播放完毕) 状态

![20140822180237146.png](https://b3logfile.com/file/2021/03/20140822180237146-5cf5321a.png)

**循环模式开启** : 如果之前使用了 setLooping() 开启了循环模式, 播放完毕之后 MediaPlayer 会重新进入 Started 状态;

**PlaybackCompleted 状态迁移** : 如果没有设置循环模式, 那么播放完毕之后会调用 OnCompletion.onCompletion() 回调方法, MediaPlayer 会进入 PlaybackCompleted 状态;

* OnCompletion注册 : 调用 MediaPlayer.setOnCompletionListener() 注册该监听器;
* 进入 Started 状态方法 : 在 PlaybackCompleted 状态时, 调用 satrt() 方法可以进入 Started 状态;

## 二. MediaPlayer 接口

### 1. 缓冲相关接口

**接口介绍** :

* 接口名称 : MediaPlayer.OnBufferingUpdateListener;
* 接口作用 : 定义一个回调接口, 该接口的作用是在流媒体缓冲状态发生改变的时候, 标明该状态;

**接口方法介绍** :

* 接口方法 :
  
  ```java
  public abstract void onBufferingUpdate (MediaPlayer mp, int percent)
  ```
* 方法作用 : 该方法在 MediaPlayer 通过 HTTP 下载缓冲视频流的时候回调, 用以改变视频缓冲状态;
* 方法参数 : mp 即 MediaPlayer 实体对象; percent 已经缓冲了的 或者 播放了的 媒体流百分比;

### 2. 播放完毕相关接口

**接口介绍** :

* 接口名称 : MediaPlayer.OnCompletionListener;
* 接口作用 : 在接口中定义了 流媒体 播放完毕后回调的方法;

**接口方法介绍** :

* 接口方法 :
  
  ```java
  public abstract void onCompletion (MediaPlayer mp)
  ```
* 方法作用 : 在 媒体流 播放完毕之后回调;

### 3. 错误相关接口

**接口介绍** :

* 接口名称 : MediaPlayer.OnErrorListener;
* 接口作用 : 在该接口中定义回调方法, 在异步操作中出现错误时会回调该方法, 其它情况下出现错误时直接抛出异常;

**接口方法介绍** :

* 接口方法 :
  
  ```java
  public abstract boolean onError (MediaPlayer mp, int what, int extra)
  ```
* 方法作用 : 异步操作中出现错误时回调该方法;
* 参数介绍 :
  
  * MediaPlayer mp : MediaPlayer 实体类;
  * int what : 出现的错误类型, 如
    
    ```
    MEDIA_ERROR_UNKONWN(位置错误)
    MEDIA_ERROR_SERVER_DIED(服务器错误) ;
    ```
  * int extra : 针对与具体错误的附加码, 用于定位错误更详细信息, 例如
    
    ```
    MEDIA_ERROR_IO(本地文件或网络相关错误), 
    MEDIA_ERROR_MALFORMAD (比特流不符合相关的编码标准和文件规范), 
    MEDIA_ERROR_UNSUPPORTED(框架不支持该功能), 
    MEDIA_ERROR_TIME_OUT(一些操作超时);
    ```

**方法执行结果** : 成功处理错误返回 true, 处理失败返回 false, 如果没有设定针对该方法的监听器, 直接调用 OnCompletionListener 监听器;

### 4. 信息相关接口

**接口介绍** :

* 接口名称 : MediaPlayer.OnInfoListener;
* 接口作用 : 该接口定义了一个回调方法, 该方法在媒体播放时出现信息或者警告时回调该方法;

**接口方法介绍** :

* 接口方法 :
  
  ```java
  public abstract boolean onInfo (MediaPlayer mp, int what, int extra)
  ```
* 方法作用 : 出现了信息或者警告的时候回调;
* 参数介绍 :
  
  * MediaPlayer mp : MediaPlayer 实体对象;
  * int what : 信息或者警告的类型, 如
    
    ```
    MEDIA_INFO_UNKNOWN(未知的信息), 
    MEDIA_INFO_VEDIO_TRACK_LAGGING(视频过于复杂解码太慢), 
    MEDIA_INFO_VEDIO_RENDERING_START(开始渲染第一帧), 
    MEDIA_INFO_BUFFRING_START(暂停播放开始缓冲更多数据), 
    MEDIA_INFO_BUFFERING_END(缓冲了足够的数据重新开始播放), 
    MEDIA_INFO_BAD_INTERLEAVING(错误交叉), 
    MEDIA_INFO_NOT_SEEKABLE(媒体不能够搜索), 
    MEDIA_INFO_METADATA_UPDATE(一组新的元数据用), 
    MEDIA_INFO_UNSUPPORTED_SUBTITLE(不支持字幕), 
    MEDIA_INFO_SUBTITLE_TIMED_OUT(读取字幕使用时间过长);
    ```
  * int extra : 信息或者警告的类型,
* 返回值 : 如果处理了信息就会返回 true, 没有处理返回false, 如果没有注册该监听, 就会忽略该信息;

### 5. 准备播放相关接口

**接口介绍** :

* 接口名称 : MediaPlayer.OnPreparedListener;
* 接口作用 : 该接口中定义一个回调方法, 该方法在进入 Prepared 状态 并 开始播放的时候回调;

**接口方法介绍** :

* 接口方法 :
  
  ```java
  public abstract void onPrepared (MediaPlayer mp)
  ```
* 方法作用 : 该方法在进入 Prepared 状态 并 开始播放的时候回调;
* 参数介绍 : MediaPlayer mp , MediaPlayer 实体对象;

### 6. 查找操作相关接口

**接口介绍** :

* 接口名称 : MediaPlayer.OnSeekCompleteListener;
* 接口作用 : 该接口定义了一个回调方法, 该方法在查找操作完成后回调;

**接口方法介绍** :

* 接口方法 :
  
  ```java
  public abstract void onSeekComplete (MediaPlayer mp)
  ```
* 方法作用 : 查找操作完成的时候回调该方法;

### 7. 视频大小相关接口

**接口介绍** :

* 接口名称 : MediaPlayer.OnVideSizeChangedListener;
* 接口作用 : 该接口中定义了一个回调方法, 当视频大小首次被知晓或者更新的时候回调该方法;

**接口方法介绍** :

* 接口方法 :
  
  ```java
  public abstract void onVideoSizeChanged (MediaPlayer mp, int width, int height)
  ```
* 方法作用 : 视频大小更新时回调该方法, 如果没有视频返回0;
* 参数解析 : int width 视频的宽度, int height 视频的高度;

## 三. MediaPlayer 常用方法解析

### 1. 构造方法

**方法的注意点** : 使用 create() 方法创建的 MediaPlayer, 直接指定了媒体资源, 不需要再进行调用 prepare() 方法;

#### 1.1 默认构造方法

```java
public MediaPlayer ()
```

**方法简介** : 默认构造方法, 创建的 MediaPlayer 自动进入 Idle 状态, 不同于 create() 方法, 创建的 MediaPlayer 自动进入 Prepared 状态;

**两种方法比较** : 因为 create() 方法创建的时候就指定了数据源, 不用在 Idle 状态设置数据, 并调用 prepare() 方法了;

#### 1.2 指定 uri 的构造方法

```java
public static MediaPlayer create (Context context, Uri uri)
```

**方法简介** : 根据给定的 Uri 创建一个 MediaPlayer 对象, 如果创建成功, 其内部会自动调用 prepare() 方法, 不同再自己调用一次, MediaPlayer 使用完毕之后要使用 release()方法, 否则会出错;

**返回值** : 如果创建成功返回 MediaPlayer 对象, 如果创建失败返回 null;

参数介绍 : Context context : Android 的上下文对象; Uri uri : 数据源的 Uri;

#### 1.3 指定资源 id

```java
public static MediaPlayer create (Context context, int resid)
```

**方法简介** : 通过给定的 raw 资源 id, 创建 MediaPlayer 对象;

**参数介绍** : int resid 设置播放源文件, 这里指的是 raw 资源 id;

#### 1.4 指定 id 和 SurfaceView

```java
public static MediaPlayer create (Context context, Uri uri, SurfaceHolder holder)
```

**方法简介** : 创建一个 MediaPlayer, 指定 MediaPlayer 数据源 Uri 和 SurfaceView 对象;

**参数介绍** :

* Context context : Android 的上下文对象;
* Uri uri : 指定的网络媒体的数据源;
* SurfaceHolder holder : 指定要播放视频的 SurfaceHolder ;

### 2. 获取播放器相关属性方法

#### 2.1 获取当前位置

```java
public int getCurrentPosition ();
```

**方法解析** : 获取当前播放器播放的位置, 返回值是 已经播放了的毫秒数;

**方法的有效状态和无效状态** :

* 有效状态 : Idle, Initialized, Prepared, Started, Paused, Stopped, PlaybackCompleted, 在以上状态调用该方法不会改变 MediaPlayer 状态;
* 无效状态 : Error 状态, 在 Error 状态调用该方法, 会进入 Error 状态中;

#### 2.2 获取文件时长

```java
public int getDuration ();
```

**方法解析** : 获取文件的播放时长 (毫秒), 如果没有可用的时长, 就会返回 -1;

**方法的有效状态和无效状态** : 设置数据源之后的非错误状态 才可以获取播放文件时长;

* 有效状态 : Prepared, Started, Paused, Stopped, PlaybackCompleted, 在以上状态调用该方法不会改变 MediaPlayer 状态;
* 无效状态 : Idle, Initialized, Error 状态, 在 Error 状态调用该方法, 会进入 Error 状态中;

#### 2.3 获取视频高度 宽度

```java
public int getVideoHeight (), public int getVideoWidth ();
```

**方法解析** : 返回视频的高度 或者 宽度, 如果没有资源, 那么会返回0, 当视频大小改变的时候可以使用MediaPlayer.OnVideoSizeChangedListener 监听其监听该事件;

**方法的有效状态和无效状态** : 除 Error 以外的所有状态;

* 有效状态 : Idle, Initialized, Prepared, Started, Paused, Stopped, PlaybackCompleted, 在以上状态调用该方法不会改变 MediaPlayer 状态;
* 无效状态 : Error 状态, 在 Error 状态调用该方法, 会进入 Error 状态中;

#### 2.4 检查 MediaPlayer 是否在循环

```java
public boolean isLooping ();
```

**方法解析** : 检查 MediaPlayer 是否在循环播放, 如果是 返回 true, 不是的话 返回 false;

**方法的有效状态和无效状态** : 在任何状态都有效, 包括在 Error 状态的时候;

#### 2.5 检查 MediaPlayer 是否在播放

```java
public boolean isPlaying ();
```

**方法解析** : 检查 MediaPlayer 是否正在播放;

**方法的有效状态和无效状态** : 除 Error 以外的所有状态, 都可以查看 MediaPlayer 是否在播放;

* 有效状态 : Idle, Initialized, Prepared, Started, Paused, Stopped, PlaybackCompleted, 在以上状态调用该方法不会改变 MediaPlayer 状态;
* 无效状态 : Error 状态, 在 Error 状态调用该方法, 会进入 Error 状态, 抛出 IllegalStateException;

### 3. 状态迁移相关方法

#### 3.1 暂停播放

```java
public void pause ();
```

**方法解析** : 暂停播放, 如果想要恢复播放的话, 调用 start() 方法;

**方法的有效状态和无效状态** : 只有在 Started 和 Paused 状态有效, Started 状态调用该方法进入 Paused 状态, Paused 状态调用该方法不起作用;

* 有效状态 : Started, Paused, 在以上状态调用该方法不会改变 MediaPlayer 状态;
* 无效状态 : Error , Idle, Initialized, Prepared, Stopped, PlaybackCompleted 状态, 在 Error 状态调用该方法, 会进入 Error 状态, 抛出 IllegalStateException;

#### 3.2 同步准备播放

```java
public void prepare ();
```

**方法解析** : 这是个同步方法, 设置完数据源 和 播放载体之后调用该方法 或者 prepareAsync() 方法, 才能进行正常播放, 如果方法调用成功, 才能正常播放;

**方法的有效状态和无效状态** : 只有在 Initialized 和 Stopped 状态中会

* 有效状态 : Initialized, Stopped, 在以上状态调用该方法不会改变 MediaPlayer 状态;
* 无效状态 : Idle, Prepared, Started, Paused, PlaybackCompleted, Error 状态, 在 Error 状态调用该方法, 会进入 Error 状态中;

#### 3.3 异步准备播放

```java
public void prepareAsync ();
```

**方法作用** : 异步的方法, 让播放器处于准备状态;

* 调用时机 : 设置完数据源 和 播放载体 之后调用该方法;
* 适用情况 : 对于 流媒体 来说, 调用该方法立即返回, 要比 阻塞等待缓冲足够的数据在播放比较好;

**方法的有效状态和无效状态** : 只有在 Initialized 和 Stopped 状态中会

* 有效状态 : Initialized, Stopped, 在以上状态调用该方法不会改变 MediaPlayer 状态;
* 无效状态 : Idle, Prepared, Started, Paused, PlaybackCompleted, Error 状态, 在 Error 状态调用该方法, 会进入 Error 状态中;

#### 3.4 释放

```java
public void release ();
```

**方法解析** : 释放掉与 MediaPlayer 相关的资源;

**调用时机** : 在 MediaPlayer 播放的 Activity 暂停(pause) 停止(stop) 或者 销毁(destroy)  的时候要调用该方法释放 资源;

**方法的有效状态和无效状态**  : 在任何状态下 调用 release() 方法都可以;

#### 3.5 重置

```java
public void reset ();
```

**方法解析** : 重置 MediaPlayer 到 Idle 状态, 此时还没有设置数据源, 如果想要播放媒体资源, 需要设置数据源 和 调用 prepare()方法;

**方法的有效状态和无效状态** : 在任何状态下 调用 release() 方法都可以;

### 4. 设置数据源相关方法

#### 4.1 设置本地文件路径

```java
public void setDataSource (String path);
```

**方法解析** : 设置一个 文件路径 或者 http/rtsp 地址 当做数据源;

**参数解析** : String path, 媒体资源的 文件路径 或者是 http/rtsp url 地址路径;

**方法的有效状态和无效状态** : 只有在 Idle 状态下才能设置数据源, 其它情况都会报错;

* 有效状态 : Idle, 在以上状态调用该方法不会改变 MediaPlayer 状态;
* 无效状态 : Initialized, Prepared, Started, Paused, Stopped, PlaybackCompleted, Error, 状态, 在 Error 状态调用该方法, 会进入 Error 状态中;

#### 4.2 设置文件描述符

```java
public void setDataSource (FileDescriptor fd);
```

**方法解析** : 设置一个文件描述符资源, 调用者应该注意关闭这个文件描述符;

**参数解析** : FileDescriptor sd, UNIX 系统的文件描述, 相当与一个文件;

**方法的有效状态和无效状态** : 只有在 Idle 状态下才能设置数据源, 其它情况都会报错;

* 有效状态 : Idle, 在以上状态调用该方法不会改变 MediaPlayer 状态;
* 无效状态 : Initialized, Prepared, Started, Paused, Stopped, PlaybackCompleted, Error, 状态, 在 Error 状态调用该方法, 会进入 Error 状态中;

#### 4.3 设置数据源只截取其中一段

```java
public void setDataSource (FileDescriptor fd, long offset, long length);
```

**方法解析** : 设置一个文件描述符数据源, 这个文件描述符文件必须是可查询的;

**参数解析** :

* FileDescriptor fd : 文件描述符;
* long offset : 文件开始播放的位置, 这里指的是字节数;
* long length : 文件播放的大小, 字节数;

**方法的有效状态和无效状态** : 只有在 Idle 状态下才能设置数据源, 其它情况都会报错;

* 有效状态 : Idle, 在以上状态调用该方法不会改变 MediaPlayer 状态;
* 无效状态 : Initialized, Prepared, Started, Paused, Stopped, PlaybackCompleted, Error, 状态, 在 Error 状态调用该方法, 会进入 Error 状态中;

#### 4.4 设置 Uri 路径

```java
public void setDataSource (Context context, Uri uri);
```

**方法介绍** : 设置一个 Uri 路径当作数据源;

**参数介绍** :

* Context context : Android 上下文对象;
* Uri uri : 网络媒体文件数据源;

**方法的有效状态和无效状态** : 只有在 Idle 状态下才能设置数据源, 其它情况都会报错;

* 有效状态 : Idle, 在以上状态调用该方法不会改变 MediaPlayer 状态;
* 无效状态 : Initialized, Prepared, Started, Paused, Stopped, PlaybackCompleted, Error, 状态, 在 Error 状态调用该方法, 会进入 Error 状态中;

### 5. 设置监听器相关方法

**注意** : 注册监听器相关方法在 MediaPlayer 的任何状态都可以调用;

#### 5.1 注册缓冲变化相关监听器

```java
public void setOnBufferingUpdateListener (MediaPlayer.OnBufferingUpdateListener listener);
```

**方法作用** : 注册一个在网络缓冲数据流发生变化后回调的监听器;

#### 5.2 注册播放完毕监听器

```java
public void setOnCompletionListener (MediaPlayer.OnCompletionListener listener);
```

**方法作用** : 注册一个在媒体资源播放完毕之后回调的播放事件;

#### 5.3 注册错误监听器

```java
public void setOnErrorListener (MediaPlayer.OnErrorListener listener);
```

**方法解析** : 注册一个在异步操作过程中发生错误回调的监听器;

#### 5.4 注册事件监听器

```java
public void setOnInfoListener (MediaPlayer.OnInfoListener listener);
```

**方法解析** : 注册一个当有信息 或者 警告出现就会回调的监听器;

#### 5.5 注册准备播放监听器

```java
public void setOnPreparedListener (MediaPlayer.OnPreparedListener listener);
```

**方法解析** : 注册一个当媒体资源准备播放时回调的监听器;

#### 5.6 注册搜寻操作监听器

```java
public void setOnSeekCompleteListener (MediaPlayer.OnSeekCompleteListener listener);
```

**方法解析** : 注册一个搜寻操作完成后回调的监听器;

#### 5.7 注册视频大小改变监听器

```java
public void setOnVideoSizeChangedListener (MediaPlayer.OnVideoSizeChangedListener listener);
```

**方法解析** : 注册一个 当视频大小已知 或者 更新后 回调的监听器;

### 6. 其他设置

#### 6.1 指定音频流类型

```java
public void setAudioStreamType (int streamtype);
```

**方法解析** : 为 MediaPlayer 设置音频流类型, 音频类型在 AudioManager 中定义, 该方法必须在 prepare() 或者 prepareAsync() 方法之前调用;

**方法的有效状态和无效状态** :

* 有效状态 : Idle, Initialized, Prepared, Started, Paused, Stopped, PlaybackCompleted, 在以上状态调用该方法会进入 Paused 状态;
* 无效状态 : Error 状态, 在 Error 状态调用该方法, 会进入 Error 状态中;

#### 6.2 设定播放载体

```java
public void setDisplay (SurfaceHolder sh);
```

**方法解析** : 设定该媒体播放器的载体 SurfaceHolder, 如果要播放视频必须设置该项 或者 setSurface() 中的任意一个, 如果播放音频, 就不许要设置该该项, 如果播放视频没有设置该项, 那么只会播放声音;

**方法的有效状态和无效状态** : 在任何状态下都有效, 并且不会改变当前的运行状态;

#### 6.3 设置循环播放

```java
public void setLooping (boolean looping);
```

**方法解析** : 设置播放器是否循环播放;

**方法的有效状态和无效状态** :

* 有效状态 : Idle, Initialized, Prepared, Started, Paused, Stopped, PlaybackCompleted, 在以上状态调用该方法不会改变当前状态;
* 无效状态 : Error 状态, 在 Error 状态调用该方法, 会进入 Error 状态中;

#### 6.4 设置是否保持屏幕

```java
public void setScreenOnWhilePlaying (boolean screenOn);
```

**方法解析**: 设置在视频播放的时候是否使用 SurfaceHolder 保持屏幕亮起;

**方法的有效状态和无效状态** : 任何状态都可调用, 并且不会改变当前状态;

#### 6.5 设置电源管理状态

```java
public void setWakeMode (Context context, int mode);
```

**方法解析** : 为 MediaPlayer 设置电源管理状态;

**方法的有效状态和无效状态** : 任何状态都可调用, 并且不会改变当前状态;

## 四. ijkplayer 使用

### 1. gradle 方式

```
# required
allprojects {
    repositories {
        jcenter()
    }
}

dependencies {
    # required, enough for most devices.
    compile 'tv.danmaku.ijk.media:ijkplayer-java:0.8.8'
    compile 'tv.danmaku.ijk.media:ijkplayer-armv7a:0.8.8'

    # Other ABIs: optional
    compile 'tv.danmaku.ijk.media:ijkplayer-armv5:0.8.8'
    compile 'tv.danmaku.ijk.media:ijkplayer-arm64:0.8.8'
    compile 'tv.danmaku.ijk.media:ijkplayer-x86:0.8.8'
    compile 'tv.danmaku.ijk.media:ijkplayer-x86_64:0.8.8'

    # ExoPlayer as IMediaPlayer: optional, experimental
    compile 'tv.danmaku.ijk.media:ijkplayer-exo:0.8.8'
}
```

优点：方便

缺点：支持格式少，不知道 https 协议

### 2. 自行编译

**安装 git 和 yasm**

```bash
sudo apt-get install git
sudo apt-get install yasm
```

**配置 sdk 和 ndk**

> ndk 版本不能超过15

```bash
# add these lines to your ~/.bash_profile or ~/.profile
export ANDROID_SDK=<your sdk path>
export ANDROID_NDK=<your ndk path>
```

**按需配置**

如果需要支持更多的格式

```bash
cd config
rm module.sh
ln -s module-default.sh module.sh
cd android/contrib
# cd ios
sh compile-ffmpeg.sh clean
```

如果不需要支持太多格式，希望库更小（包括 hevc 格式）

```sh
cd config
rm module.sh
ln -s module-lite-hevc.sh module.sh
cd android/contrib
# cd ios
sh compile-ffmpeg.sh clean
```

如需不需要太多格式(默认)

```sh
cd config
rm module.sh
ln -s module-lite.sh module.sh
cd android/contrib
# cd ios
sh compile-ffmpeg.sh clean
```

**为安卓开发编译**

```sh
git clone https://github.com/Bilibili/ijkplayer.git ijkplayer-android
cd ijkplayer-android
git checkout -B latest k0.8.8

# 初始化安卓
./init-android.sh
# 初始化安卓支持 http
./init-android-openssl.sh

cd android/contrib
# 清除
./compile-openssl.sh clean
./compile-ffmpeg.sh clean
# 编译
./compile-openssl.sh all
./compile-ffmpeg.sh all

# 编译 ijkplayer
cd ..
./compile-ijk.sh all
```



