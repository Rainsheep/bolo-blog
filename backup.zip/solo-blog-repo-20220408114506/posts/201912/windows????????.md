title: windows开机自动运行脚本
date: '2019-12-19 23:21:32'
updated: '2019-12-19 23:21:32'
tags: [windows]
permalink: /articles/2019/12/19/1576768892351.html
---
## 方法一

> 此方法登录时自启

* 登录自己用户时才能开机启动的启动文件夹。`C:\Users\10766\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup`
* 登录所有用户时都能开机启动的启动文件夹。
  `C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp`

## 方法二

> 注册表实现开机自启
> 在`HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Run`中添加字符串值，数值数据写 bat 的目录。
> ![p20191219111330.png](https://img.hacpai.com/file/2019/12/p20191219111330-beb1c282.png)

## 方法三

> 策略组自启动

运行`gpedit.msc`
计算机配置 &gt;Windows 设置 &gt; 脚本(启动/关机)
![p20191219111519.png](https://img.hacpai.com/file/2019/12/p20191219111519-71d83725.png)

双击启动 &gt; 添加 &gt; 浏览
![p20191219111707.png](https://img.hacpai.com/file/2019/12/p20191219111707-3e0acb76.png)

## 方法四

> 通过任务计划添加

计算机 &gt; 管理 &gt; 任务计划程序 &gt; 创建任务
![p20191219111927.png](https://img.hacpai.com/file/2019/12/p20191219111927-36df4795.png)

设置常规、触发器、操作、条件即可
![p20191219112056.png](https://img.hacpai.com/file/2019/12/p20191219112056-2b8377a8.png)
