title: mac 安装 redis
date: '2021-09-03 22:35:48'
updated: '2021-10-20 11:37:49'
tags: [nosql]
permalink: /articles/2021/09/03/1630679748847.html
---
参考文献：

[mac安装redis](https://www.jianshu.com/p/6d1bb631b39d)
[mac下安装redis](https://www.cnblogs.com/kermitjam/p/11193466.html)
[Mac 下 Redis 5.0 的卸载与安装](https://www.cnblogs.com/dear_diary/p/10363616.html)
[MAC安装和卸载redis](https://www.jianshu.com/p/a2deaab7c0e1)
[Homebrew安装redis](https://blog.csdn.net/zeal9s/article/details/101025410)

## 1. mac 卸载 redis

### 1.1 brew 安装方式卸载

```bash
brew uninstall redis
```

### 1.2 压缩包安装卸载

停止 redis 服务器

```shell
redis-cli shutdown
```

检测

```shell
#检测后台进程是否存在
ps -ef |grep redis

#检测6379端口是否在监听
netstat -lntp | grep 6379

#因为Redis可以妥善处理SIGTERM信号，所以直接 kill -9 进程id 也是可以关闭redis的
kill -9 PID
```

查看 redis 位置

```shell
which redis-server
/usr/local/bin/redis-server
```

删除 make 的时候产生的几个 redis 文件

```bash
rm -rf /usr/local/bin/redis*
```

删除 redis 文件夹

## 2. mac 安装 redis

### 2.1 brew 安装

```shell
brew install redis
```

### 2.2 压缩包安装

* redis 默认端口 6379
* 载mac版redis安装包,下载地址 https://redis.io/download
* ```
  解压:　　
      tar zxvf redis-4.0.14.tar.gz
  
  移动到:　　
      mv redis-4.0.14.tar.gz ~/software　　
  
  切换到:　　
      cd ~/software/redis-4.0.14/　　
  
  进入到解压后的文件夹下面,路径改成你自己的文件夹存放的路径
  
  编译测试: 
      sudo make test
  
  编译安装:　　
      sudo make install
  ```

## 3. redis 启动与停止

**方式一 (仅 brew 安装可用)**

```shell
// 启动
brew services start redis
// 查看状态
brew services
// 关闭服务
brew services stop redis
```

**方式二**

* 启动：redis-server
* 停止：redis-cli shutdown

> 如果在启动的时候提示: Address already in use.意思你的 6379 端口被占用
> 
> ps -ef | grep -i redis 找到进程，kill -9 pid 即可

