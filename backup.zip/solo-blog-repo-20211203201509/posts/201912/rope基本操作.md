title: rope基本操作
date: '2019-12-03 22:27:06'
updated: '2019-12-03 22:27:06'
tags: [STL, 知识点总结]
permalink: /articles/2019/12/03/1575383226457.html
---
在g++头文件中，<ext/rope>中有成型的块状链表，在using namespace 

__gnu_cxx;空间中，其操作十分方便。

基本操作：

rope test;

test.push_back(x);//在末尾添加x

test.insert(pos,x);//在pos插入x　　

test.erase(pos,x);//从pos开始删除x个

test.copy(pos,len,x);//从pos开始到pos+len为止用x代替

test.replace(pos,x);//从pos开始换成x

test.substr(pos,x);//提取pos开始x个

test.at(x)/[x];//访问第x个元素

其算法复杂度n*(n^0.5)，可以在很短的时间内实现快速的插入、删除和查找字符串，是一个很厉害的神器！
