title: activity 转场动画
date: '2021-06-25 14:30:49'
updated: '2021-06-25 14:30:49'
tags: [android]
permalink: /articles/2021/06/25/1624602649299.html
---
参考文献：

[View 动画几种特殊使用场景](https://github.com/OCNYang/Android-Animation-Set/blob/master/view-animation/ViewAnimationUseTips.md)
[实现 Activity 的切换动画](https://github.com/OCNYang/Android-Animation-Set/wiki/%E5%AE%9E%E7%8E%B0-Activity-%E7%9A%84%E5%88%87%E6%8D%A2%E5%8A%A8%E7%94%BB)

## 1. overridePendingTransition

**这种方法写着简单但是不好用**，通过 `overridePendingTransition`，他的两个参数分别是新 `Activity` 进入时的动画和旧 Activity 退出时的动画. 如果设置为 0 则没有动画。

这个方法必须跟在 `startActivity()` 或 `finish()` 后面才会生效。

还是先定义两个动画：

进入时的动画：

```xml
<set xmlns:android="http://schemas.android.com/apk/res/android">
    <translate
        android:fromXDelta="0"
        android:toXDelta="0"
        android:fromYDelta="100%"
        android:toYDelta="0"
        android:duration="2000" />
    <alpha
        android:fromAlpha="0"
        android:toAlpha="1"
        android:duration="2000" />
</set>
```

退出时的动画:

```xml
<set xmlns:android="http://schemas.android.com/apk/res/android">
    <translate
        android:fromXDelta="0"
        android:toXDelta="0"
        android:fromYDelta="0"
        android:toYDelta="-100%"
        android:duration="2000" />
    <alpha
        android:fromAlpha="1"
        android:toAlpha="0"
        android:duration="2000" />
</set>
```

跳转时调用：

```java
startActivity(new Intent(MainActivity.this,SecondActivity.class));
overridePendingTransition(R.anim.activity_in,R.anim.activity_out);
```

## 2. style

首先看 `res/values/styles.xml`。定义了一个叫 `ActivityAnim` 的 `style`，里面有四个属性，分表代表下面的含义

| 属性                        | 含义                                                      |
| --------------------------- | --------------------------------------------------------- |
| activityOpenEnterAnimation  | 打开一个新的 Activity 时，要显示的新的 Activit 执行的动画 |
| activityOpenExitAnimation   | 打开一个新的 Activity 时，当前的旧的 Activit 执行的动画   |
| activityCloseEnterAnimation | 关闭一个 activity 时，要显示的上一个 Activity 执行的动画  |
| activityCloseExitAnimation  | 关闭一个 activity 时，被关闭的 Activity 执行的动画        |

这四个动画可以针对需要只设置需要的。

把 ActivityAnim 设置给 App 要用的主题 AppTheme 的 `android:windowAnimationStyle` 属性

```xml
<resources>
    <style name="AppTheme" parent="Theme.AppCompat.Light.DarkActionBar">
        <item name="colorPrimary">@color/colorPrimary</item>
        <item name="colorPrimaryDark">@color/colorPrimaryDark</item>
        <item name="colorAccent">@color/colorAccent</item>
        <item name="android:windowAnimationStyle">@style/ActivityAnim</item>
    </style>
    <style name="ActivityAnim">
        <item name="android:activityOpenEnterAnimation">@anim/activity_in</item>
        <item name="android:activityOpenExitAnimation">@anim/activity_out</item>
        <item name="android:activityCloseEnterAnimation">@anim/activity_close_in</item>
        <item name="android:activityCloseExitAnimation">@anim/activity_close_out</item>
    </style>
</resources>
```

在后再清单文件里引用这个主题:

```xml
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.sunlinlin.animademo">
    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/AppTheme">
        <activity android:name=".MainActivity">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
        <activity android:name=".SecondActivity"></activity>
    </application>
</manifest>
```

上面的四个动画分别是：

activity_in：

```xml
<set xmlns:android="http://schemas.android.com/apk/res/android">
    <translate
        android:fromXDelta="0"
        android:toXDelta="0"
        android:fromYDelta="100%"
        android:toYDelta="0"
        android:duration="2000" />
    <alpha
        android:fromAlpha="0"
        android:toAlpha="1"
        android:duration="2000" />
</set>
```

activity_out:

```xml
<set xmlns:android="http://schemas.android.com/apk/res/android">
    <translate
        android:fromXDelta="0"
        android:toXDelta="0"
        android:fromYDelta="0"
        android:toYDelta="-100%"
        android:duration="2000" />
    <alpha
        android:fromAlpha="1"
        android:toAlpha="0"
        android:duration="2000" />
</set>
```

activity_close_in:

```xml
<set xmlns:android="http://schemas.android.com/apk/res/android">
    <translate
        android:fromXDelta="0"
        android:toXDelta="0"
        android:fromYDelta="-100%"
        android:toYDelta="0"
        android:duration="2000" />
    <alpha
        android:fromAlpha="0"
        android:toAlpha="1"
        android:duration="2000" />
</set>
```

activity_close_out:

```xml
<set xmlns:android="http://schemas.android.com/apk/res/android">
    <translate
        android:fromXDelta="0"
        android:toXDelta="0"
        android:fromYDelta="0"
        android:toYDelta="100%"
        android:duration="2000" />
    <alpha
        android:fromAlpha="1"
        android:toAlpha="0"
        android:duration="2000" />
</set>
```

