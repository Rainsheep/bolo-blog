title: brew 常用命令
date: '2020-10-31 00:16:54'
updated: '2020-10-31 00:16:54'
tags: [mac]
permalink: /articles/2020/10/31/1604074614109.html
---
### brew 控制服务

```
# 查看系统通过 brew 安装的服务
brew services list
# 清除已卸载无用的启动配置文件
brew services cleanup
# 启动服务
brew services start <formula>
# 关闭服务
brew services stop <formula>
# 重启服务
brew services restart <formula>
```

### 安装卸载

> 通过brew安装的文件会自动设置环境变量，所以不用担心命令行不能启动的问题。

```
# 显示 brew 版本信息
brew --version/-v
# 安装指定软件
brew install  <formula>
# 卸载指定软件
brew uninstall <formula>
# 显示所有已安装软件
brew list
# 搜索软件
brew search TEXT|/REGEX/
# 显示软件信息
brew info <formula>
```

### 升级软件相关

```
# 自动升级homebrew（从github下载最新版本）
brew update
# 检测已有新版本的软件
brew outdated 
# 升级所有软件
brew upgrade  
# 升级指定的软件
brew upgrade <formula>
# 禁止指定软件升级
brew pin <formula> 
# 解锁禁止升级
brew unpin <formula> 
# 升级所有的软件包，包括未清理干净的旧版本的包
brew upgrade --all 
```

### 清理相关

```
# 列出需要清理的内容
brew cleanup -n 
# 清理指定的软件过时包
brew cleanup <formula> 
# 清理所有的过时软件
brew cleanup 
# 卸载指定软件
brew unistall <formula> 
# 彻底卸载指定软件，包括旧版本
brew unistall <fromula> --force 
```
