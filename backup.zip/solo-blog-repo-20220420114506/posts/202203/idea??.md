title: idea 激活
date: '2022-03-18 13:03:47'
updated: '2022-03-18 13:10:23'
tags: [软件教程]
permalink: /articles/2022/03/18/1647579827912.html
---
参考文档：
[ja-netfilter](https://github.com/ja-netfilter/ja-netfilter)
[ja-netfilter-mymap-plus](https://github.com/zfkun/ja-netfilter-mymap-plugin)
[激活教程](https://bangkaixin.com/?p=62)
[介绍一个"牛逼闪闪"开源库：ja-netfilter](https://zhile.io/2021/11/29/ja-netfilter-javaagent-lib.html)

# 1. 介绍

此方法理论适用 JeBrains 全家桶所有版本，本文基于 2021.3.3 测试。

**原理**：防火墙原理，利用防火墙阻止**激活检测**。

**工具**：ja-netfilter

**官方介绍**：
我们通常会使用防火墙来阻断这些软件的恶意访问。但防火墙也不是万能的，比如：跨平台问题、https 下无法精准阻断某个 url 访问、部分防火墙不能阻断 dns 访问。
于是就有了我今天开源的这个项目：通用的、针对 java 程序的、灵活的、精准基于规则的、基于 AOP 思想的牛逼哄哄防火墙（无数狗头）：ja-netfilter！

# 2. 使用方式

## 2.1 下载

去 [ja-netfilter github](https://github.com/ja-netfilter/ja-netfilter/releases) 下载最新版，保存到自定义目录(不能删除)，我们基于 `/rainsheep/software` 目录。

## 2.2 配置文件

在 `/rainsheep/software/ja-netfilter/config` 目录下。

在 plugins 目录下有一些插件(dns.jar,url.jar 等)，对应的配置文件名为 `插件名.conf`。

我们使用 url 和 dns 两个配置。

**dns.conf**

```
[DNS]
EQUAL,jetbrains.com
```

**url.conf**

```
[URL]
PREFIX,https://account.jetbrains.com/lservice/rpc/validateKey.action
```

## 2.3 使用

我们在 JVM Options file 添加如下内容即可使用(修改为自己的路径)。

```
-javaagent:/rainsheep/software/ja-netfilter/ja-netfilter.jar
```

我这边介绍两种方式

### 2.3.1 使用 Toolbox App

在 Toolbox App ，打开对应软件设置

![image.png](https://oss.rainsheep.cn/blog/fe5dad4c65eb46f73ec0e4cd6f5f4d11-20220318130023779-1647579623-913.png)

![image.png](https://oss.rainsheep.cn/blog/cfcd49ce755decbee0b25f4bc6f05a08-1647579550-a3e.png)

修改配置文件，添加上述那一行代码，重启即可。

### 2.3.2 直接启动软件

> 此方式需要保证软件目前处于可用状态(激活或试用)。
> 或者我们直接修改 vm 文件

![image.png](https://oss.rainsheep.cn/blog/f70a1dc539afc4c25e12518543d27e39-1647579728-c37.png)

点击编辑，加入上面那行代码，重启即可。

# 3. ja-netfilter-mymap-plugin

此插件为 ja-netfilter 的插件，功能为 自定义点击激活界面的显示信息，除了修改 UI 没啥作用，可选。

[下载](https://github.com/zfkun/ja-netfilter-mymap-plugin/releases) 插件，放置到 ja-netfilter 的 plugins 目录。

在 conf 目录下新建配置文件，mymap.conf

```
[MyMap]
EQUAL,licenseeName->Rainsheep
EQUAL,gracePeriodDays->100000 
EQUAL,paidUpTo->5000-12-31
```

重启后，打开注册信息可以看到

![image-20220318130818987](https://oss.rainsheep.cn/blog/image-20220318130818987-1647580099-443.png)

