title: ssh 用户配置
date: '2021-11-12 19:50:48'
updated: '2021-11-22 15:06:41'
tags: [Linux]
permalink: /articles/2021/11/12/1636717848438.html
---
参考文献: [SSH自动登录config文件配置](https://www.cnblogs.com/wuqinglong/p/11379245.html)

> 确保本地 .ssh 下有密钥

## 1. 配置服务端

将本机的 `~/.ssh/id_rsa.pub` 文件配置到服务器的 `~/.ssh/authorized_keys` 文件中。

使用 ssh-copy-id 进行上传，运行 `ssh-copy-id xxx@0.0.0.0` 会自动将公钥追加到 authorized_keys 文件中。

注意：`.ssh` 目录的权限和 authorized_keys 的权限分别是 700 和 600。

## 2. 配置客户端

配置好服务端之后我们就可以使用 `ssh user@host` 直接登录服务器了，不需要输入密码，那么我们还得记住 user 和 host，还有更简单的方法吗？那当然啦。

配置 `~/.ssh/config` 文件

```
Host {name}
    HostName {host}
    User {user}
    IdentityFile ~/.ssh/id_rsa
Host {name}
    HostName {host}
    Port {port}
    User {user}
    IdentityFile ~/.ssh/id_rsa2
```

ssh {name} 直接登陆

## 3. git 多用户配置

当我们的项目需要使用特定的 ssh 配置的话。

打开项目的 `.git/confug`，将 hostname 改为我们的 host 别名。

比如：

```
url = git@github.com:Lapisy/RecyclerViewSample.git
```

改为

```
url = git@github:Lapisy/RecyclerViewSample.git
```

就能使用特定的配置

