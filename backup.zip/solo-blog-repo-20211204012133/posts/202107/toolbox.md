title: toolbox
date: '2021-07-29 17:53:17'
updated: '2021-07-29 17:53:17'
tags: [软件教程]
permalink: /articles/2021/07/29/1627552397068.html
---
JetbBrains Toolbox 工具用来管理 JetbBrains 下所有 IDE，十分好用。

下载地址：https://www.jetbrains.com/zh-cn/toolbox-app/

可以进行 安装、卸载、多版本管理、回滚降级、即时打开项目等多个功能。

使用发现，没办法识别手动安装的，需要将手动安装的删除，否则会有多版本存在。



