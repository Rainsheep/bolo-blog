title: Activity
date: '2021-03-31 15:08:35'
updated: '2021-03-31 15:08:35'
tags: [android]
permalink: /articles/2021/03/31/1617174515693.html
---
## 1. 生命周期

### 1.1 返回栈

android 是使用任务(Task)来管理活动的，一个任务就是一组存放在栈里的活动的集合，这个栈也被称作返回栈(Back Stack)，默认情况下每当我们启动一个新活动，他会在返回栈中入栈，并处于栈顶位置，每当我们按下 Back 键或调用 finish() 方法去销毁一个活动时，处于栈顶的活动会出栈，这时前一个入站的活动会重新处于栈顶的位置，系统总是会显示处于栈顶的活动给用户。

### 1.2 活动的状态

**运行状态**: 当一个活动位于返回栈的栈顶时，这活动就位于运行状态。系统最不愿意回收的就是运行状态的活动，因为这会带来非常差的用户体验。

**暂停状态**: 当一个活动不再处于栈顶位置，但任然可见时，这时活动就进入了暂停状态。因为不是每一个活动都会占满整个屏幕的，比如对话框形式的活动只会占用屏幕中间的部分区域。处于暂停状态的活动任然是完全存活的，系统也不愿意去回收这种活动（因为它依然可见，回收可见的东西都会对用户体验有不好的影响。）只有在内存极低的情况下，系统才会考虑去回收这种活动。

**停止状态:** 当一个活动不再处于栈顶位置，并且完全不可见的时候，就进入了停止状态。系统任然会为这种活动保存相应的状态和成员变量，但这并不是完全可靠的，当其他地方需要内存时，处于停止状态的活动就有可能会被系统回收。

**销毁状态**: 当一个活动从返回栈中移除后就变成了销毁状态。系统会最倾向与回收处于这种状态的活动，从而保证手机内存充足。

### 1.3 生命周期

| 方法        | 简介                                                         |
| ----------- | ------------------------------------------------------------ |
| onCreate()  | 它会在活动第一次被创建的时候调用。我们应该在这个方法中完成活动的初始化操作，比如加载布局、绑定事件等。 |
| onStart()   | 这个方法在活动由不可见变为可见的时候调用。                   |
| onResume()  | 这个方法在活动准备好和用户交互时调用，此时的活动一定处于返回栈的栈顶，并且处于运行状态。 |
| onPause()   | 这个方法在系统准备去启动或者恢复另一个活动的时候调用。我们通常会在这个方法中将一些消耗CPU的资源释放掉，以及保存一些关键的数据，但这个方法的执行速度一定要快，不然会影响到新的栈活动的使用。 |
| onStop()    | 这个方法在活动完全不可见的时候调用。它和onPause()方法的主要区别在于，如果启动的新活动是一个对话框式的活动，那么onPause()方法会被执行，而onStop()并不会执行。 |
| onDestroy() | 这个方法在活动被销毁之前调用，之后活动的状态讲变为销毁状态。 |
| onRestart() | 这个方法在活动由停止状态变为运行状态之前调用，也就是活动被重新启动了。 |

以上7个方法除了 onRestart()，其他都是亮亮对应的，从而又可以讲活动分为3种生存期。

* **完整生存期**： 活动在 onCreate() 方法和 onDestroy() 方法之间所经历的，就是完整生存期。一般情况下，活动会在 onCreate() 方法中完成各种初始化操作，在 onDestroy() 方法完成释放内存的操作。
* **可见生存期**： 活动在 onStart() 方法和 onStop() 方法之间所经历的，就是可见生存期。在可见生存期内，活动对用户总是可见的，即便有可能无法和用户进行交互。我们可以通过这两个方法，合理地管理那些对用户可见的资源。比如在 onStart()方 法中对资源进行加载，而在 onStop() 中对资源进行释放，从而保证处于停止状态的活动不会占用过多内存。
* **前台生存期**： 活动在 onResume() 方法和 onPause() 方法之间所经历的就是前台生存期。在前台生存期内，活动总是处于运行状态，此时的活动是可以和用户进行交互的，我们平时看到和接触最多的也就是这个状态下的活动。

![18364230.jpg](https://b3logfile.com/file/2021/03/18364230-96e4ee82.jpg)

### 1.4 活动被回收了怎么办

当一个 活动进入到了停止状态，是有可能被系统回收的。想象以下场景：应用中有一个活动 A，用户在 A 的基础上启动了 B，活动 A 进入了停止状态。这个时候由于系统内存不足，将活动 A 回收了，然后用户按 Back 键返回活动，这个时候活动 A 会正常显示，只不过这个时候并不会执行 onRestart() 方法，而是执行活动 A 的 onCreate() 方法，因为活动 A 在这种情况下会被重新创建一次。

当我们的应用出现了这种情况，是非常影响用户体验的，所以必须解决这个问题，查阅文档可知 Activity 中还提供了一个 onSaveInstanceStart() 回调方法，这个方法在活动回收前一定会调用，因此我们可以通过这个方法来解决活动被回收时 数据得不到保存的问题。

onSaveInstanceStart() 会携带一个 Bundle 类型的参数， Bundle 提供了一系列的方法用于保存数据，每个保存的方法都要传入两个参数，第一个是键，第二个是要保存的内容。

```java
@Override
public void onSaveInstanceState(Bundle outState, PersistableBundle outPersistentState) {
    super.onSaveInstanceState(outState, outPersistentState);
    String tempData = "Something you just type";
    outState.putString("data",tempData);
}
```

数据以及保存下来了，然后我们要在 onCreate() 方法里面进行恢复，细心地你也许早就发现 onCreate() 方法也有一个参数，这个参数一般情况下是 null，但是如果活动被系统回收之前使用 onSaveInstanceStart() 方法来保存过数据的话，这个参数就会携带我们之前保存的全部数据。

```java
@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    if (savedInstanceState != null){
        String temp = savedInstanceState.getString("data");
        Toast.makeText(this, "" + temp, Toast.LENGTH_SHORT).show();
    }
}
```

恢复数据也可以在 onRestoreInstanceState 方法中执行。这个方法 会在 onCreate 之后执行

```java
@Override
protected void onRestoreInstanceState(Bundle savedInstanceState) {
    super.onRestoreInstanceState(savedInstanceState);
    if (savedInstanceState != null){
        Log.e(TAG, "onRestoreInstanceState: "+savedInstanceState.getString("data") );
    }
}
```

## 2. 活动的启动模式

参考 ：[活动的启动模式](https://blog.csdn.net/qq_39899087/article/details/86510252)

### 2.1 standard 模式

默认的启动模式，使用返回栈来管理活动。在 standard 模式下，每当启动一个新的活动，就会在返回栈中入栈，并处于栈顶的位置。

对于使用 standard 模式的活动，系统不在乎该活动是否在返回栈已存在，每次启动都会创建该活动一个新的实例。

FirstActivity 类：

```java
public class FirstActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("FirstActivitys",this.toString());
        setContentView(R.layout.activity_frist);
        Button button_1 = findViewById(R.id.button_1);
        button_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FirstActivity.this,FirstActivity.class);
                startActivity(intent);
            }
        });

    }
}
```

运行程序，连续点击 FirstActivity 界面的按钮2次，可以看到在 logcat 中打印信息：

![20190116175748671.png](https://b3logfile.com/file/2021/03/20190116175748671-87e825e4.png)

根据打印信息我们可以知道，每点击一次按钮，就创建出一个新的 FirstActivity 实例。此时返回栈中也存在3个 FirstActivity 的实例，因此需要点击3次back键才能退出程序。

### 2.2 singleTop 模式

在该模式下，启动活动时若发现返回栈的栈顶已经有该活动，则认为可以直接使用它，不会再创建新的活动实例。

实践一下，在 AndroidManifest.xml 文件中添加活动启动模式：

```xml
<activity
    android:name=".FirstActivity"
    android:launchMode="singleTop"
    android:label="FirstActivity">
    <intent-filter>
        <action android:name="android.intent.action.MAIN" />

        <category android:name="android.intent.category.LAUNCHER" />
    </intent-filter>
</activity>
```

![20190116175954696.png](https://b3logfile.com/file/2021/03/20190116175954696-30c7b22d.png)

无论点击几次按钮，打印的数据只有一条，只创建了一次 FirstActivity。因为目前 FirstActivity 已经处于返回栈的栈顶，所有每当需要启动 FirstActivity 活动时会直接使用栈顶的活动，因此 FirstActivity 只有一个实例，点击一次 back 键即可退出程序。

当 FirstActivity 不在栈顶位置时，再次启动 FirstActivity 仍然会创建新的实例。
创建一个新的活动 SecondActivity 实践：
SecondActivity类：

```java
public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("SecondActivity",this.toString());
        setContentView(R.layout.activity_second);
        Intent intent = new Intent(SecondActivity.this,FristActivity.class);
        startActivity(intent);
    }
}
```

修改 FirstActivity:

```java
public class FirstActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("FirstActivitys",this.toString());
        setContentView(R.layout.activity_frist);
        Button button_1 = findViewById(R.id.button_1);
        button_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FirstActivity.this,SecondActivity.class);
                startActivity(intent);
            }
        });

    }
}
```

![20190116172443766.png](https://b3logfile.com/file/2021/03/20190116172443766-582faa32.png)

系统创建了两个不同的 FirstActivity 实例， 因为在启动 SecondActivity 时，栈顶不再是 FirstActivity 变成了 SecondActivity,因此在 SecondActivity 界面点击跳转到 FirstActivity 界面，会再次创建新的 FirstActivity 实例。
现在点击 back 按钮，会返回到 SecondActivity 界面，再次点击 back 按钮返回 FirstActivity 界面，再次点击才能退出程序。

### 2.3 singleTask 模式

在该模式下，每次启动活动时先在返回栈检查是否存在该活动的实例。如果存在，直接使用该实例，并把在这个活动之上的所有活动统统出栈；如果不存在，则会创建一个新的活动实例。
首先修改 AndroidMainfest：

```xml
<activity
    android:name=".FirstActivity"
    android:launchMode="singleTask"
    android:label="FirstActivity">
    <intent-filter>
        <action android:name="android.intent.action.MAIN" />

        <category android:name="android.intent.category.LAUNCHER" />
    </intent-filter>
</activity>
```

运行程序，在 FirstActivity 界面中点击按钮进入 SecondActivity 界面，然后在 SecondActivity 界面中点击按钮，从新进入 FirstActivity。
运行程序，观察 logcat 的打印信息：

![20190116183708499.png](https://b3logfile.com/file/2021/03/20190116183708499-b4377144.png)

从 secondActivity 点击按钮到 FirstActivity ,因为返回栈中已经有 FirstActivity(栈底)，SecondActivity(栈顶)，所以不需要重新创建 FirstActivity 活动实例，SecondActivity 出栈，FirstActivity 重新成为了栈顶活动，直接被使用。因此 FirstActivity 的 onRestart() 方法和 SecondActivity 的 onDestory 方法被执行。现在返回栈只剩下 FirstActivity 的实例，直接点击一下返回按钮，退出程序。

### 2.4 singleInstace 模式

该模式下的活动会启用一个新的返回栈来管理这个活动。在这种模式下会有一个单独的返回栈来管理这个活动，不管哪个应用程序来访问这个活动，都共用同一个返回栈，解决了共享活动实例的问题。
首先修改 AndroidMainfest（针对 SeconActivity）：

```xml
<activity
    android:name=".SecondActivity"
    android:label="SecondActivty"
    android:launchMode="singleInstance"/>
```

FirstActivity

```java
@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    Log.d("FirstActivitys","Task id is " + getTaskId());
    setContentView(R.layout.activity_frist);
    Button button_1 = findViewById(R.id.button_1);
    button_1.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(FirstActivity.this,SecondActivity.class);
            startActivity(intent);
        }
    });
}
```

SecondActivity

```java
@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    Log.d("SecondActivitys","Task id is " + getTaskId());
    setContentView(R.layout.activity_second);
    Button button_2 = findViewById(R.id.button_2);
    button_2.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(SecondActivity.this,ThirdActivity.class);
            startActivity(intent);
        }
    });
}
```

ThirdActivity

```java
@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    Log.d("ThirdActivitys","Task id is " + getTaskId());
    setContentView(R.layout.activity_third);
}
```

![20190116190945212.png](https://b3logfile.com/file/2021/03/20190116190945212-fd589e44.png)

可以看出，SeconActivity 的 Task id 不同于 FirstActivity 和 ThridActivty，说明 SecondActivity 存放在一个单独的返回栈中，而且这个栈中只有 SecondActivity 这一个活动。
点击返回按钮会进入 FirstActivity 中，再点击返回按钮，会进入 SecondActivity 中，再次点击返回按钮才能退出程序。这是因为 FirstActivity(栈底) 和 ThridActivity(栈顶) 在同一个返回栈，所以点击返回，ThirdActivity 抛出，FirstActivity 呈现；再次点击返回按钮，FirstActivity 抛出，该栈为空，进入下一个栈，显示新栈的SecondActivity 活动实例；再次点击，两个栈都为空，退出程序。

## 3. 小技巧

### 3.1 判断当前界面处于哪个 activity

```java
public class BaseActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("BaseActivity", getClass().getSimpleName());
    }
}
```

让所有 Activity 继承此 activity

### 3.2 随时随地退出程序

如果程序运行后有多个 Activity 压在程序栈，但是想在任何一个 Activity 退出程序，并销毁所有 Activity，该怎么办呢？

新建一个活动管理器类，每次新建一个Activity 时，就把新建的实例交给该管理器类进行管理，在必要的时候，随时调用该管理器类来销毁所有 Activity 实例。

```java
public class ActivityCollector {
    public static List<Activity> activities = new ArrayList<>();

    public static void addActivity(Activity activity) {
        activities.add(activity);
    }

    public static void removeActivity(Activity activity) {
        activities.remove(activity);
    }

    public static void finishAll() {
        for (Activity activity : activities) {
            if (!activity.isFinishing()) {
                activity.finish();
            }
        }
    }
}
```

然后修改 BaseActivity

```java
public class BaseActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("BaseActivity", getClass().getSimpleName());
        ActivityCollector.addActivity(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ActivityCollector.removeActivity(this);
    }
}
```

当想要退出程序时，调用 finishAll() 方法即可。

```java
ActivityCollector.finishAll();
// 杀死当前进程，保证完全退出
android.os.Process.killProcess(android.os.Process.myPid());
```

### 3.3 启动活动的最佳写法

```java
public class SecondActivity extends BaseActivity {
    public static void actionStart(Context context, String data1, String data2) {
        Intent intent = new Intent(context, SecondActivity.class);
        intent.putExtra("param1", data1);
        intent.putExtra("param2", data2);
        context.startActivity(intent);
    }
}
```

调用此方法即可，清晰知道要传哪些参数，不需要关注 key。

