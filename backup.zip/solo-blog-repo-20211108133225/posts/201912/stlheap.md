title: ' stl-heap'
date: '2019-12-03 20:49:17'
updated: '2019-12-03 20:49:17'
tags: [STL, acm]
permalink: /articles/2019/12/03/1575377357220.html
---
头文件 algorithm

make_heap();建堆，大顶堆从小到大排序，小顶堆从大到小排序

pop_heap();把第一个和最后一个调换，然后把[first,end-1]重新构堆

push_heap();假设一开始是个有效堆，加进来一个或者一组元素重新构堆

sort_heap();堆排序

```cpp
#include<iostream>
#include<algorithm>
#include<vector>
#include<functional>
using namespace std;
void print(vector<int> v) {
	for (int i = 0; i < v.size(); i++)
		cout << v[i] << " ";
	cout << endl;
}
int main() {
	int s[] = { 10,20,30,5,15 };
	vector<int> v(s, s + 5);
	make_heap(v.begin(), v.end());//构建大顶堆
	//make_heap(v.begin(), v.end(), greater<int>());构建小顶堆
	print(v);
	pop_heap(v.begin(), v.end());//pop_heap不是删除某个元素而是把第一个和最后一个元素对调后[first,end-1]进行构树，最后一个不进行构树
	v.pop_back();//删除最后一个的结点
	print(v);
	v.push_back(99);//在最后增加一个结点
	push_heap(v.begin(), v.end());//重新构树
	print(v);
	sort_heap(v.begin(), v.end());//把树的结点的权值进行排序
	print(v);
	return 0;
}

```
