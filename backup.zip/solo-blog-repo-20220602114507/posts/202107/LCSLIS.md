title: LCS -> LIS
date: '2021-07-26 11:50:42'
updated: '2021-07-26 11:50:42'
tags: [DP]
permalink: /articles/2021/07/26/1627271442508.html
---
一道很有意思的将 lcs(最长公共子序列) 转换为了 lis(最长增长子序列) 的问题。

题目链接 ：[1713. 得到子序列的最少操作次数](https://leetcode-cn.com/problems/minimum-operations-to-make-a-subsequence/)

题解链接：https://leetcode-cn.com/problems/minimum-operations-to-make-a-subsequence/solution/de-dao-zi-xu-lie-de-zui-shao-cao-zuo-ci-hefgl/



