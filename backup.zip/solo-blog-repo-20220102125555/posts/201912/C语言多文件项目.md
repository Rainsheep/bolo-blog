title: C语言 多文件项目
date: '2019-12-03 21:05:34'
updated: '2019-12-03 21:05:34'
tags: [知识点总结]
permalink: /articles/2019/12/03/1575378334515.html
---
将所有文件放到一个项目下，可以一次编译所有 cpp 文件，通过 main 文件引用别文件中函数的方法：将所有函数声明在一个.h 文件中，在需要调用这个函数的文件中#include&quot;.h&quot;即可（文件前面加上#pragma once，可以保证头文件只被编译一次，避免一些错误）

#include&lt;&gt; 首先查找类库目录下的头文件

#include&quot;&quot;首先查找当前目录下的头文件

例如：

```c
head.h
void fun1();
void fun2();
```

```c
main.cpp
#include<iostream>
#include"head.h"
using namespace std;
int main(){
	fun1();
	fun2();
}
```

```c
fun1.cpp
#pragma once
#include<iostream>
using namespace std;
void fun1(){
	cout<<"1"<<endl;
}
```

```c
fun2.cpp
#pragma once
#include<iostream>
using namespace std;
void fun2(){
	cout<<"2"<<endl;
}
```
