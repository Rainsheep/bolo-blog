title: druid 丢弃连接
date: '2022-03-04 15:22:58'
updated: '2022-03-04 15:22:58'
tags: [druid]
permalink: /articles/2022/03/04/1646378578003.html
---
```java
// 丢弃连接
public void discardConnection(DruidConnectionHolder holder) {
    if (holder == null) {
        return;
    }

    Connection conn = holder.getConnection();
    if (conn != null) {
        // close 掉真正的连接对象，一般调用该方法传入的 connection 对象都是最原始的驱动连接对象，所以这里并不会触发 recycle
        JdbcUtils.close(conn);
    }

    lock.lock();
    try {
        if (holder.discard) {
            return;
        }

        if (holder.active) {
            // 活跃连接数 -1
            activeCount--;
            holder.active = false;
        }
        // 丢弃连接数 +1
        discardCount++;

        holder.discard = true;

        if (activeCount <= minIdle) {
            // 唤起一次主流程3新增连接
            emptySignal();
        }
    } finally {
        lock.unlock();
    }
}
```

