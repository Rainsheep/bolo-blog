title: PAT排名汇总
date: '2019-12-03 13:05:41'
updated: '2019-12-03 13:05:41'
tags: [acm, STL, 模拟]
permalink: /articles/2019/12/03/1575349541564.html
---
# 输入格式:
输入的第一行给出一个正整数N（\le≤100），代表考点总数。随后给出N个考点的成绩，格式为：首先一行给出正整数K（\le≤300），代表该考点的考生总数；随后K行，每行给出1个考生的信息，包括考号（由13位整数字组成）和得分（为[0,100]区间内的整数），中间用空格分隔。

# 输出格式:
首先在第一行里输出考生总数。随后输出汇总的排名表，每个考生的信息占一行，顺序为：考号、最终排名、考点编号、在该考点的排名。其中考点按输入给出的顺序从1到N编号。考生的输出须按最终排名的非递减顺序输出，获得相同分数的考生应有相同名次，并按考号的递增顺序输出。

# 输入样例:
```
2
5
1234567890001 95
1234567890005 100
1234567890003 95
1234567890002 77
1234567890004 85
4
1234567890013 65
1234567890011 25
1234567890014 100
1234567890012 85
```

# 输出样例：
```
9
1234567890005 1 1 1
1234567890014 1 2 1
1234567890001 3 1 2
1234567890003 3 1 2
1234567890004 5 1 4
1234567890012 5 2 2
1234567890002 7 1 5
1234567890013 8 2 3
```

1234567890011 9 2 4
学号不能Longlong，存入vectore的数据是个副本，修改里面的数据无法传到外边，即原来数据不会被修改，且vectore不能引用(vectore<int&>)，只能传入指针，修改原数据。注意调用数据的方式，(*it)->score，必须加括号，->优先级大于\*



```c++
#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
struct node
{
	string num;//不能用Longlong，longlong第一位为0会自动删除 
	int score;
	int sumrank;
	int rank;
	int work;
}student[30005];//存学生信息 
bool cmp(node* a,node* b)
{
	if(a->score!=b->score)
	return a->score>b->score;
	return a->num<b->num;
}//比较函数，分数不等按学号排 
int main()
{
	int T,t,n,i,j,k,s=0;
	vector<node*> q;//vector存指向结构体的指针 
	vector<node*>::iterator it;
	cin>>T;
	for(i=1;i<=T;i++)
	{
		q.clear();//清空，否则会在原基础上存数据 
		cin>>n;
		while(n--)
		{
			cin>>student[s].num>>student[s].score;
			student[s].work=i;
			q.push_back(&student[s]);//压入结构体的指针 
			s++;//学生数量加1 
		}
		sort(q.begin(),q.end(),cmp);
		(*q.begin())->rank=1;//注意这地方的运用，(*q.begin())是指向结构体的指针，必须加括号，->的优先级大于*，*a.b等级于a->b 
		for(it=q.begin()+1,j=2;it!=q.end();it++,j++)
		{
			(*it)->rank=j;//(*it)是结构体的地址 
			if((*it)->score==(*(it-1))->score)(*it)->rank=(*(it-1))->rank;
		}	
	}
   q.clear();
   for(i=0;i<s;i++)
   q.push_back(&student[i]);
	
	
		sort(q.begin(),q.end(),cmp);
	(*q.begin())->sumrank=1;
	for(it=q.begin()+1,j=2;it!=q.end();it++,j++)
	{
		(*it)->sumrank=j;
		if((*it)->score==(*(it-1))->score) (*it)->sumrank=(*(it-1))->sumrank;
	}
	
	cout<<s<<endl;
	for(i=0;i<s;i++)
	cout<<q[i]->num<<" "<<q[i]->sumrank<<" "<<q[i]->work<<" "<<q[i]->rank<<endl;
	
}

```
