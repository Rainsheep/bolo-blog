title: Ubuntu最小化所有窗口
date: '2020-07-17 12:23:32'
updated: '2020-07-17 12:23:32'
tags: [Linux]
permalink: /articles/2020/07/17/1594959812671.html
---
参考：[Super + D键快捷键不显示桌面](https://ubuntuqa.com/article/1509.html)

前置步骤：设置→键盘→快捷键→导航→隐藏全部正常窗口→快捷键设置为 `super+D`

问题：`ctrl+super+D` 可以最小化所有窗口，`super+D`无法最小化所有窗口

解决方法：设置→外观→行为→勾选添加显示桌面图标到启动器
