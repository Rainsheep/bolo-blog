title: tomcat 相关知识
date: '2020-02-24 05:16:41'
updated: '2020-02-24 16:45:40'
tags: [Java]
permalink: /articles/2020/02/24/1582492601874.html
---
* Tomcat 端口号被占用的解决方案：

  * 杀掉占用端口的进程：`netstat -ano` ，查看占用端口的进程的 PID，然后去任务管理器结束此进程。
  * 修改自身端口号。
* Tomcat 的关闭：

  * `bin/shutdown.bat`
  * 在启动的黑窗口按 ctrl+c 结束进程。
* Tomcat 部署项目的方式：

  * 直接将项目文件夹或者 war 包 放到 webapps 目录下即可。
    * 使用 war 包的时候，war 包会自动解压，删除 war 包也会将对应文件夹删除。
    * 缺点：当有项目出错的时候，会导致别的项目无法成功部署。
  * 配置 `conf/server.xml` 文件（不推荐这种方式）
    * 在 `<Host>` 标签体中配置 `<Context docBase="D:\hello" path="/hehe" />`
      * docBase：项目存放的路径
      * path：虚拟目录
  * 在 `conf\Catalina\localhost` 创建任意名称的 XML 文件。在文件中编写 `<Context docBase="D:\hello" />`，XML 的文件名即为项目的虚拟路径。（推荐这种方式）
* Java 动态项目的目录结构：

  ```
  -- 项目根目录
    -- WEB-INF目录
      -- web.xml：web项目的核心配置文件
      -- classes目录：放置 class 文件和 src 目录下资源文件的目录
      -- lib目录：放置项目依赖的 jar 包
    -- jsp文件、静态资源文件等资源
  ```
* WEB-INF 目录下的资源不能被浏览器直接访问。
* IDEA 中 out 目录下 artifacts 文件夹的结构即为上述结构，IDEA 将项目发布到 Tomcat 的时候，会先编译 Java 文件，然后将 class 文件和 src 目录下的资源文件放置在 WEB-INF\classes 目录中，然后将整个 Web 文件夹弄成 war_exploded 部署到 Tomcat 服务器上。
* IDEA 会为每一个添加了 Tomcat 的项目单独建立一份配置文件

  * 查看控制台的 log：Using CATALINA_BASE：`C:\Users\10766\.IntelliJIdea2019.1\system\tomcat\Tomcat_8_5_45_workspace`
* 工作空间项目和 Tomcat 部署的 Web 项目

  * 工作空间：`out\artifacts`
  * Tomcat 部署的 Web 项目：`C:\Users\10766\.IntelliJIdea2019.1\system\tomcat\Tomcat_8_5_45_workspace\conf\Catalina\localhost\XML文件`
    * `<Context path="/javaweb_war_exploded" docBase="C:\Users\10766\Desktop\mycode\IDEA\workspace\out\artifacts\javaweb_war_exploded" />`
    * path 为虚拟路径，docBase 为项目所在位置
  * Tomcat 真正访问的是“Tomcat 部署的 Web 项目”，"tomcat 部署的 Web 项目"对应着"工作空间项目" 的 Web 目录下的所有资源。
