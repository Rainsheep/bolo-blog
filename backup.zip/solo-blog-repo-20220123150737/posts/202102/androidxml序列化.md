title: android xml 序列化
date: '2021-02-25 01:40:58'
updated: '2021-02-25 01:40:58'
tags: [android]
permalink: /articles/2021/02/25/1614188458515.html
---
xml 的序列化：

```java
//获取xml序列化器
 XmlSerializer serializer = Xml.newSerializer();
//给序列化器设置一个输出
serializer.setOutput(openFileOutput("smslist.xml", MODE_PRIVATE), "utf-8");
//写文档开始的声明<?xml version="1.0"?>
serializer.startDocument("utf-8", true);
//第一个参数 名称空间 如果当前文档受某份schema约束就传入一个名称空间 没有约束的情况传null
//<SMSList>
serializer.startTag(null, "SMSList");
serializer.text(sms.from);
serializer.endTag(null, "from");
```

xml 的解析：

```java
//获取xml解析器
XmlPullParser pullParser = Xml.newPullParser();
// 解析下一行
eventType = pullParser.next();
// 判断是否结束
int eventType = pullParser.getEventType();
if (eventType != XmlPullParser.END_DOCUMENT)
```

**实例**

```java
public class MainActivity extends Activity {
    ArrayList<SMS> smsList = new ArrayList<SMS>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        for (int i = 0; i < 30; i++) {
            SMS sms = new SMS();
            sms.from = "10000" + i;
            sms.content = "content" + i;
            sms.time = "2016-9-4 16:25:" + i;
            smsList.add(sms);
        }

        for (SMS sms : smsList) {
            System.out.println(sms);
        }

    }

    // 通过 StringBuilder 实现 xml 序列化
    public void saveSMS(View v) {
        StringBuilder sb = new StringBuilder();
        //写xml的文档声明
        sb.append("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
        sb.append("<SMSList>");
        for (SMS sms : smsList) {
            //写每一个sms开始的标签
            sb.append("<SMS>");

            //一个属性一个属性写对应的节点
            sb.append("<from>");
            sb.append(sms.from);
            sb.append("</from>");

            sb.append("<content>");
            sb.append(sms.content);
            sb.append("</content>");

            sb.append("<time>");
            sb.append(sms.time);
            sb.append("</time>");

            sb.append("</SMS>");
        }
        sb.append("</SMSList>");

        String xml = sb.toString();
        try {
            FileOutputStream fos = openFileOutput("sms.xml", MODE_PRIVATE);
            fos.write(xml.getBytes());
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 通过 xml 序列化器实现
    public void saveSMS2(View v) {
        //获取xml序列化器
        XmlSerializer serializer = Xml.newSerializer();
        //给序列化器设置一个输出
        try {
            serializer.setOutput(openFileOutput("smslist.xml", MODE_PRIVATE), "utf-8");
            //写文档开始的声明<?xml version="1.0"?>
            serializer.startDocument("utf-8", true);
            //第一个参数 名称空间 如果当前文档受某份schema约束就传入一个名称空间 没有约束的情况传null
            //<SMSList>
            serializer.startTag(null, "SMSList");
            for (SMS sms : smsList) {
                //写<SMS>
                serializer.startTag(null, "SMS");

                serializer.startTag(null, "from");
                serializer.text(sms.from);
                serializer.endTag(null, "from");

                serializer.startTag(null, "content");
                serializer.text(sms.content);
                serializer.endTag(null, "content");

                serializer.startTag(null, "time");
                serializer.text(sms.time);
                serializer.endTag(null, "time");

                //</SMS>
                serializer.endTag(null, "SMS");
            }

            //</SMSList>
            serializer.endTag(null, "SMSList");
            serializer.endDocument();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 解析 xml
    public void parseSMS(View v) {
        ArrayList<SMS> SMSs = null;
        SMS sms = null;
        //获取xml解析器
        XmlPullParser pullParser = Xml.newPullParser();
        //设置一个输入
        try {
            pullParser.setInput(openFileInput("sms.xml"), "utf-8");
            //获取事件类型
            int eventType = pullParser.getEventType();
            //只要没解析到文档结束就一直解析
            while (eventType != XmlPullParser.END_DOCUMENT) {
                switch (eventType) {
                    case XmlPullParser.START_TAG:
                        if ("SMSList".equals(pullParser.getName())) {
                            //创建集合
                            SMSs = new ArrayList<SMS>();
                        } else if ("SMS".equals(pullParser.getName())) {
                            //创建对象
                            sms = new SMS();
                        } else if ("from".equals(pullParser.getName())) {
                            //保存from属性
                            sms.from = pullParser.nextText();
                        } else if ("content".equals(pullParser.getName())) {
                            //保存content属性
                            sms.content = pullParser.nextText();
                        } else if ("time".equals(pullParser.getName())) {
                            //保存time属性
                            sms.time = pullParser.nextText();
                        }
                        break;
                    case XmlPullParser.END_TAG:
                        if ("SMS".equals(pullParser.getName())) {
                            //把对象添加到集合
                            SMSs.add(sms);
                        }
                        break;
                }
                eventType = pullParser.next();
            }
            for (SMS sms1 : SMSs) {
                System.out.println(sms1);
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
```



