title: JSON 学习笔记
date: '2020-02-29 15:05:18'
updated: '2020-03-09 18:30:05'
tags: [学习笔记]
permalink: /articles/2020/02/29/1582959918244.html
---
### 1. JSON 基础

* 概念： JavaScript Object Notation，JavaScript 对象表示法
* * JSON 现在多用于存储和交换文本信息的语法
  * 进行数据的传输
  * JSON 比 XML 更小、更快，更易解析。
* 定义规则

  * 数据在键值对中：JSON 数据是由键值对构成的
  * 键用引号(单双都行)引起来，也可以不使用引号
  * 值的取值类型：
    * 数字（整数或浮点数）
    * 字符串（在双引号中）
    * 逻辑值（true 或 false）
    * 数组（在方括号中），{"persons":[{},{}]}
    * 对象（在花括号中），{"address":{"province"："陕西"....}}
    * null
  * 数据由逗号分隔：多个键值对由逗号分隔
  * 花括号保存对象：使用{}定义 JSON 格式
  * 方括号保存数组：[]
* 值的存储以及获取：

  * JSON 对象\.键名
  * JSON 对象["键名"]
  * 数组对象[索引]

  ```js
  //1.定义基本格式
  var person = {"name": "张三", age: 23, 'gender': true};
  //获取name的值，张三
  var name = person.name;
  var name = person["name"];

  //2.嵌套格式   {}———> []
  var persons = {
      "persons": [
          {"name": "张三", "age": 23, "gender": true},
          {"name": "李四", "age": 24, "gender": true},
          {"name": "王五", "age": 25, "gender": false}
          ]
  };
  //获取王五
  var name1 = persons.persons[2].name;

  //2.嵌套格式   []———> {}
  var ps = [{"name": "张三", "age": 23, "gender": true},
      {"name": "李四", "age": 24, "gender": true},
      {"name": "王五", "age": 25, "gender": false}];
  //获取李四
  var name2 = ps[1].name;
  ```
* 遍历：使用 for in 循环

  ```js
  var person = {"name": "张三", age: 23, 'gender': true};
  //获取person对象中所有的键和值
  //for in 循环
  for(var key in person){
      //这样的方式获取不行。因为相当于  person."name"
      //alert(key + ":" + person.key);
      alert(key+":"+person[key]);
  }

  var ps = [{"name": "张三", "age": 23, "gender": true},
      {"name": "李四", "age": 24, "gender": true},
      {"name": "王五", "age": 25, "gender": false}];
  //获取ps数组中的所有值
  for (var i = 0; i < ps.length; i++) {
      var p = ps[i];
      for(var key in p){
          alert(key+":"+p[key]);
      }
  }
  ```

  > 注意：使用循环的时候得到的 key 为一个字符串，没办法用 JSON 对象。key 的方式获取值，需要使用 JSON 对象[key] 的方式获取值，而且因为 key 是字符串，所以[]中不需要再加双引号。
  >

### 2. JSON 解析

* 常见的解析器：Jsonlib，Gson，fastjson，jackson
* Java 对象转换 JSON
  1. 导入 jackson 的相关 jar 包
  2. 创建 Jackson 核心对象 ObjectMapper
  3. 调用 ObjectMapper 的相关方法进行转换
* jackson 坐标：
  ```xml
  <dependency>
    <groupId>com.fasterxml.jackson.core</groupId>
    <artifactId>jackson-databind</artifactId>
    <version>2.9.0</version>
  </dependency>
  <dependency>
    <groupId>com.fasterxml.jackson.core</groupId>
    <artifactId>jackson-core</artifactId>
    <version>2.9.0</version>
  </dependency>
  <dependency>
    <groupId>com.fasterxml.jackson.core</groupId>
    <artifactId>jackson-annotations</artifactId>
    <version>2.9.0</version>
  </dependency>
  ```
* ObjectMapper 对象关于 Java 对象转 JSON 的方法：
  * `writeValue(参数1，obj)`，obj 为要转换的对象，参数 1 为下列取值
    * File：将 obj 对象转换为 JSON 字符串，并保存到指定的文件中
    * Writer：将 obj 对象转换为 JSON 字符串，并将 JSON 数据填充到字符输出流中
    * OutputStream：将 obj 对象转换为 JSON 字符串，并将 JSON 数据填充到字节输出流中
  * `writeValueAsString(obj)`：将对象转为 JSON 字符串，返回一个字符串
  * List 对象转 JSON 会转成 JSON 的数组形式。
  * Map 对象转 JSON 与对象转成的 JSON 一致。
* 注解：
  * @JsonIgnore：排除属性。
  * @JsonFormat：属性值得格式化，多用于日期
    * @JsonFormat(pattern = "yyyy-MM-dd")，格式化 Date 对象
* JSON 对象转 Java 对象
  * `ObjectMapper对象.readValue(参数1, Class)`，参数 1 可取值
    * String
    * File
    * Reader
    * InputStream
