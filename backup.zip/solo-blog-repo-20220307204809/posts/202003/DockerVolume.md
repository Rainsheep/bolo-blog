title: Docker Volume
date: '2020-03-24 17:06:10'
updated: '2020-03-24 17:06:10'
tags: [Linux]
permalink: /articles/2020/03/24/1585040770531.html
---
### 1. 什么是 Docker Volume

在 Docker 中，Volume 实现数据的持久化（所谓 Docker 的数据持久化即**数据不随着 Container 的结束而结束**），需要将数据从宿主机挂载到容器中。默认位于 `/var/lib/docker/volumes` 目录中。

### 2. Volume 的基本操作

```shell
docker volume ls # 查看所有容器卷，可以查看容器默认的数据卷
docker volume inspect volumeName # 查看指定容器卷详情信息,Mountpoint为挂载点
```

### 3. 创建一个指定挂载点的容器

```shell
docker run --name mysql -p 3306:3306 \
-v /dockerData/mysql/data:/var/lib/mysql \
-v /dockerData/mysql/mysqld.cnf:/etc/mysql/mysql.conf.d/mysqld.cnf \
-e MYSQL_ROOT_PASSWORD=123456 -d mysql:5.6
```

* -v 为挂载数据卷的指定
* `-v /dockerData/mysql/data:/var/lib/mysql`：将本地的 `/dockerData/mysql/data` 目录挂载到 MySQL 容器的 `/var/lib/mysql` 目录
* `-v /dockerData/mysql/mysqld.cnf:/etc/mysql/mysql.conf.d/mysqld.cnf`：将本地 `/dockerData/mysql/mysqld.cnf` 配置文件挂载到 MySQL 容器的 `/etc/mysql/mysql.conf.d/mysqld.cnf` 文件
