title: android 控件
date: '2021-02-23 19:19:37'
updated: '2021-02-23 19:19:37'
tags: [android]
permalink: /articles/2021/02/23/1614079177741.html
---
## 1 TextView

```
text        // 设置显示的文本内容
textColor   // 设置字体颜色
textStyle   // 设置字体风格，normal/bold/italic
textSize    // 字体大小，单位一般是用sp
background  // 控件的背景颜色，可以是图片
```

**阴影**

```
shadowColor  //设置阴影颜色,需要与shadowRadius一起使用
shadowRadius // 设置阴影的模糊程度,设为0.1就变成字体颜色了,建议使用3.0
shadowDx     // 设置阴影在水平方向的偏移
shadowDy     // 设置阴影在竖直方向的偏移
```

**边框**

```
// 自行编写一个 ShapeDrawable 的资源文件,然后 TextView 将 backgroung 设置为这个drawable 资源

// shapeDrawable资源文件的几个节点以及属性
// 这个是设置背景颜色的
<solid android:color = "xxx">  

// 这个是设置边框的粗细,以及边框颜色的
<stroke android:width = "xdp" android:color="xxx">

// 这个是设置边距的
<padding androidLbottom = "xdp"...> 

// 这个是设置圆角的
<corners android:topLeftRadius="10px"...> 

// 这个是设置渐变色的,可选属性有: 
// startColor:起始颜色 
// endColor:结束颜色 
// centerColor:中间颜色 
// angle:方向角度,等于0时,从左到右,然后逆时针方向转,当angle = 90度时从下往上 
// type:设置渐变的类型
<gradient>
```

**带图片 (drawableXxx) 的 TextView**

```
drawableTop
drawableButtom
drawableLeft
drawableRight
// 设置图片与文字间的间距
drawablePadding

// 如需设置图片大小，需通过 java 代码设置
txtZQD = (TextView) findViewById(R.id.txtZQD);  
Drawable[] drawable = txtZQD.getCompoundDrawables();  
// 数组下表0~3,依次是:左上右下  
drawable[1].setBounds(100, 0, 200, 200);  
txtZQD.setCompoundDrawables(drawable[0],drawable[1],drawable[2],drawable[3]);
```

**识别链接类型**

当文字中出现了 URL，E-Mail，电话号码，地图的时候，我们可以通过设置 autoLink 属性；当我们点击文字中对应部分的文字，即可跳转至某默认 APP，比如一串号码，点击后跳转至拨号界面！

```
autoLink="email/none/web/email/phone/map/all"
// all 就是全部都包含,自动识别协议头

//在Java代码中
setAutoLinkMask(Linkify.ALL); setMovementMethod(LinkMovementMethod.getInstance());
```

**包含 HTML**

常用标签：font、big、small、i、b、a、img

```
TextView t1 = (TextView)findViewById(R.id.txtOne);
String s1 = "<a href = 'http://www.baidu.com'>百度</a>";
t1.setText(Html.fromHtml(s1));
t1.setMovementMethod(LinkMovementMethod.getInstance());
```

**定制文本**

SpannableString(针对的是不可变文本)、SpannableStringBuilder(针对可变文本)

此处只讲解 SpannableString

```
BackgroundColorSpan  // 背景色
ClickableSpan        // 文本可点击，有点击事件
ForegroundColorSpan  // 文本颜色（前景色）
MaskFilterSpan       // 修饰效果，如模糊(BlurMaskFilter)、浮雕(EmbossMaskFilter)
MetricAffectingSpan  // 父类，一般不用
RasterizerSpan       // 光栅效果
StrikethroughSpan    // 删除线（中划线）
SuggestionSpan       // 相当于占位符
UnderlineSpan        // 下划线
AbsoluteSizeSpan     // 绝对大小（文本字体）
DynamicDrawableSpan  // 设置图片，基于文本基线或底部对齐。
ImageSpan            // 图片
RelativeSizeSpan     // 相对大小（文本字体）
ReplacementSpan      // 父类，一般不用
ScaleXSpan           // 基于 x 轴缩放
StyleSpan            // 字体样式：粗体、斜体等
SubscriptSpan        // 下标（数学公式会用到）
SuperscriptSpan      // 上标（数学公式会用到）
TextAppearanceSpan   // 文本外貌（包括字体、大小、样式和颜色）
TypefaceSpan         // 文本字体
URLSpan              // 文本超链接
```

使用例子

```
TextView t1 = (TextView) findViewById(R.id.txtOne);
SpannableString span = new SpannableString("红色打电话斜体删除线绿色下划线图片:.");
// 设置背景色,setSpan时需要指定的flag,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE(前后都不包括)
span.setSpan(new ForegroundColorSpan(Color.RED), 0, 2, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
// 用超链接标记文本
span.setSpan(new URLSpan("tel:4155551212"), 2, 5, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
t1.setText(span);
```

**跑马灯**

```
singleLine="true"      // 文本一行显示
ellipsize="marquee"    // start(省略号在开头)、end、middle、marquee(跑马灯)
marqueeRepeatLimit="marquee_forever"  // 重复滚动次数，marquee_forever 无限滚动
```

## 2 EditText

输入框

```
hint="默认提示文本"
// 提示文本颜色
textColorHint="#95A1AA"
// 获得焦点后全选组件内所有文本内容
selectAllOnFocus="true"
```

输入类型

```
inputType="none"  
inputType="text"  
inputType="textCapCharacters"  
inputType="textCapWords"  
inputType="textCapSentences"  
inputType="textAutoCorrect"  
inputType="textAutoComplete"  
inputType="textMultiLine"  
inputType="textImeMultiLine"  
inputType="textNoSuggestions"  
inputType="textUri"  
inputType="textEmailAddress"  
inputType="textEmailSubject"  
inputType="textShortMessage"  
inputType="textLongMessage"  
inputType="textPersonName"  
inputType="textPostalAddress"  
inputType="textPassword"  
inputType="textVisiblePassword"  
inputType="textWebEditText"  
inputType="textFilter"  
inputType="textPhonetic" 

inputType="number"  
inputType="numberSigned"  
inputType="numberDecimal"  
inputType="phone"//拨号键盘  
inputType="datetime"  
inputType="date"//日期键盘  
inputType="time"//时间键盘
```

行相关

```
minLines="3"
maxLines="3"
singleLine="true"
```

文字间隔

```
// 设置字与字的水平间隔
textScaleX="1.5"  
//设置字与字的垂直间隔
textScaleY="1.5"
```

英文字母大写类型

```
capitalize="none | sentences | words | characters"
```

焦点

```
edit.requestFocus(); //请求获取焦点
edit.clearFocus(); //清除焦点

自动弹出键盘需要配置 windowSoftInputMode
```

光标位置

```
// 让 EditText 获得焦点时选中全部文本
setSelectAllOnFocus(true)
// 设置光标不显示
setCursorVisible(false)
// 获得当前光标的前后位置
getSelectionStart
getSelectionEnd
```

