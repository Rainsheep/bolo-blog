title: github加速教程
date: '2020-07-29 21:32:13'
updated: '2020-07-29 21:32:13'
tags: [软件教程]
permalink: /articles/2020/07/29/1596029533938.html
---
登录：[http://tool.chinaz.com/dns](http://tool.chinaz.com/dns) 查询dns
![p2020072921533053SS.png](https://b3logfile.com/file/2020/07/p2020072921533053SS-09265a0e.png)

找一个TTL最小的而且能ping通的，修改host文件


![p2020072921413141SS.png](https://b3logfile.com/file/2020/07/p2020072921413141SS-21f698c3.png)

修改host之前：

![p2020072921492849SS.png](https://b3logfile.com/file/2020/07/p2020072921492849SS-e5aa8dbc.png)

修改host之后：

![p2020072921282928SS.png](https://b3logfile.com/file/2020/07/p2020072921282928SS-ac250189.png)
