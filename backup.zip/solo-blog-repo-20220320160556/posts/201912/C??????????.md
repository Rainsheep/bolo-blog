title: C语言对文件的读写操作
date: '2019-12-03 21:11:25'
updated: '2019-12-03 21:11:25'
tags: [知识点总结]
permalink: /articles/2019/12/03/1575378685230.html
---
|文件使用方式|含义|如果指定的文件不存在|
|---|---|---|
|“r”（只读）|为了输入数据，打开一个已存在的文本文件|出错|
|“w”（只写）|为了输出数据，打开一个文本文件|建立新文件|
|“a”（追加）|向文本文件尾部添加数据|出错|
|“rb”（只读）|为了输入数据，打开一个二进制文件|出错|
|“wb”（只写）|为了输出数据，打开一个二进制文件|建立新文件|
|“ab”（追加）|向二进制文件尾添加数据|出错|

文件路径名

```c
fopen("D:\\CC\\data.dat","r");
fopen("D:/CC/data.dat","r"); 
```

常用的定义文件指针的方法
`FILE *fp; `

常用打开和关闭文件的方法

```c
if((fp=fopen("data.txt","r"))==NULL){
	printf("无法打开此文件\n");
	exit(0); 
}
 
fclose(fp);
```

判断文件是否读到尾

```c
while(!feof(fp)){
	
}
```

读写一个字符

```c
fgetc(fp);
fputc(ch,fp);
```

读写一个字符串

```c
fgets(str,n,fp);//读入n-1个字符，并在结尾加上'\0',遇到'\n'和EOF也算结束
fputs(str,fp);//输出到文件 
```

格式化读写（可读写结构体）

```c
fprintf(fp,"%d %s %lf\n",a,s1,b);
fscanf(fp,"%d %s %lf",&a,s1,&b);
```

二进制方式读写（可读写结构体）

```c
fread(address,size,count,fp);//count，读写的数据项 
fwrite(address,size,count,fp);
 
for(int i=0;i<40;i++)
fread(&s[i],sizeof(struct node),1,fp);
 
for(int i=0;i<40;i++)
fwrite(&s[i],sizeof(struct node),1,fp);
```

输入输出流读写

```c
freopen("input.txt","r",stdin);
//scanf
fclose(stdin); 
 
freopen("output.txt","w",stdout);
//print
fclose(stdout); 
```
