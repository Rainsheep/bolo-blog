title: ContentProvider
date: '2021-04-08 16:01:26'
updated: '2021-04-12 16:55:43'
tags: [android]
permalink: /articles/2021/04/08/1617868886760.html
---
## 1. 内容提供者简介

用于在不同应用程序之间实现数据共享功能。

## 2. 获取数据

### 2.1 URI

要访问内容提供器中共享的数据，就需要借助 ContentResolver 类，通过 Context 中的 getContentResolver 方法获取该类的实例。这个类提供了添加、更新、删除和查询数据的方法。和SQLiteDatabase那块比较相似，但也有不同。

各个方法不需要传递表名参数，需要用一个 Uri 参数(内容 URI)替代，内容 URI 由 authority 和 path 两个部分组成，为内容提供器中的数据提供了一个唯一标志符。

authority 用来区分不同的应用程序，一般采用程序包名的方式命名避免冲突，例如包名为 `com.example.app`，那么对应的 authority 命名为 `com.example.app.provider`。

path 来区分统一程序中的不同表，通常加载 authority 之后，比如在数据库里面两张表 table1 和 table2，这样URL 就变成 `com.example.app.provider/table1` 和 `com.example.app.provider/table2`，而内容uri还需要在字符串头部加上协议声明 `content://`。内容 URI 标准写法如下：

```
content://com.example.app.provider/table1
content://com.example.app.provider/table2
```

内容 URI 字符串可以清楚的表达出是哪个程序的哪张表，ContentResolver 中的增删改查方法接收内容 URI。需要把 URI 字符串解析成 URI 对象。调用 `Uri.parse()` 方法即可解析。

```java
Uri uri = Uri.parse("content://com.example.app.provider/table1");
```

### 2.2 查询

```java
Cursor cursor = getContentResolver().query(
    uri,
    projection,
    selection,
    selectionArgs,
    sortOrder);
```

* projection: 指定查询的列名，对应 sql `select column1, column2`
* selection: 指定 where 的约束条件，对应 sql `where column = value`
* selectionArgs: 为 where 中占位符提供具体的值
* sortOrder: 查询指定结果的排序方式，对应 sql `order by column1, column2`

查询完返回一个 Cursor 对象，将数据从 Cursor 对象逐个读取：

```java
if(cursor != null){
    while(cursor.moveToNext()){
        String column1 = cursor.getString(cursor.getColunmIndex("colunm1"));
        int column2 = cursor.getInt(cursor.getColumnIndex("column2");
    }
    cursor.close();
}
```

### 2.3 插入

```java
ContentValues values = new ContentValues();
values.put("column1", "text");
valuse.put("column2", 1);
getContentResolver().insert(uri, values);
```

### 2.4 更新

更新 column1 = text 并且 column2 = 1 这行的数据

```java
ContentValues values = new ContentValues();
values.put("column1", "");
getContentResolver().update(uri, values, "column1 = ? and column2 = ?", new String[]{"text","1"});
```

### 2.5 删除

```java
getContentResolver().delete(uri, "column2 = ?", new String[]{"1"});
```

## 3. 提供数据

### 3.1 创建内容提供器

创建一个类继承 ContentProvider

```java
public class MyProvider extends ContentProvider {
 
    @Override
    public boolean onCreate() {
        return false;
    }
 
    @Nullable
    @Override
    //使用uri参数来确定查询哪张表，projection参数用于确定查询哪些列，selection和selectionArgs参数用于约束查询哪些行；
    // sortorder参数用于对结果进行排序，查询的结果存放在Cursor对象中返回。
    public Cursor query(@NonNull Uri uri, @Nullable String[] projection, @Nullable String selection, @Nullable String[] selectionArgs, @Nullable String sortOrder) {
        return null;
    }
 
    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues values) {
        return null;
    }
 
    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues values, @Nullable String selection, @Nullable String[] selectionArgs) {
        return 0;
    }
 
    @Override
    public int delete(@NonNull Uri uri, @Nullable String selection, @Nullable String[] selectionArgs) {
        return 0;
    }
 
    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        return null;
    }
}
```

* onCreate()
  初始化内容提供器的时候调用。通常会在这里完成对数据库的创建和升级等操作，返回 true 表示内容提供器初始化成功，返回 false 则表示失败。注意，只有当存在 ContentResolver 尝试访问我们程序中的数据时，内容提供器才会被初始化。
* query()
  从内容提供器中查询数据。使用 uri 参数来确定查询哪张表，projection 参数用于确定查询哪些列，selection 和 selectionArgs 参数用于约束查询哪些行，sortOrder 参数用于对结果进行排序，查询的结果存放在 Cursor 对象中返回。
* insert()
  向内容提供器中添加一条数据。使用 uri 参数来确定要添加到的表，待添加的数据保存在 values 参数中。添加完成后，返回一个用于表示这条新记录的 URI。
* update()
  更新内容提供器中已有的数据。使用 uri 参数来确定更新哪一张表中的数据，新数据保存在 values 参数中，selection 和 selectionArgs 参数用于约束更新哪些行，受影响的行数将作为返回值返回。
* delete()
  从内容提供器中删除数据。使用uri 参数来确定删除哪一张表中的数据，selection 和 selectionArgs 参数用于约束删除哪些行，被删除的行数将作为返回值返回。
* getType()
  根据传入的内容 URI 来返回相应的 MIME 类型。

内容 uri 的写法

```java
// 表示访问的是 table1 表中的数据。
content://com.example.app.provider/table1
// 表示调用方期望访问的是 table1 表中id 为 1 的数据。
content://com.example.app.provider/table1/1
```

我们可以使用通配符的方式来分别匹配这两种格式的内容 URI，规则如下：

* `*`：表示匹配任意长度的任意字符。
* `#`：表示匹配任意长度的数字。

所以，一个能够匹配任意表的内容 URI 格式就可以写成：

```
content://com.example.app.provider/*
```

而一个能够匹配 table1 表中任意一行数据的内容 URI 格式就可以写成：

```
content://com.example.app.provider/table1/#
```

接着，我们再借助 UriMatcher 这个类就可以轻松地实现匹配内容 URI 的功能。UriMatcher 中提供了一个 addURI() 方法：

```java
public void addURI(String authority, String path, int code);
```

这个方法接收三个参数，可以分别把权限、路径和一个自定义代码传进去。这样，当调用 UriMatcher 的 match()方法时，就可以将一个 Uri 对象传入，返回值是某个能够匹配这个 Uri 对象所对应的自定义代码，利用这个代码，我们就可以判断出调用方期望访问的是哪张表中的数据了。修改 MyContentProvider 中的代码，如下所示：

```java
public class MyContentProvider extends ContentProvider {
    public static final int TABLE1_DIR = 0;
    public static final int TABLE1_ITEM = 1;
    public static final int TABLE2_DIR = 2;
    public static final int TABLE2_ITEM = 3;
    private static UriMatcher uriMatcher;

    static {
        uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        uriMatcher.addURI("com.example.app.provider", "table1", TABLE1_DIR);
        uriMatcher.addURI("com.example.app.provider ", "table1/#", TABLE1_ITEM);
        uriMatcher.addURI("com.example.app.provider ", "table2", TABLE2_ITEM);
        uriMatcher.addURI("com.example.app.provider ", "table2/#", TABLE2_ITEM);
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        switch (uriMatcher.match(uri)) {
            case TABLE1_DIR:
                // 查询table1表中的所有数据
                break;
            case TABLE1_ITEM:
                // 查询table1表中的单条数据
                break;
            case TABLE2_DIR:
                // 查询table2表中的所有数据
                break;
            case TABLE2_ITEM:
                // 查询table2表中的单条数据
                break;
            default:
                break;
        }
    }
}
```

当 query() 方法被调用的时候，就会通过 UriMatcher 的 match() 方法对传入的 Uri 对象进行匹配，如果发现 UriMatcher 中某个内容URI 格式成功匹配了该 Uri 对象，则会返回相应的自定义代码，然后我们就可以判断出调用方期望访问的到底是什么数据了。

除此之外，还有一个方法你会比较陌生，即 getType() 方法。它是所有的内容提供器都必须提供的一个方法，用于获取 Uri 对象所对应的 MIME 类型。一个内容 URI 所对应的 MIME 字符串主要由三部分组分，Android 对这三个部分做了如下格式规定。

* 必须以vnd 开头。
* 如果内容 URI 以路径结尾，则后接 `android.cursor.dir/`，如果内容 URI 以 id 结尾，则后接`android.cursor.item/`。
* 最后接上 `vnd.<authority>.<path>`。

所以，对于 `content://com.example.app.provider/table1` 这个内容 URI，它所对应的 MIME 类型就可以写成：`vnd.android.cursor.dir/vnd.com.example.app.provider.table1`

对于 `content://com.example.app.provider/table1/1` 这个内容 URI，它所对应的 MIME 类型就可以写成：`vnd.android.cursor.item/vnd. com.example.app.provider.table1`

现在我们可以继续完善 MyContentProvider 中的内容了，这次来实现 getType() 方法中的逻辑，代码如下所示：

```java
@Override
public String getType(Uri uri) {
    switch (uriMatcher.match(uri)) {
        case TABLE1_DIR:
            return "vnd.android.cursor.dir/vnd.com.example.app.provider.table1";
        case TABLE1_ITEM:
            return "vnd.android.cursor.item/vnd.com.example.app.provider.table1";
        case TABLE2_DIR:
            return "vnd.android.cursor.dir/vnd.com.example.app.provider.table2";
        case TABLE2_ITEM:
            return "vnd.android.cursor.item/vnd.com.example.app.provider.table2";
        default:
            break;
    }
    return null;
}
```

### 3.2 跨程序数据共享实例

DatabaseProvider.java

```java
public class DatabaseProvider extends ContentProvider {

    public static final int BOOK_DIR = 0;
    public static final int BOOK_ITEM = 1;
    public static final int CATEGORY_DIR = 2;
    public static final int CATEGORY_ITEM = 3;

    public static final String AUTHORITY = "com.example.databasetest.provider";

    private static UriMatcher uriMatcher;

    private MyDatabaseHelper dbHelper;

    static {
        uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        // 访问 book 表中所有数据
        uriMatcher.addURI(AUTHORITY, "book", BOOK_DIR);
        // 访问 book 表中单条数据
        uriMatcher.addURI(AUTHORITY, "book/#", BOOK_ITEM);
        uriMatcher.addURI(AUTHORITY, "category", CATEGORY_DIR);
        uriMatcher.addURI(AUTHORITY, "category/#", CATEGORY_ITEM);
    }

    @Override
    public boolean onCreate() {
        dbHelper = new MyDatabaseHelper(getContext(), "BookStore.db", null, 2);
        // 返回 true 表示内容提供器初始化成功
        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        // 查询数据
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = null;
        switch (uriMatcher.match(uri)) {
            case BOOK_DIR:
                cursor = db.query("Book", projection, selection, selectionArgs, null, null, sortOrder);
                break;
            case BOOK_ITEM:
                // getPathSegments() 会将内容 URI 权限之后的部分以 '/' 分割，分割后的字符串列表中，0 存放路径，1 存放 id
                String bookId = uri.getPathSegments().get(1);
                cursor = db.query("Book", projection, "id = ?", new String[] { bookId }, null, null, sortOrder);
                break;
            case CATEGORY_DIR:
                cursor = db.query("Category", projection, selection, selectionArgs, null, null, sortOrder);
                break;
            case CATEGORY_ITEM:
                String categoryId = uri.getPathSegments().get(1);
                cursor = db.query("Category", projection, "id = ?", new String[] { categoryId }, null, null, sortOrder);
                break;
            default:
                break;
        }
        return cursor;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        // 添加数据
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        Uri uriReturn = null;
        switch (uriMatcher.match(uri)) {
            case BOOK_DIR:
            case BOOK_ITEM:
                long newBookId = db.insert("Book", null, values);
                uriReturn = Uri.parse("content://" + AUTHORITY + "/book/" + newBookId);
                break;
            case CATEGORY_DIR:
            case CATEGORY_ITEM:
                long newCategoryId = db.insert("Category", null, values);
                uriReturn = Uri.parse("content://" + AUTHORITY + "/category/" + newCategoryId);
                break;
            default:
                break;
        }
        // 要求返回这条新增数据的 URI
        return uriReturn;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        // 更新数据
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        int updatedRows = 0;
        switch (uriMatcher.match(uri)) {
            case BOOK_DIR:
                updatedRows = db.update("Book", values, selection, selectionArgs);
                break;
            case BOOK_ITEM:
                String bookId = uri.getPathSegments().get(1);
                updatedRows = db.update("Book", values, "id = ?", new String[] { bookId });
                break;
            case CATEGORY_DIR:
                updatedRows = db.update("Category", values, selection, selectionArgs);
                break;
            case CATEGORY_ITEM:
                String categoryId = uri.getPathSegments().get(1);
                updatedRows = db.update("Category", values, "id = ?", new String[] { categoryId });
                break;
            default:
                break;
        }
        // 返回受影响的条数
        return updatedRows;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        // 删除数据
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        int deletedRows = 0;
        switch (uriMatcher.match(uri)) {
            case BOOK_DIR:
                deletedRows = db.delete("Book", selection, selectionArgs);
                break;
            case BOOK_ITEM:
                String bookId = uri.getPathSegments().get(1);
                deletedRows = db.delete("Book", "id = ?", new String[] { bookId });
                break;
            case CATEGORY_DIR:
                deletedRows = db.delete("Category", selection, selectionArgs);
                break;
            case CATEGORY_ITEM:
                String categoryId = uri.getPathSegments().get(1);
                deletedRows = db.delete("Category", "id = ?", new String[] { categoryId });
                break;
            default:
                break;
        }
        // 返回被删除的行数
        return deletedRows;
    }

    @Override
    public String getType(Uri uri) {
        switch (uriMatcher.match(uri)) {
            case BOOK_DIR:
                return "vnd.android.cursor.dir/vnd.com.example.databasetest. provider.book";
            case BOOK_ITEM:
                return "vnd.android.cursor.item/vnd.com.example.databasetest. provider.book";
            case CATEGORY_DIR:
                return "vnd.android.cursor.dir/vnd.com.example.databasetest. provider.category";
            case CATEGORY_ITEM:
                return "vnd.android.cursor.item/vnd.com.example.databasetest. provider.category";
        }
        return null;
    }
}
```

内容提供器需要在 AndroidMainfest.xml 中注册

```xml
<application
    <provider
        android:name=".DatabaseProvider"
        android:authorities="com.example.databasetest.provider"
        android:enabled="true"
        android:exported="true" />
</application>
```

* exported 表示是否允许被别的程序访问

新建一个程序，调用内容提供者

```java
public class MainActivity extends AppCompatActivity {

    private String newId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button addData = (Button) findViewById(R.id.add_data);
        addData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 添加数据
                Uri uri = Uri.parse("content://com.example.databasetest.provider/book");
                ContentValues values = new ContentValues();
                values.put("name", "A Clash of Kings");
                values.put("author", "George Martin");
                values.put("pages", 1040);
                values.put("price", 55.55);
                Uri newUri = getContentResolver().insert(uri, values);
                newId = newUri.getPathSegments().get(1);
            }
        });
        Button queryData = (Button) findViewById(R.id.query_data);
        queryData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 查询数据
                Uri uri = Uri.parse("content://com.example.databasetest.provider/book");
                Cursor cursor = getContentResolver().query(uri, null, null, null, null);
                if (cursor != null) {
                    while (cursor.moveToNext()) {
                        String name = cursor.getString(cursor. getColumnIndex("name"));
                        String author = cursor.getString(cursor. getColumnIndex("author"));
                        int pages = cursor.getInt(cursor.getColumnIndex ("pages"));
                        double price = cursor.getDouble(cursor. getColumnIndex("price"));
                        Log.d("MainActivity", "book name is " + name);
                        Log.d("MainActivity", "book author is " + author);
                        Log.d("MainActivity", "book pages is " + pages);
                        Log.d("MainActivity", "book price is " + price);
                    }
                    cursor.close();
                }
            }
        });
        Button updateData = (Button) findViewById(R.id.update_data);
        updateData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 更新数据
                Uri uri = Uri.parse("content://com.example.databasetest.provider/book/" + newId);
                ContentValues values = new ContentValues();
                values.put("name", "A Storm of Swords");
                values.put("pages", 1216);
                values.put("price", 24.05);
                getContentResolver().update(uri, values, null, null);
            }
        });
        Button deleteData = (Button) findViewById(R.id.delete_data);
        deleteData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 删除数据
                Uri uri = Uri.parse("content://com.example.databasetest.provider/book/" + newId);
                getContentResolver().delete(uri, null, null);
            }
        });
    }
}
```



