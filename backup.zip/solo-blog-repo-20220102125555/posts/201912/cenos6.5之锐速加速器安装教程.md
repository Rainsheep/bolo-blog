title: cenos 6.5 之 锐速加速器安装教程
date: '2019-12-02 22:40:53'
updated: '2019-12-04 15:15:27'
tags: [ss, Shadowsocks]
permalink: /articles/2019/12/02/1575297653373.html
---
<details>
	<summary>参考链接</summary>
	<a href="https://www.91yun.co/archives/683">锐速破解版 linux一键自动安装包</a>
	<a href="https://www.91yun.co/archives/683">锐速破解版 linux一键自动安装包</a>
</details>

# 下载锐速
`wget -N --no-check-certificate https://github.com/91yun/serverspeeder/raw/master/serverspeeder.sh && bash serverspeeder.sh`

# 内壳版本号不一致
>1如若内壳版本号不一样，进行这步操作，否则跳过
首先需要确认自己的内核版本，输入命令`uname -a`，输出中有i686则为32位，有x86_64则为64位。

下载32位内核：
`rpm -ivh http://soft.91yun.pw/ISO/Linux/CentOS/kernel/kernel-firmware-2.6.32-504.3.3.el6.noarch.rpm`

下载64位内核：
`rpm -ivh http://soft.91yun.pw/ISO/Linux/CentOS/kernel/kernel-2.6.32-504.3.3.el6.x86_64.rpm --force`

以64位系统为例下载后可以`rpm -ivh kernel-2.6.32-504.el6.i686.rpm --force`降级内核，然后reboot重启系统即可。

如果出现error: Failed dependencies: kernel-firmware >= 2.6.32-504.el6 is needed by kernel-2.6.32-504.el6.x86_64这样的错误，需要更新firmware。

![20171225143018864.png](https://img.hacpai.com/file/2019/12/20171225143018864-63462fbd.png)


`wget -c http://ftp.scientificlinux.org/linux/scientific/6.5/x86_64/updates/security/kernel-firmware-2.6.32-504.el6.noarch.rpm`

然后执行`rpm -Uvh kernel-firmware-2.6.32-504.el6.noarch.rpm`你会发现进度条，再执行`rpm -qa | grep kernel-firmware`发现firmware安装成功。

这下我们再执行`rpm -ivh kernel-2.6.32-504.el6.x86_64.rpm --force`来装内核就成功了。
重启机器，reboot  此时，在执行第一步  成功

 # 配置文件
然后再复制下面代码粘贴到putty里按回车：（复制到最后一个字母, 一次性粘贴到putty回车）：
`vi /serverspeeder/etc/config`

然后在键盘按方向键移动光标查找下列4项, 如果引号内的数值与下列4项给出的一致，则不需要修改,如果不一致则修改为下列数值( 由于列表较长,将光标一直按下去, 就能找到rsc和gso ) 修改请先用方向键移动光标到要修改的数值上再按键盘上字母 i 进入编辑模式,  直接修改引号数值为1 (按键盘上数字键1, 再按Delete键删除原来0) ,编辑好后请按键盘上ESC键退出编辑模式 ,  然后在键盘上按shift键加 : 键, 输入wq 按回车键）：
```
rsc=”1″
gso=”1″
maxmode=”1″
advinacc=”1″
```
重启加速服务完成优化(复制命令粘贴到putty并回车)：
`service serverSpeeder restart`

至此，就成功加速, 可以超高速看视频了.锐速加速效果还是很明显的。

# 卸载锐速
`chattr -i /serverspeeder/etc/apx* && /serverspeeder/bin/serverSpeeder.sh uninstall -f`


