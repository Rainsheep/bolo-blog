title: node.js 学习笔记
date: '2020-09-04 11:10:49'
updated: '2020-09-04 11:10:49'
tags: [学习笔记, 前端]
permalink: /articles/2020/09/04/1599189049934.html
---
### 概述

* **Node**是一个基于Chrome V8引擎的JavaScript**代码运行环境**。
* JavaScript 由三部分组成，ECMAScript，DOM，BOM。
* Node.js是由ECMAScript及Node 环境提供的一些附加API组成的，包括文件、网络、路径等等一些更加强大的 API。
* 在Node环境下执行代码，使用Node命令执行后缀为.js的文件即可
* 在**浏览器**中全局对象是**window**，在**Node**中全局对象是**global**。
* Node中全局对象下有以下方法，可以在任何地方使用，global可以省略。
  * console.log()   在控制台中输出
  * setTimeout()   设置超时定时器
  * clearTimeout() 清除超时时定时器
  * setInterval()   设置间歇定时器
  * clearInterval()  清除间歇定时器

### 模块化开发

* Node.js规定一个JavaScript文件就是一个模块，模块内部定义的变量和函数默认情况下在外部无法得到
* 模块内部可以使用exports对象进行成员导出，使用require方法导入其他模块。
* exports是module.exports的别名(地址引用关系)，导出对象最终以module.exports为准
* Node运行环境提供的API. 因为这些API都是以模块化的方式进行开发的, 所以我们又称Node运行环境提供的API为系统模块，比如fs文件操作，`require('fs')` 后即可使用。

### 第三方模块

* 别人写好的、具有特定功能的、我们能直接使用的模块即第三方模块，由于第三方模块通常都是由多个文件组成并且被放置在一个文件夹中，所以又名包。
* 第三方模块有两种存在形式

  * 以js文件的形式存在，提供实现项目具体功能的API接口。
  * 以命令行工具形式存在，辅助项目开发
* npm (node package manager) ： node的第三方模块管理工具

  * 下载：npm install 模块名称
  * 卸载：npm unintall package 模块名称
  * 一般情况下，命令行工具使用全局安装的方式，库文件使用本地安装的方式，使用 -g 参数来进行全局安装
* Gulp：基于node平台开发的前端构建工具

  * 能够压缩合并HTML、CSS、JS文件
  * 将es6、less语法转换
  * 公共文件抽离
  * 修改文件浏览器自动刷新
* Gulp 中提供的方法

  * lgulp.src()：获取任务要处理的文件
  * lgulp.dest()：输出文件
  * lgulp.task()：建立gulp任务
  * lgulp.watch()：监控文件的变化
* package.json ：项目描述文件，记录了当前项目信息，例如项目名称、版本、作者、github地址、当前项目依赖了哪些第三方模块等。使用 `npm init -y` 命令生成。

  * 使用`npm install 包名` 命令下载的文件会默认被添加到 package.json 文件的 dependencies 字段中
  * 使用`npm install 包名 --save-dev` 命令将包添加到package.json文件的devDependencies字段中，开发依赖使用，线上运行不需要
* package-lock.json 文件

  * 锁定包的版本，确保再次下载时不会因为包版本不同而产生问题
  * 加快下载速度，因为该文件中已经记录了项目所依赖第三方包的树状结构和包的下载地址，重新安装时只需下载即可，不需要做额外的工作
* 当模块拥有路径但没有后缀时

  ```
  require('./find.js');
  require('./find');
  ```

  1. require方法根据模块路径查找模块，如果是完整路径，直接引入模块。
  2. 如果模块后缀省略，先找同名JS文件再找同名JS文件夹
  3. 如果找到了同名文件夹，找文件夹中的index.js
  4. 如果文件夹中没有index.js就会去当前文件夹中的package.json文件中查找main选项中的入口文件
  5. 如果找指定的入口文件不存在或者没有指定入口文件就会报错，模块没有被找到
* 当模块没有路径且没有后缀时

  ```
  require('find')
  ```

  1.Node.js会假设它是系统模块

  2.Node.js会去node_modules文件夹中

  3.首先看是否有该名字的JS文件

  4.再看是否有该名字的文件夹

  5.如果是文件夹看里面是否有index.js

  6.如果没有index.js查看该文件夹中的package.json中的main选项确定模块入口文件

  7.否则找不到报错
