title: mac 优化终端
date: '2020-09-13 23:28:36'
updated: '2021-07-27 01:34:15'
tags: [mac]
permalink: /articles/2020/09/13/1600010916412.html
---
参考连接：

[Mac OS X 下优化 Terminal，一篇就够了](https://www.jianshu.com/p/5e06509f4565)

[iTerm2 + OhMyZsh + agnoster + Powerline + solarized = 漂亮的Mac终端](https://blog.csdn.net/huihut/article/details/61418136)

[oh-my-zsh 插件推荐 : autojump、zsh-autosuggestion 以及 zsh-syntax-highlighting](https://www.zrahh.com/archives/167.html)

[Oh My Zsh 插件](https://github.com/ohmyzsh/ohmyzsh/wiki/Plugins)

> 系统：macOS Catalina 10.15.6

### 安装 iTmer2

* 进入[官网](https://www.iterm2.com/downloads.html)下载 Stable Releases，解压后拖到应用程序中。

### 安装 zsh 终端

* 新版系统自带 zsh
  
  ```
  cat /etc/shells    // 查看本地的 bash 列表
  chsh -s /bin/zsh   // 切换到指定 bash
  zsh --version      // 查看版本
  ```
* iTerm2 → Preferences → Generation → Closing → 取消勾选 Confirm Quit iTerm2
* iTerm2 → Preferences → Apparence → Winsows → 取消勾选 show border around windows
* 重启 iTmer2

### 安装 [Powerline fonts](https://github.com/powerline/fonts)

* 主题需要 Powerline 字符集的支持
* 通过 git 安装
  
  ```bash
  git clone https://github.com/powerline/fonts.git --depth=1
  cd fonts
  ./install.sh
  cd ..
  rm -rf fonts
  ```

### 安装 Oh My Zsh

- Oh My Zsh 是基于 zsh 的一个扩展工具集，它提供了丰富的扩展功能
- 安装
  
  ```bash
  sh -c "$(curl -fsSL https://raw.githubusercontent.com/robbyrussell/oh-my-zsh/master/tools/install.sh)"
  ```
- 查看自带主题
  
  ```bash
  ls ~/.oh-my-zsh/themes
  ```
- 设置主题，这里使用 ys 主题
  
  ```
  vim ~/.zshrc
  设置 ZSH_THEME="ys"   // ZSH_THEME="random" 每次打开终端都会随机主题
  ```
- 启用 oh my zsh
  
  ```
  source $ZSH/oh-my-zsh.sh
  ```
- 此时进入 iTerm2 既有效果

### 设置背景色和字体

* iTerm2 → Preferences → Profiles → Colors → Color Presets 选择 Smoooooth
* Background 设置为 1c2c40
* Text → Font 选择 Source Code Pro for Powerline Bold Italic 14
  
  > 注意必须选择 for powerline 字体 ，防止乱码

### oh my zsh 插件

#### catimg

* 在终端展示图片
* ```
  # 依赖于 imagemagick
  brew install imagemagick
  ```

#### extract

* 作用：使用 x 命令，可以解压一切压缩文件

#### autojump

* Mac 系统
  
  ```bash
  brew install autojump
  ```
* 使用
  
  ```
  j 模糊路径名进行跳转
  ```

#### zsh-autosuggestion

* 输入命令时可以根据历史命令自动补全
* 安装
  
  ```
  git clone git://github.com/zsh-users/zsh-autosuggestions $ZSH_CUSTOM/plugins/zsh-autosuggestions
  ```
* 按右方向键补全

#### zsh-syntax-highlighting

* 命令语法高亮
* 安装
  
  ```
  git clone https://github.com/zsh-users/zsh-syntax-highlighting.git ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-syntax-highlighting
  ```

#### 声明插件

插件需要在 `.zshrc` 中声明

```
# 修改 plugins
plugins=(
    git
    autojump
    catimg
    extract
    zsh-autosuggestion
    zsh-syntax-highlighting
)
```

> Git/autojump/catimg/extract 属于 oh my zsh 自带插件，声明即可。
> 
> zsh-autosuggestion/zsh-syntax-highlighting 属于第三方插件，需放置在 $ZSH_CUSTOM/plugins 下再声明

### 设置 vim

* ```
  vim ./vimrc
  syntax on
  set ts=4
  set expandtab
  set autoindent
  ```

> 以后终端配置文件为 .zshrc ，不再是 .bash_profile，可以将以前的配置内容复制到新的配置文件中

### 终端 * 号无法使用

```
// .zshrc 中添加
// 意思：无法匹配时用原内容代替
setopt no_nomatch
```

