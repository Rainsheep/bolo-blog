title: android style 详解
date: '2021-06-25 14:21:33'
updated: '2021-06-25 14:21:33'
tags: [android]
permalink: /articles/2021/06/25/1624602093778.html
---
参考文献：

[AndroidStudio XML文件之style标签详解](https://blog.csdn.net/a1003434346/article/details/95924995)

## 1. 前言

Android 的样式一般定义在 res/values/styles.xml 文件中，其中有一个根元素 resource，样式通过嵌套子标签 style 来完成，style 以嵌套多个 item 标签来设置不同的属性，从而提高复用率。

**示例**

```xml
<style name="DefaultProgressDialog" parent="android:style/Theme.Dialog" >
    <item name="android:windowFrame">@null</item>
    <item name="android:windowNoTitle">true</item>
    <item name="android:windowBackground">@android:color/transparent</item>
    <item name="android:windowIsFloating">true</item>
    <item name="android:windowContentOverlay">@null</item>
</style>
```

- style 标签
  - name="XXX"  定义该 style 样式的 name 名称
  - parent="XXX"  可以继承自哪一个 Style 标签,继承以后可对父标签已经有的属性进行重写

* item 标签
  * name="XXX" name 里面的值可以为任意字符串,对应的是某一个 view 的属性值(如果要引用的 view 不存在这个属性,默认为这个属性无效(忽略这个属性)，并不会报错)

## 2. 常用属性

```xml
// 窗口进出动画设置:
<style name="WheelSelect" parent="@android:style/Animation">
    <item name="android:windowEnterAnimation">@anim/wheel_select_enter</item>
    <item name="android:windowExitAnimation">@anim/wheel_select_exit</item>
</style>

// 设置Dialog的属性:
<style name="DefaultProgressDialog" parent="android:style/Theme.Dialog">
    <item name="android:windowFrame">@null</item>
    <item name="android:windowNoTitle">true</item>
    <item name="android:windowBackground">@android:color/transparent</item>
    <item name="android:windowIsFloating">true</item>
    <item name="android:windowContentOverlay">@null</item>
</style>
```

## 3. 使用

主题使用：

```xml
<application
    android:allowBackup="true"
    android:icon="@mipmap/ic_launcher"
    android:label="@string/app_name"
    android:theme="@style/AppTheme">
    <!-- activity here -->
</application>
```

弹窗使用：

```java
popupWindow.setAnimationStyle(R.style.pop_anim);
```



