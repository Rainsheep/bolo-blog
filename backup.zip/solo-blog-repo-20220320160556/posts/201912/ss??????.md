title: ss脚本错误解决
date: '2019-12-04 14:24:04'
updated: '2019-12-04 14:24:04'
tags: [ss, Shadowsocks]
permalink: /articles/2019/12/04/1575440644239.html
---
[https://www.cnblogs.com/dadong616/p/5062727.html](https://www.cnblogs.com/dadong616/p/5062727.html)

[http://www.kuitao8.com/20180315/4682.shtml](http://www.kuitao8.com/20180315/4682.shtml)
