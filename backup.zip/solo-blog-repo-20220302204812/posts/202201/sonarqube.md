title: sonarqube
date: '2022-01-09 15:05:36'
updated: '2022-01-09 15:05:36'
tags: [tools]
permalink: /articles/2022/01/09/1641711936805.html
---
# 1. 简介

sonarqube 是一个代码质量检测工具。

# 2. 安装

官网：https://www.sonarqube.org/

我们采用 docker-compose 方式安装。

先将配置文件复制出来。

```bash
docker cp sonarqube:/opt/sonarqube/conf /dockerData/sonarqube/conf
```

启动

```yaml
version: '3'
services:
  sonarqube:
    image: sonarqube
    container_name: sonarqube
    restart: always
    ports:
      - 9000:9000
      - 9092:9092
    volumes:
      - /dockerData/sonarqube/conf:/opt/sonarqube/conf
```

安装完成后，即可通过 9000 端口访问。

初始账号密码皆为 admin

# 3. 配置

**安装中文插件**

![image-20220109142636521](https://oss.rainsheep.cn/blog/image-20220109142636521-1641709596-e0e.png)

**数据库**

高版本不可使用 mysql, 我们使用默认的 H2，无需做任何配置

# 4. 使用

## 4.1 mvn 使用

在我的账号 -> 安全 -> 生成令牌 token

### 4.1.1 全局配置

编辑 .m2 中的 settings.xml 文件

添加如下配置：

```xml
<?xml version="1.0" encoding="UTF-8"?>
<settings xsi:schemaLocation="http://maven.apache.org/SETTINGS/1.1.0 http://maven.apache.org/xsd/settings-1.1.0.xsd"
  xmlns="http://maven.apache.org/SETTINGS/1.1.0"
  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <pluginGroups>
    <pluginGroup>org.sonarsource.scanner.maven</pluginGroup>
  </pluginGroups>

  <profiles>
    <profile> 
      <id>sonar</id>  
      <activation> 
        <activeByDefault>true</activeByDefault> 
      </activation>  
      <properties> 
        <sonar.host.url>自己的地址</sonar.host.url> 
      </properties> 
    </profile>  
  </profiles>
  <activeProfiles>
    <activeProfile>sonar</activeProfile>
  </activeProfiles>
</settings>
```

**分析**

```bash
mvn sonar:sonar -Dsonar.login={token}
```

### 4.1.2 单个项目配置

**引入插件**

```xml
<plugin>
    <groupId>com.xiaomi.sonarsource.scanner.maven</groupId>
    <artifactId>sonar-maven-plugin</artifactId>
</plugin>
```

**进行分析**

```bash
mvn sonar:sonar -Dsonar.login={token} -Dsonar.host.url=域名
```

**生成本地报告**

```bash
mvn sonar:sonar -Dsonar.login={token} -Dsonar.report=true -Dsonar.host.url=域名
```

## 4.2 SonarScanner 方式

下载地址：https://docs.sonarqube.org/latest/analysis/scan/sonarscanner/

**下载解压后配置环境变量**

```
export PATH=$PATH:/usr/local/sonar-scanner/bin
```

**配置 sonarqube 地址**

编辑 `$install_directory/conf/sonar-scanner.properties`:

```
sonar.host.url=http://localhost:9000
```

**在需要扫描的项目的根目录下添加 sonar-project.properties**

```
# projectKey 是项目的唯一标识，不能出现重复，可随意起
sonar.projectKey=my:project

# --- optional properties ---
# 不能是中文
#sonar.projectName=My project
# defaults to 'not provided'
#sonar.projectVersion=1.0
 
# Path is relative to the sonar-project.properties file. Defaults to .，项目源代码目录
#sonar.sources=.
 
# Encoding of the source code. Default is default system encoding
#sonar.sourceEncoding=UTF-8
```

**执行扫描**

```
sonar-scanner -Dsonar.login=myAuthenticationToken
```



