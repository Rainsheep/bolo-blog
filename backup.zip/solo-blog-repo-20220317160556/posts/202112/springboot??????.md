title: springboot  多个配置文件
date: '2021-12-30 19:02:34'
updated: '2021-12-30 19:02:34'
tags: [springboot]
permalink: /articles/2021/12/30/1640862154579.html
---
参考文档：[profile之springboot](https://blog.csdn.net/java_collect/article/details/83833686)

另外一种多配置文件方式参考：[maven profile](https://www.rainsheep.cn/articles/2021/12/30/1640861247161.html)

## 1. 简介

想必大家都有这种经历，我们开发项目的时候要有多个环境，如开发环境、测试环境、生产环境，他们的配置文件一般不同，如数据库地址。当我们要向各个环境发布程序时，需要人工处理这些配置文件，这显然麻烦且易错。有了 profile，一切问题就简单了。简单讲 profile 就是一组配置，不同 profile 提供不同组合的配置，程序运行时可以选择使用哪些 profile 来适应环境。

## 2. 多配置文件

多个 application-{profile}.properties 文件

我们先来搭建一个简单的 springboot 项目快速了解多 profile 的使用。项目结构非常简单： ![20181107222458680](https://oss.rainsheep.cn/blog/20181107222458680-1640861586-325.png)

除了 application.properties 还有多个 application-{profile}.properties（格式必须为这样）,在每个配置文件中项目启动的端口是不一样的。

在 application.properties 使用 spring.profiles.active=prod 来指定生效的配置文件为 application-prod.properties. 启动项目后可以在控制台看到启动端口为 application-prod.properties 里配置的 server.port=8084

### 2.1 profile 多种激活方式

1. 第一种就是上面的在配置文件中通过 spring.profiles.active= 来指定，注意可以激活多个 profile，如`spring.profiles.active=prod, dev` 如果都存在某值，执行 last win 策略。
2. 通过命令行方式。优先级高于第一种的spring.profiles.active
   
   * 执行 `java -jar xxx.jar`，可以观察到服务端口被设置为 8082。
   * 执行 `java -jar xxx.jar –spring.profiles.active=test`，可以观察到服务端口被设置为8083，也就是（test）环境的配置
3. 通过虚拟机参数。-Dspring.profiles.active=dev
4. 使用编程的方式激活
   
   ```java
   @SpringBootApplication
   public class Application {
   
      public static void main(String[] args) {
          ConfigurableApplicationContext applicationContext = SpringApplication.run(Application.class, args);
          applicationContext.getEnvironment().setActiveProfiles("dev");
      }
   }
   ```

### 2.2 spring.profiles.include 属性

![20181107222055536](https://oss.rainsheep.cn/blog/20181107222055536-1640861926-4f5.png)

意思是无论执行哪个 profile，都会去加载 application-mq.properties 里的配置。但是注意，只会去加载application-mq.properties 里独有的配置，如果 application-mq.properties 也有 server.port 字段并不会生效。

可以利用这种方式简化配置文件的书写，如在 application-mq.properties 书写各个环境都有的 mq 配置信息，不必都夹杂在 application.properties 里。

### 2.3 总结

* application.properties 文件是必定要加载的，而且是先加载的，无论是通过哪种方式指定的。
* 当加载完 application 文件之后才加载指定的 profiles 文件
* 如果 application 文件和指定的 profile 文件有相同的配置或冲突的配置项，则以 profile 中的为基准
* application 文件中写通用的配置项，profile 文件中写特定环境的配置项，spring.profiles.include 指定公共的配置项（起到了分离的作用），这样可以简化配置文件的书写。
  

