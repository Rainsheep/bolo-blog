title: 修改 class 变量值
date: '2021-06-01 15:39:29'
updated: '2021-06-01 15:39:29'
tags: [java]
permalink: /articles/2021/06/01/1622533169881.html
---
目的：不经过反编译，直接修改 class 文件的变量值。

所需工具：Jclasslib 库[Jclasslib.zip](https://b3logfile.com/file/2021/06/Jclasslib-e47178ed.zip)，jclasslib Bytecode Viewer(IDEA 插件)

用 IDEA 打开要修改的 class 文件，然后点击视图 -> Show Bytecode With Jclasslib, 找到要修改的字符串，比如 "status"

![jclasslib.png](https://b3logfile.com/file/2021/06/image-70775e4a.png)

可见此常量指向 #145 地址，跟踪过去

![image.png](https://b3logfile.com/file/2021/06/image-dae787a2.png)

我们修改 145 地址中的内容即可，修改程序如下：

```java
import java.io.*;

import org.gjt.jclasslib.structures.Constant;
import org.gjt.jclasslib.io.ClassFileWriter;
import org.gjt.jclasslib.structures.ClassFile;
import org.gjt.jclasslib.structures.constants.ConstantUtf8Info;

public class Test {
    public static void main(String[] args) throws Exception {
        // .class 文件绝对的路径
        String filePath = "/home/rainsheep/Desktop/SmoothStreamingTestMediaDrmCallback.class";
        FileInputStream fis = new FileInputStream(filePath);
        DataInput di = new DataInputStream(fis);
        ClassFile cf = new ClassFile();
        cf.read(di);
        Constant[] infos = cf.getConstantPool();
        int count = infos.length;
        for (int i = 0; i < count; i++) {
            if (infos[i] != null) {
                System.out.print(i + " = " + infos[i].getVerbose() + " = end");
                // JclassLib 中的地址
                if (i == 145) {
                    ConstantUtf8Info uInfo = (ConstantUtf8Info) infos[i];
                    //新的变量
                    uInfo.setString("newString");
                    infos[i] = uInfo;
                }
            }
        }
        cf.setConstantPool(infos);
        fis.close();
        File f = new File(filePath);
        ClassFileWriter.writeToFile(f, cf);
    }
}
```

运行以后(需要导入 jar 包)，然后反编译新的 class 文件查看，即可发现，字符串已经修改为 newString。



