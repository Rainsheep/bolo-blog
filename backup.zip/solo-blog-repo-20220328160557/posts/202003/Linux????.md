title: Linux 学习笔记
date: '2020-03-09 22:17:46'
updated: '2021-08-01 23:39:28'
tags: [Linux, 学习笔记]
permalink: /articles/2020/03/09/1583763466425.html
---
# vim的三种模式

## 正常模式

以vim打开一个档案就直接进入一般模式了（这是默认的模式）在这个模式中，你可以使用
『上下左右』按键来移动光标，你可以使用『删除字符』或『删除整行』来处理档案内容，
也可以使用『复制、粘贴』来处理你的文件数据。

## 插入模式

按下i,l,o,O,a,A,r,R等任何一个字母之后才会进入编辑模式，一般来说按i即可，插入模式无法使用快捷键

## 命令行模式

在这个模式当中，可以提供你相关指令，完成读取、存盘、替换、离开vim、显示行号等的动作则是在此模式中达成的！

## 命令行→正常模式

vim xxx进入正常模式，例如vim Hello.java

## 正常模式→命令行模式

输入:或者/跟命令就行，例如:wq

## 命令行模式→正常模式

按ESC

## 正常模式→插入模式

按i或者a即可

## 插入模式→正常模式

按ESC

## :q :wq :q!三者的区别

:q退出(未修改)  :wq(保存修改并退出) :q!(修改了但不想保存)

# vi和vim常用快捷键

复制当前行	yy
拷贝当前行向下的5行	5yy
粘贴	p
删除当前行	dd
删除当前行向下的5行	5dd
撤销上一步操作	u
恢复被撤销的操作	ctrl+r
查找	/关键字，按n下一个
显示行号	:set nu
隐藏行号	:set nonu
最末行	G
最首行	gg
跳到某行	先输入数字n，然后按shift+g即可

## 设置vim默认显示行号

```
vim /etc/vimrc
最后一行加上set nu
:wq写入退出即可
```

## 误按ctrl+z的解决方案

ctrl+z是强制将进程加入后台运行，终端输入fg即可调出后台进程

## xhsell中右边小键盘数字键无法使用

选择连接，点击属性，将终端中的终端类型选择为linux

# 关机&重启

## shutdown

shutdown -h now	立即关机
shutdown -h 1	1分钟后关机
shutdown -r now	立即重启

## halt

直接使用，等价于关机

shutdown	安全关机，root用户使用，关机且关闭电源
halt	关机不关闭电源，普通用户使用
init 0	关机或重启的本质都是修改运行级别，root用户使用

## poweroff

关机，多用户方式runlevel3下不建议使用

## reboot

重启

## sync

把内存数据写入磁盘,关机或者重启时都应该先执行该指令，防止数据丢失

# 用户管理

useradd name	添加用户
useradd -d 指定目录 新的用户名	给新创建的用户指定家目录
userad -g 用户组 用户名
passwd name	给用户指定密码
userdel name	删除用户
userdel -r name	删除用户并且删除对应的home目录
id name	查询用户信息
su - name	切换用户
exit	返回用户
groupadd name	增加组
groupdel name	删除组
usermod -g 用户组 用户名	修改用户组

# 运行级别

0：关机
1：单用户【找回丢失密码】
2：多用户状态没有网络模式
3：多用户状态有网络模式
4：系统未使用保留给用户
5：图形界面
6：系统重启
常用运行级别是3和5，要修改默认的运行级别可修改文件/etc/inittab的id:5:initdefault:这一行的数字
修改运行级别用init n

## 找回root用户

思路：进入单用户模式(run level 1)，修改root密码，因为进入单用户模式，root不需要尼玛就可以登录。
开机→引导时输入回车→看到一个界面输入e→看到一个新的界面，选中第二行(kernel)，输入e→在这行最后输入 1，再输入回车→进入单用户模式→输入passwd root修改密码。

# 帮助指令

man [命令指令或配置文件]	获取帮助信息
help 命令	获得shell内置命令的帮助信息

# 文件目录类指令

pwd	显示当前工作目录的绝对路径

ls [选项] [目录模式文件]
-a	显示当前目录的所有文件和目录，包括隐藏文件
-l	以列表的方式显示信息

mkdir [选项] 要创建的目录
-p	创建多级目录

rmdir [选项] 要删除的空目录
rm -rf 目录	删除非空目录

rm [选项] 要删除的文件或目录
-r	递归删除整个文件夹
-f	强制删除不提示

touch 文件名称	创建空文件 ，可以一次创建多文件

cp [选项] source dest	拷贝文件到指定目录
-r	递归复制整个文件夹
\cp	表示覆盖复制

mv 当前文件或目录 目的文件或目录	移动文件与目录或重命名

cat [选项] 要查看的文件	查看文件内容,只能读，不能改
-n	显示行号
cat [选项] 要查看的文件 | more	分页显示，空格下一页

more 要查看的文件	它以全屏幕的方式按页显示文本文件的内容
内置快捷键
space	向下翻一页
enter	向下一行
q	退出more
ctrl+b	返回上一屏
ctrl+f	向下滚动一屏
=	输出当前行号
:f	输出文件名和当前行的行号

less 要查看的文件	用来分屏查看文件内容，它的功能与more指令类似，但是比more指令更加强大。并不是一次将整个文件加载之后才显示，而是根据显示需要加载内容，对于显示大型文件具有较高的效率。
内置快捷键
space	向下翻动一页
[pagedown]	向下翻动一页
[pageup]	向上翻动一页
/子串	向下搜索子串功能，n向下查找，N向上查找
?子串	向上搜索子串功能，n向上查找，N向下查找
q	离开这个less
enter    向下一行
g     跳到第一行
G     跳到最后一行
v      调用 vi 编辑

\>指令和>>指令	>输出重定向，>>追加
ls -l > 文件	列表的内容写入文件中（覆盖写）
ls -al >> 文件	列表的内容追加到文件的末尾
cat 文件1 > 文件2	将文件1的内容覆盖到文件2
echo "内容" >> 文件	将内容追加到文件

echo [选项] [输出内容]	输出内容到控制台

head 文件	查看文件头10行内容
head -n 5 文件	查看文件头5行内容，5可以是任意行数

tail 文件	查看文件后10行内容
tail -n 5 文件	查看文件后5行内容，5可以是任意行数
tail -f 文件	实时追踪该文档的所有更新

ln -s 原文件或目录 软链接名	功能描述给原文件创建一个软链接,-s表示软连接，不带s为硬链接，都保持同步更新

history	查看已经执行过的历史命令
history 10	显示最近使用过的10个命令，10可以是任意数字
!10	重新执行历史编号为10的指令

# 时间日期类相关指令

date	显示当前时间
date "+%Y-%m-%d %H:%M:%S"	显示年月日时分秒，中间连接符自定义，前面需要带上+号
date -s "2018-10-10 11:22:22"	设置系统时间

cal [选项]	不加选项，显示本月日历
cal 2020	显示2020年的日历

# 搜索查找类指令

find [搜索范围] [选项]	find指令将从指定目录向下递归地遍历其各个子目录，将满足条件的文件或者目录显示在终端。
选项说明
-name	按照指定的文件名查找模式查找文件
find / -name test.txt
-user	查找属于指定用户名所有文件
find / -user root
-size	按照指定的文件大小查找文件（+n大于 -n小于 n等于）
find / -size +20M

locate指令
locate 搜索文件

```
locate指令可以快速定位文件路径,由于 locate指令基于数据库进行查询，所以第一次运行前，必须使用 updatedb指令创建 locate数据库。
```

grep指令和管道符号|
grep过滤查找，管道符|，表示将前一个命令的处理结果输出传递给后面的命令处理。
grep [选项] 查找内容 源文件
-n	显示匹配行及行号
-i	忽略字母大小写
例如 cat test.txt | grep -n yes   查找yes

# 压缩和解压缩

gzip 文件名	用于压缩文件，压缩完以后自动删除源文件,用于.gz格式
gunzip 文件.gz	用于解压文件

zip [选项] name.zip 要压缩的内容
-r	递归压缩，压缩目录
unzip [选项] name.zip
-d<目录>	指定解压后文件的存放目录

tar指令
是打包指令，最后打包后的文件是tar.gz的文件。
tar [选项] name.tar.gz 打包的内容
-c	产生.tar打包文件
-v	显示详细信息
-f	指定压缩后的文件名
-z	打包同时压缩
-x	解包.tar文件
tar -zcvf name.tar.gz a1.txt a2.txt	压缩文件
tar -zcvf name.tar.gz /home	压缩目录
tar -zxvf name.tar.gz	解压到当前目录
tar -zxvf name.tar.gz -C /目录	解压到指定目录

# 组管理和权限管理

chown 用户名 文件名	修改文件所有者

groupadd 组名	创建组

chgrp 组名 文件名	修改文件所在组

usermod -g 组名 用户名	修改用户所在组

usermod -d 目录名 用户名	改变用户登录的初始目录

# 权限详解

## 权限介绍

-rwxrw-r-- 1 root root 1213 Feb 2 09:39 abc.txt

0-9 位说明
1)第 0 位确定文件类型(d目录, -文件 , l 软连接, c字符设备，键盘鼠标 , b块文件，硬盘)
2)第 1-3 位确定所有者（该文件的所有者）拥有该文件的权限。---User
3)第 4-6 位确定所属组（同用户组的）拥有该文件的权限，---Group
4)第 7-9 位确定其他用户拥有该文件的权限 ---Other
5)如果是文件，表示硬链接数目，如果是目录，代表子目录个数（默认包含当前目录.和上级目录..）
6)后面两个代表文件所有者和文件所在组
7)代表文件大小，单位字节，目录为4096字节
8)最后修改时间
9)文件名字

## rwx权限详解

r：文件中可以读取查看，目录中可以ls查看目录内容
w:文件中可以修改，但是不代表可以删除该文件,删除一个文件的前提条件是对该
文件所在的目录有写权限，才能删除该文件。目录中可以修改,目录内创建+删除+重命名目录。
x:文件中可以被执行，目录中可以进入该目录。
可用数字表示为: r=4,w=2,x=1 因此 rwx=4+2+1=7

## 修改权限

指令：chmod
u:所有者 g:所有组 o:其他人 a:所有人

1) chmod u=rwx,g=rx,o=x 文件目录名
2) chmod o+w 文件目录名	其他人加上w权限
3) chmod a-x 文件目录名	所有人加上x权限

通过数字修改
chmod u=rwx,g=rx,o=x 文件目录名
相当于
chmod 751 文件目录名

## 修改目录所有者和所在组

chown newowner file 改变文件的所有者
chgrp newgroup file 改变文件的所有组
chown newowner:newgroup file 改变用户的所有者和所有组
-R 如果是目录 则使其下所有子文件或目录递归生效

# crond任务调度

基本语法	crontab [选项]
-e	编辑定时任务
-l	查询任务
-r	删除当前用户的所有任务

第一个*	分钟
第二个*	小时
第三个*	日
第四个*	月
第五个*	星期几

*代表任何时间，，代表不连续时间，-代表范围，\*/n代表每隔多久执行一次

*/ 1 * * * * ls -l /etc >> /tmp/to.txt

每隔一分钟追加一次

service crond restart 	重启任务调度

# 磁盘分区和挂载

## 挂载U盘

fdisk -l	查看是否有U盘
mount	查看U盘是否挂载
mount /dev/sdb1 挂载目录	挂载U盘
umount /dev/sdb1或者挂载点	卸载

## 查询磁盘使用情况

df -h

### 查询目录的磁盘占用情况

du -h /目录
-s	 指定目录占用大小汇总
-h	 带计量单位
-a	 含文件
--max-depth=1	 子目录深度
-c 	列出明细的同时，增加汇总值

# 进程管理

## 查看进程

ps -aux	显示所有进程
-a 显示当前终端的所有进程信息
-u 以用户的格式显示进程信息
-x 显示后台进程运行的参数

ps -ef	 是以全格式显示当前所有的进程
-e 显示所有进程
-f 全格式

pstree 进程树
-p	显示进程PID
-u	显示进程的所属用户

## 显示详解

ps -aux
USER：用户名称
PID：进程号
%CPU：进程占用 CPU 的百分比
%MEM：进程占用物理内存的百分比
VSZ：进程占用的虚拟内存大小（单位：KB）
RSS：进程占用的物理内存大小（单位：KB）
TT：终端名称,缩写 .
STAT：进程状态，其中 S-睡眠，s-表示该进程是会话的先导进程，N-表示进程拥有比普通优先级更低的优先级，R-正在运行，D-短期等待，Z-僵死进程，T-被跟踪或者被停止等等
STARTED：进程的启动时间
TIME：CPU 时间，即进程使用 CPU 的总时间
COMMAND：启动进程所用的命令和参数，如果过长会被截断显示

ps -ef
UID：用户 ID
PID：进程 ID
PPID：父进程 ID
C：CPU 用于计算执行优先级的因子。数值越大，表明进程是 CPU 密集型运算，执行优先级会降低；数值越小，表明进程是 I/O 密集型运算，执行优先级会提高
STIME：进程启动的时间
TTY：完整的终端名称
TIME：CPU 时间
CMD：启动进程所用的命令和参数

## 终止进程

kill [选项] 进程PID	通过进程号杀死进程
-9	强制杀掉

killall 进程名字	通过进程名称杀死进程
例如 killall gedit

## 动态监控进程

top [选项]

```
-p	通过指定监控进程PID来仅仅监控某个进程的状态
```

交互操作：

```
以CPU使用率排序，默认就是此项
	以内存的使用率排序
	以PID排序
	退出top
```

# 服务管理

service 服务名 [start | stop | restart | reload | status]
在 CentOS7.0 后 不再使用 service ,而是 systemctl

用法：

systemctl start|stop|restart|reload|status 服务名

systemctl enable/disable 服务名，开启/关闭服务并开启/禁止其开机自启

列出服务名：ll /etc/init.d/

chkconfig --list	可以查看服务在各个运行级别下的自启

service sshd status	查看 sshd 服务的运行状态

chkconfig --level 5 sshd off	将 sshd 服务在运行级别 5 下设置为不自动启动

chkconfig iptables off	在所有运行级别下，关闭防火墙

chkconfig iptables on	在所有运行级别下，开启防火墙

chkconfig 重新设置服务后自启动或关闭，需要重启机器 reboot 才能生效

# 防火墙管理

参考文档：[Linux 防火墙命令](https://blog.csdn.net/baidu_36124158/article/details/90603496)

```bash
# 安装防火墙
yum install firewalld firewalld

# 查看防火状态
systemctl status firewalld
firewall-cmd --state
service  iptables status

# 暂时关闭防火墙
systemctl stop firewalld
service  iptables stop

# 永久关闭防火墙
systemctl disable firewalld
chkconfig iptables off

# 重启防火墙
systemctl enable firewalld
service iptables restart  

# 开启防火墙
systemctl start firewalld

# 永久开启防火墙
systemctl enable firewald
chkconfig iptables on

# 更新防火墙规则
firewall-cmd --reload

# 打开端口
firewall-cmd --zone=public --permanent --add-port=80/tcp 

# 列出端口
firewall-cmd --zone=public --list-ports
```

# yum教程

yum check-update	检验更新
yum update	升级所有包同时也升级软件和系统内核
yum upgrade	只升级所有包，不升级软件和系统内核
yum install name	安装
yum remove name	移除
yum list	列出资源库中所有可以安装或更新的rpm包
yum info xxx                查看xxx软件的信息（已安装）
yum search xxx           搜索软件包（以名字为关键字）
yum list installed         列出已经安装的包

# Shell编程

开头：#!/bin/bash

## sh脚本的两种运行方式

./name.sh	脚本需要有x权限
sh  ./name.sh	不需要权限，不推荐

## 定义变量规则

定义变量：变量=值
撤销变量：unset 变量
声明静态变量：readonly 变量，注意：不能 unset

## 将命令的返回值赋给变量

A=\`ls -la` 反引号，运行里面的命令，并把结果返回给变量 A

A=$(ls -la) 等价于反引号

## 设置环境变量

参考文献：[etc/profile和~/.bashrc的区别](https://blog.csdn.net/ZoeYen_/article/details/78560905)

**此处只讨论 bash，不讨论其他 shell**

* `/etc/profile`：系统级别配置，当用户第一次登录时，该文件被执行。是系统全局针对终端环境的设置，它是 login 时最先被系统加载的，是它调用了 `/etc/bashrc`，以及 `/etc/profile.d` 目录下的 `*.sh` 文件。
* `~/.bashrc`: 用户级别配置，通常打开一个新终端时，默认会 load 里面的设置，在这里的设置不影响其它人。如果一个服务器多个开发者使用，大家都需要有自己的 sdk 安装和设置，那么最好就是设置它。
* `/etc/bashrc`: 系统级别配置，修改了它，会影响所有用户的终端环境，这里一般配置终端如何与用户进行交互的增强功能等。
* `~/.bash_profile`：用户级别配置，每个用户都可使用该文件输入专用于自己使用的 shell 信息，当用户登录时，该文件仅仅执行一次，默认情况下，他设置一些环境变量，执行用户的 `.bashrc` 文件。

我们看一下四者的区别：

![20171117142454885.png](https://b3logfile.com/file/2021/01/20171117142454885-55089231.png)

`/etc/profile` 和 `~/.bash_profile` 是交互式的。

`/etc/bashrc` 和 `~/.bashrc` 是非交互式的。

交互式模式就是 shell 等待你的输入，并且执行你提交的命令。这种模式被称作交互式是因为 shell 与用户进行交互。这种模式也是大多数用户非常熟悉的：登录、执行一些命令、签退。当你签退后，shell也终止了。

非交互式模式，在这种模式下，shell 不与你进行交互，而是读取存放在文件中的命令,并且执行它们。当它读到文件的结尾，shell 也就终止了。

> 交互式的配置文件会自动去加载非交互式的配置文件

**总结：我们一般配置 `~/.bashrc` 即可**

**配置内容如下**

export 变量名=变量值	将 shell 变量输出为环境变量
source 配置文件	让修改后的配置信息立即生效

## 位置参数

运行的时候传参 ./myshell.sh 100 200
代码中获取参数：

- \$n （功能描述：n 为数字，$0 代表命令本身，$1-$9 代表第一到第九个参数，十以上的参数，十
  以上的参数需要用大括号包含，如${10}）
- \$* （功能描述：这个变量代表命令行中所有的参数，$*把所有的参数看成一个整体）
- \$@（功能描述：这个变量也代表命令行中所有的参数，不过$@把每个参数区分对待）
- \$#（功能描述：这个变量代表命令行中所有参数的个数）

## 运算符

1. $[运算式]	推荐
2. $((运算式))
3. expr m + n
   注意 expr 运算符间要有空格
4. expr m - n
5. expr \*, /, % 乘，除，取余

## 条件判断

[ condition ]（注意 condition 前后要有空格）
#非空返回 true，可使用$?验证（0 为 true，>1 为 false）

判断条件：
= 字符串比较
-lt 小于
-le 小于等于
-eq 等于
-gt 大于
-ge 大于等于
-ne 不等于
-r 有读的权限 [ -r 文件 ]
-w 有写的权限
-x 有执行的权限
-f 文件存在并且是一个常规的文件
-e 文件存在
-d 文件存在并是一个目录

语法：
if [ 条件判断式 ]
then
程序
elif [条件判断式]
then
程序
fi

## case语句

case $变量名 in
"值 1"）
如果变量的值等于值 1，则执行程序 1
;;
"值 2"）
如果变量的值等于值 2，则执行程序 2
;;
*）
如果变量的值都不是以上的值，则执行此程序
;;
esac

## for循环

for 变量 in  值1  值2  值 3 …
do
程序
done

---

for ((  初始值; 循环控制条件;变量变化 ))
do
程序
done

## while循环

while [ 条件判断式 ]
do
程序
done

## read读入

read [选项] [参数]
-p：指定读取值时的提示符；
-t：指定读取值时等待的时间（秒），如果没有在指定的时间内输入，就不再等待了

## 函数

### 系统函数

basename 基本语法
功能：返回完整路径最后 / 的部分，常用于获取文件名
basename  [pathname]  [suffix]

例如 basename /home/aaa/test.txt	结果为test.txt
basename /home/aaa/test.txt  .txt	结果为test

dirname	返回完整路径最后 / 的前面的部分，常用于返回路径部分
例如 dirname /home/aaa/test.txt	结果为 /home/aaa

### 自定义函数

[ function ] funname[()]
{
Action;
[return int;]
}

# 命令总结

ls	显示指定目录下的内容,-s显示文件大小(带单位)
ll	显示指定目录下的内容的详细信息
pws	打印当前目录全路径
clear	清屏
cal	日历
wc -l	统计行数
grep "^-"	以-开头
netstat -anp	查看所有的网络服务(监听状态)
ssh 用户名@IP	 从 linux 系统客户机远程登陆 linux 系统服务机
set	显示当前 shell 中所有变量
&&	表示前一条命令执行成功时，才执行后一条命令
||	 表示上一条命令执行失败后，才执行下一条命令
sudo chown -R username 文件路径   递归修改文件的拥有者



