title: springboot 日志
date: '2021-09-21 12:10:15'
updated: '2021-09-21 12:58:43'
tags: [java]
permalink: /articles/2021/09/21/1632197415896.html
---
参考文献：

[SpringBoot日志打印增加方法和行号](https://blog.csdn.net/weixin_43030522/article/details/107535618)
[logging日志 --SpringBoot功能](https://www.cnblogs.com/ylcc-zyq/p/12600760.html)
[log4j 日志格式详解](https://blog.csdn.net/zhangyunfei1984/article/details/115419360)

## 1. springboot 日志的默认配置

查找资料发现 springboot 通过 logging.pattern.console 来配置日志格式，我们想查看默认配置。

可以看到默认配置位于 org.springframework.boot:spring-boot:2.5.1 库下面，![image-20210921010359569](https://oss.rainsheep.cn/blog/image-20210921010359569-1632157439-4b8.png)

找到对应配置文件：![image-20210921114936151](https://oss.rainsheep.cn/blog/image-20210921114936151-1632196176-16e.png)

![image-20210921115002314](https://oss.rainsheep.cn/blog/image-20210921115002314-1632196202-5da.png)

可以看到默认配置为：

```
"%clr(%d{${LOG_DATEFORMAT_PATTERN:-yyyy-MM-dd HH:mm:ss.SSS}}){faint} %clr(${LOG_LEVEL_PATTERN:-%5p}) %clr(${PID:- }){magenta} %clr(---){faint} %clr([%15.15t]){faint} %clr(%-40.40logger{39}){cyan} %clr(:){faint} %m%n${LOG_EXCEPTION_CONVERSION_WORD:-%wEx}"
```

## 2. 日志格式配置解析

默认格式打印日志如下：

```
-2021-09-21 00:58:36.537 - WARN 6273 --- [nio-8080-exec-1] c.r.m.t.s.impl.UmsAdminServiceImpl       : 登录异常:用户名或密码错误
```

### 2.1 彩色编码输出

使用 ％clr 转换字配置颜色编码。 转换器以最简单的形式根据日志级别输出着色，如以下示例所示：

```
%clr(%-5p)
```

下表描述了日志级别到颜色的映射：

| Level   | Color  |
| :------ | :----- |
| `FATAL` | Red    |
| `ERROR` | Red    |
| `WARN`  | Yellow |
| `INFO`  | Green  |
| `DEBUG` | Green  |
| `TRACE` | Green  |

另外，您可以通过将其提供为转换的选项来指定应使用的颜色或样式。 例如，要使文本变黄，请使用以下设置：

```
%clr(%d{yyyy-MM-dd HH:mm:ss.SSS}){yellow}
```

支持以下颜色和样式:

- `blue`
- `cyan`
- `faint`
- `green`
- `magenta`
- `red`
- `yellow`

### 2.2 字符解释

下表说明了以上模式使用的字符和所有其他字符，可以在自定义模式中使用：

| 转换字符 | 表示的意思                                                   |
| -------- | ------------------------------------------------------------ |
| c        | 用于输出的记录事件的类别。例如，对于类别名称”a.b.c” 模式 %c{2} 会输出 “b.c” |
| C        | 用于输出呼叫者发出日志请求的完全限定类名。例如，对于类名 “org.apache.xyz.SomeClass”, 模式 %C{1} 会输出 “SomeClass”. |
| d        | 用于输出的记录事件的日期。例如， %d{HH:mm:ss,SSS} 或 %d{dd MMM yyyy HH:mm:ss,SSS}. |
| F        | 用于输出被发出日志记录请求，其中的文件名                     |
| l        | 用于将产生的日志事件调用者输出位置信息                       |
| L        | 用于输出从被发出日志记录请求的行号                           |
| m        | 用于输出使用日志事件相关联的应用程序提供的消息               |
| M        | 用于输出发出日志请求所在的方法名称                           |
| n        | 输出平台相关的行分隔符或文字                                 |
| p        | 用于输出的记录事件的优先级                                   |
| r        | 用于输出毫秒从布局的结构经过直到创建日志记录事件的数目       |
| t        | 用于输出生成的日志记录事件的线程的名称                       |
| x        | 用于与产生该日志事件的线程相关联输出的NDC（嵌套诊断上下文）  |
| X        | 在X转换字符后面是键为的MDC。例如 X{clientIP} 将打印存储在MDC对键clientIP的信息 |
| %        | 文字百分号 %%将打印％标志                                    |

### 2.3 格式修饰符

默认情况下，相关资料原样输出。然而，随着格式修饰符的帮助下，可以改变最小字段宽度，最大字段宽度和对齐。

下表涵盖了各种各样的修饰符的情况：

| Format modifier | left justify | minimum width | maximum width | 注释                                                         |
| --------------- | ------------ | ------------- | ------------- | ------------------------------------------------------------ |
| %20c            | false        | 20            | none          | 用空格左垫，如果类别名称少于20个字符长                       |
| %-20c           | true         | 20            | none          | 用空格右垫，如果类别名称少于20个字符长                       |
| %.30c           | NA           | NONE          | 30            | 从开始截断，如果类别名称超过30个字符长                       |
| %20.30c         | false        | 20            | 30            | 用空格左侧垫，如果类别名称短于20个字符。但是，如果类别名称长度超过30个字符，那么从开始截断。 |
| %-20.30c        | true         | 20            | 30            | 用空格右侧垫，如果类别名称短于20个字符。但是，如果类别名称长度超过30个字符，那么从开始截断。 |

### 2.4 默认日志格式解析

1. `%clr(%d{${LOG_DATEFORMAT_PATTERN:-yyyy-MM-dd HH:mm:ss.SSS}}){faint}` 打印时间
2. `%clr(${LOG_LEVEL_PATTERN:-%5p})` 打印日志级别
3. `%clr(${PID:- }){magenta}`  打印进程 ID
4. `%clr(---){faint}` 打印---
5. `%clr([%15.15t]){faint}` 打印线程信息
6. `%clr(%-40.40logger{39}){cyan}` 打印类名
7. `%clr(:){faint} %m%n${LOG_EXCEPTION_CONVERSION_WORD:-%wEx}` 打印日志消息

## 3. 修改日志格式

我们想要在原本日志格式上面进行修改，加上日志打印的方法和代码行号，可以这样设置。

```
"%clr(%d{${LOG_DATEFORMAT_PATTERN:yyyy-MM-dd HH:mm:ss.SSS}}){faint} %clr(${LOG_LEVEL_PATTERN:-%5p}) %clr(${PID:- }){magenta} %clr(---){faint} %clr([%15.15t]){faint} %clr(%-40.40logger{39} %-13.13M){cyan} %clr(%4.4L) %clr(:){faint} %m%n${LOG_EXCEPTION_CONVERSION_WORD:-%wEx}"
```

## 4. Marker

marker 相当于一个标记，可以根据其过滤日志，作用不大。

```java
import org.slf4j.Marker;
import org.slf4j.MarkerFactory;

private static final Marker MARKER = MarkerFactory.getMarker("UmsAdminServiceImpl => ");

LOGGER.info(MARKER, "login");
```



