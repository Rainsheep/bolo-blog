title: android levelList
date: '2021-06-25 21:58:49'
updated: '2021-06-25 21:58:49'
tags: [android]
permalink: /articles/2021/06/25/1624629529215.html
---
参考文献：

[android levellistdrawable 基本使用](https://blog.csdn.net/zzldm/article/details/52982105)

## 1. 介绍

LevelListDrawable 可以通过改变 level 值来切换相应的图片。

## 2. 基本使用

**在 drawable 创建**

```xml
<?xml version="1.0" encoding="utf-8"?>
<level-list xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:drawable="@drawable/lamp_on" //灯亮的图片
        android:minLevel="12"
        android:maxLevel="20"/>
 
    <item android:drawable="@drawable/lamp_off" //灯灭的图片
          android:minLevel="6"
          android:maxLevel="10"/>
</level-list>
```

**布局文件**

```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
              android:orientation="vertical"
              android:layout_width="match_parent"
              android:layout_height="match_parent">
 
    <ImageView
        android:src="@drawable/bitmap"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:id="@+id/iv_drawable"/>
 
    <Button
        android:id="@+id/btn_on"
        android:text="light on"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"/>
 
    <Button
        android:id="@+id/btn_off"
        android:text="light off"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"/>
</LinearLayout>
```

**activity**

```java
public class TestDrawable extends AppCompatActivity implements View.OnClickListener{
    private Button on,off;
    private ImageView iv;
 
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.testdrawable);
 
        on = (Button) findViewById(R.id.btn_on);
        off = (Button) findViewById(R.id.btn_off);
        on.setOnClickListener(this);
        off.setOnClickListener(this);
        iv = (ImageView) findViewById(R.id.iv_drawable);
        iv.setImageLevel(8);
    }
 
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_off){
            //设置的level值必须在6-10之间
            iv.setImageLevel(8);
        }else if (v.getId() == R.id.btn_on){
            //设置的level值必须在12-20之间
            iv.setImageLevel(18);
        }
    }
}
```



