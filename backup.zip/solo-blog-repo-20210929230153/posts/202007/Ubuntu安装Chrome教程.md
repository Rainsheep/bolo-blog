title: Ubuntu安装Chrome教程
date: '2020-07-20 14:55:24'
updated: '2020-07-20 14:55:24'
tags: [Linux]
permalink: /articles/2020/07/20/1595228124635.html
---
参考：[Ubuntu16.04之Google-Chrome安装教程](https://blog.csdn.net/CiaoTigre/article/details/104289299)

### 1.将下载源加入到系统的源列表

 `sudo wget http://www.linuxidc.com/files/repo/google-chrome.list -P /etc/apt/sources.list.d/`

> 如果返回“地址解析错误”等信息，可以百度搜索其他提供 Chrome 下载的源，用其地址替换掉命令中的地址.

### 2.导入谷歌软件的公钥

`wget -q -O - https://dl.google.com/linux/linux_signing_key.pub  | sudo apt-key add -`

用于下面步骤中对下载软件进行验证。如果顺利的话，命令将返回“OK”

### 3.更新源列表

`sudo apt-get update`

### 4.安装Chrome

`sudo apt-get install google-chrome-stable`
