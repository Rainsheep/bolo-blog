title: MVC 开发模式和三层架构
date: '2020-02-26 12:17:40'
updated: '2020-02-26 18:34:44'
tags: [Java, 学习笔记]
permalink: /articles/2020/02/26/1582690660373.html
---
### MVC 开发模式

![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-02-26+13:54:02+MVC开发模式.bmp)

* MVC 并不是设计模式。
* M：Model，模型。
  * 完成具体的业务操作，如：查询数据库，封装对象。
  * 在 Javawb 中由 JavaBean 充当。
  * V：View，视图。
    * 展示数据。
    * 在 Javawb 中由 JSP 充当。
  * C：Controller，控制器。
    * 获取用户的输入。
    * 调用模型。
    * 将数据交给视图进行展示。
    * 在 Javawb 中由 Servlet 充当。
* 优点：
  * 耦合性低，方便维护，可以利于分工协作。
  * 重用性高。
* 缺点：
  * 使得项目架构变得复杂，对开发人员要求高。

### 三层架构：软件设计架构

![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-02-26+18:32:32+三层架构.bmp)

* 界面层(表示层/web 层)：用户看的得界面。用户可以通过界面上的组件和服务器进行交互。
* 业务逻辑层(service 层)：处理业务逻辑的。
* 数据访问层(dao 层)：操作数据存储文件。
