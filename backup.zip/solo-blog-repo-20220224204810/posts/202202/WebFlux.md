title: WebFlux
date: '2022-02-22 13:03:59'
updated: '2022-02-22 13:03:59'
tags: [java, spring, springboot]
permalink: /articles/2022/02/22/1645506239831.html
---
参考文档：
[WebFlex](https://docs.spring.io/spring-framework/docs/current/reference/html/web-reactive.html#webflux)
[Reactive Spring实战 -- WebFlux使用教程](https://segmentfault.com/a/1190000039003808)
[Spring5之WebClient简单使用](https://www.jianshu.com/p/cc3a99614476)
[Spring的WebClient基本使用 ](https://www.cnblogs.com/grasp/p/12179906.html)

> 本文主要介绍 WebClient 用法

# 1. Configuration

## 1.1 maven

```xml
<dependency>
   <groupId>org.springframework.boot</groupId>
   <artifactId>spring-boot-starter-webflux</artifactId>
</dependency>
```

## 1.2 create

* WebClient.create()
  
  ```java
  @Test
  public void testCreate() {
      Mono<String> mono = WebClient
              //创建WenClient实例
              .create()
              //方法调用，WebClient中提供了多种方法
              .method(HttpMethod.GET)
              //请求url
              .uri("http://localhost:8080/hello")
              //获取响应结果
              .retrieve()
              //将结果转换为指定类型
              .bodyToMono(String.class);
      //block方法返回最终调用结果，block方法是阻塞的
      System.out.println("响应结果：" + mono.block());
  }
  ```
* WebClient.create(String baseUrl)：指定baseUrl，使用该客户端发送请求都是基于baseUrl。
  
  ```java
  @Test
  public void testCreateBaseUrl() {
      Mono<String> mono = WebClient
              //创建WenClient实例，指定基础url，所以下面uri请求的路径都是基于这个路径
              .create("http://localhost:8080")
              //方法调用，WebClient中提供了多种方法
              .method(HttpMethod.GET)
              //请求url
              .uri("/hello")
              //获取响应结果
              .retrieve()
              //将结果转换为指定类型
              .bodyToMono(String.class);
      //block方法返回最终调用结果，block方法是阻塞的
      System.out.println("响应结果：" + mono.block());
  }
  ```
* WebClient.builder()：返回一个WebClient.Builder，该对象可以做链式调用，传递更多的参数。
  
  ```java
  @Test
  public void testBuilder() {
      Mono<String> mono = WebClient
              .builder()
              //配置头信息，或者其他信息
              .defaultHeader("token", "123456789")
              //创建WebClient实例
              .build()
              //方法调用，WebClient中提供了多种方法
              .method(HttpMethod.GET)
              //请求url
              .uri("http://localhost:8080/hello")
              //获取响应结果
              .retrieve()
              //将结果转换为指定类型
              .bodyToMono(String.class);
  }
  ```
  
  > 支持的可选配置
  > 
  > * uriBuilderFactory: 自定义 UriBuilderFactory 灵活配置使用 URL。
  > * defaultUriVariables: 定义默认的 uri 变量
  > * defaultHeader: 为HTTP请求设置Headers请求头。
  > * defaultCookie：为HTTP请求设置Cookies。
  > * defaultRequest：自定义HttpRequest。
  > * filter：为HTTP请求增加客户端过滤器。
  > * exchangeStrategies：HTTP读写信息自定义。
  > * clientConnector：HTTP客户端连接器设置。

## 1.3 超时

连接超时配置

```java
import io.netty.channel.ChannelOption;

HttpClient httpClient = HttpClient.create()
        .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 10000);

WebClient webClient = WebClient.builder()
        .clientConnector(new ReactorClientHttpConnector(httpClient))
        .build();
```

读或写超时

```java
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;

HttpClient httpClient = HttpClient.create()
        .doOnConnected(conn -> conn
                .addHandlerLast(new ReadTimeoutHandler(10))
                .addHandlerLast(new WriteTimeoutHandler(10)));

// Create WebClient...
```

响应超时

```java
// 全部客户端
HttpClient httpClient = HttpClient.create()
        .responseTimeout(Duration.ofSeconds(2));
// Create WebClient...

// 单个客户端
WebClient.create().get()
        .uri("https://example.org/path")
        .httpRequest(httpRequest -> {
            HttpClientRequest reactorRequest = httpRequest.getNativeRequest();
            reactorRequest.responseTimeout(Duration.ofSeconds(2));
        })
        .retrieve()
        .bodyToMono(String.class);
```

# 2. retrieve

> 声明如何提取响应

获取 entity

```java
WebClient client = WebClient.create("https://example.org");

Mono<ResponseEntity<Person>> result = client.get()
        .uri("/persons/{id}", id).accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .toEntity(Person.class);
```

仅获取 body

```java
WebClient client = WebClient.create("https://example.org");

Mono<Person> result = client.get()
        .uri("/persons/{id}", id).accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .bodyToMono(Person.class);
```

获取列表

```java
Flux<Quote> result = client.get()
        .uri("/quotes").accept(MediaType.TEXT_EVENT_STREAM)
        .retrieve()
        .bodyToFlux(Quote.class);
```

处理错误状态

```java
Mono<Person> result = client.get()
        .uri("/persons/{id}", id).accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(HttpStatus::is4xxClientError, response -> ...)
        .onStatus(HttpStatus::is5xxServerError, response -> ...)
        .bodyToMono(Person.class);
```

# 3. Exchange

> exchange 替换 retrieve 获取 http 响应完整内容

```java
public void testExchange() {
    Mono<ClientResponse> clientResponseMono = WebClient
            .create()
            .method(HttpMethod.GET)
            .uri("http://localhost:8080/hello")
            .exchange();
    ClientResponse clientResponse = clientResponseMono.block();
    //响应头
    ClientResponse.Headers headers = clientResponse.headers();
    //响应状态
    HttpStatus httpStatus = clientResponse.statusCode();
    //响应状态码
    int rawStatusCode = clientResponse.rawStatusCode();
    //响应体
    Mono<String> mono = clientResponse.bodyToMono(String.class);
    String body = mono.block();
}
```

> exchangeToMono() 和 exchangeToFlux() 可以用在复杂场景，比如获取 cookie, 根据状态进行不同请求，

```java
Mono<Person> entityMono = client.get()
        .uri("/persons/1")
        .accept(MediaType.APPLICATION_JSON)
        .exchangeToMono(response -> {
            if (response.statusCode().equals(HttpStatus.OK)) {
                return response.bodyToMono(Person.class);
            }
            else {
                // Turn to error
                return response.createException().flatMap(Mono::error);
            }
        });
```

# 4. Request Body

## 4.1 json

发送 mono

```java
Mono<Person> personMono = ... ;

Mono<Void> result = client.post()
        .uri("/persons/{id}", id)
        .contentType(MediaType.APPLICATION_JSON)
        .body(personMono, Person.class)
        .retrieve()
        .bodyToMono(Void.class);
```

发送 flux

```java
Flux<Person> personFlux = ... ;

Mono<Void> result = client.post()
        .uri("/persons/{id}", id)
        .contentType(MediaType.APPLICATION_STREAM_JSON)
        .body(personFlux, Person.class)
        .retrieve()
        .bodyToMono(Void.class);
```

有实际值的话，直接发送实际值

```java
Person person = ... ;

Mono<Void> result = client.post()
        .uri("/persons/{id}", id)
        .contentType(MediaType.APPLICATION_JSON)
        .bodyValue(person)
        .retrieve()
        .bodyToMono(Void.class);
```

## 4.2 form data

使用 MultiValueMap，content 默认被 FormHttpMessageWriter 设置为 application/x-www-form-urlencoded

```java
MultiValueMap<String, String> formData = ... ;

Mono<Void> result = client.post()
        .uri("/path", id)
        .bodyValue(formData)
        .retrieve()
        .bodyToMono(Void.class);
```

也可以使用内置的 BodyInserters

```java
import static org.springframework.web.reactive.function.BodyInserters.*;

Mono<Void> result = client.post()
        .uri("/path", id)
        .body(fromFormData("k1", "v1").with("k2", "v2"))
        .retrieve()
        .bodyToMono(Void.class);
```

## 4.3 Multipart Data

```java
MultipartBodyBuilder builder = new MultipartBodyBuilder();
builder.part("fieldPart", "fieldValue");
builder.part("filePart1", new FileSystemResource("...logo.png"));
builder.part("jsonPart", new Person("Jason"));
builder.part("myPart", part); // Part from a server request

Mono<Void> result = client.post()
        .uri("/path", id)
        .body(builder.build())
        .retrieve()
        .bodyToMono(Void.class);
```

或者使用内置的 BodyInserters

```java
import static org.springframework.web.reactive.function.BodyInserters.*;

Mono<Void> result = client.post()
        .uri("/path", id)
        .body(fromMultipartData("fieldPart", "value").with("filePart", resource))
        .retrieve()
        .bodyToMono(Void.class);
```

# 5. Filters

可以通过过滤器来拦截处理请求

```java
WebClient client = WebClient.builder()
        .filter((request, next) -> {

            ClientRequest filtered = ClientRequest.from(request)
                    .header("foo", "bar")
                    .build();

            return next.exchange(filtered);
        })
        .build();
```

# 6. Attributes

可以向请求添加属性，如果想通过过滤器影响指定请求，这种方式很方便

```java
WebClient client = WebClient.builder()
        .filter((request, next) -> {
            Optional<Object> usr = request.attribute("myAttribute");
            // ...
        })
        .build();

client.get().uri("https://example.org/")
        .attribute("myAttribute", "...")
        .retrieve()
        .bodyToMono(Void.class);

    }
```

# 7. Synchronous Use

可以进行堵塞，用同步的方式使用结果

```java
Person person = client.get().uri("/person/{id}", i).retrieve()
    .bodyToMono(Person.class)
    .block();

List<Person> persons = client.get().uri("/persons").retrieve()
    .bodyToFlux(Person.class)
    .collectList()
    .block();
```

如果调用多次请求，比起一个个堵塞，一起堵塞会更加有效(两个请求并发进行)

Mono.zip 可以合并多个值一起计算

```java
Mono<Person> personMono = client.get().uri("/person/{id}", personId)
        .retrieve().bodyToMono(Person.class);

Mono<List<Hobby>> hobbiesMono = client.get().uri("/person/{id}/hobbies", personId)
        .retrieve().bodyToFlux(Hobby.class).collectList();

Map<String, Object> data = Mono.zip(personMono, hobbiesMono, (person, hobbies) -> {
            Map<String, String> map = new LinkedHashMap<>();
            map.put("person", person);
            map.put("hobbies", hobbies);
            return map;
        })
        .block();
```

# 8. subscribe

> 非阻塞式获取响应结果

```java
@Test
public void testSubscribe() {
    Mono<String> mono = WebClient
            .create()
            .method(HttpMethod.GET)
            .uri("http://localhost:8080/hello")
            .retrieve()
            .bodyToMono(String.class);
    mono.subscribe(WebClientTest::handleMonoResp);
}
//响应回调
private static void handleMonoResp(String monoResp) {
    System.out.println("请求结果为：" + monoResp);
}
```

# 9. 占位符传参

**数字占位符**

```java
public static void main(String[] args) throws Exception {
    List<String> list = new ArrayList<>();
    list.add("a");
    list.add("b");
    String url = "http://localhost:8080/user/{1}/{2}";
    Mono<String> mono = WebClient.create()
            .method(HttpMethod.POST)
            .uri(url, list.toArray())
            .retrieve()
            .bodyToMono(String.class);
    String result = mono.block();
}
```

**参数名占位符**

```java
public static void main(String[] args) throws Exception {
    String url = "http://localhost:8080/user/{id}/{name}";
    String id = "123";
    String name = "Boss";
    Mono<String> mono = WebClient.create()
            .method(HttpMethod.POST)
            .uri(url, id, name)
            .retrieve()
            .bodyToMono(String.class);
    String result = mono.block();
}
```

**map 传参**

```java
public static void main(String[] args) throws Exception {
    String url = "http://localhost:8080/user/{id}/{name}";
    Map<String, String> params = new HashMap<>();
    params.put("id", "123");
    params.put("name", "Boss");
    Mono<String> mono = WebClient.create()
            .method(HttpMethod.POST)
            .uri(url, params)
            .retrieve()
            .bodyToMono(String.class);
    String result = mono.block();
}
```

# 10. Mono 和 Flux

mono 和 flux 类似于 Optional ， 是一个临时性的东西。

flux 类似于 list , 包含 0~n 个元素。

mono 只有 0~1 个元素。

