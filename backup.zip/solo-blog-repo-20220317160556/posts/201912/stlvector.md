title: stl-vector
date: '2019-12-03 19:33:30'
updated: '2019-12-03 19:37:52'
tags: [知识点总结, STL]
permalink: /articles/2019/12/03/1575372810901.html
---
# vector 的基本操作

vector 的长度根据需要自动改变。

vectore\<typename> name;定义 vector

vectore\<typename> name(n,x);可以将 vector 初始化为 n 个 x;

name.push_back();添加元素，时间复杂度 O（1）

name.pop_back();删除元素；O（1）

name.size();获得元素个数；O（1）

name.clear();清空 vector 中的所有元素；

name.insert(it,x);向迭代器 it 处插入一个元素 x；O（N）

neme.erase(it);删除迭代器为 it 的元素。O（N）

name.erase(it1,it2);删除两个迭代器内的元素。O（N）

注意：迭代器与指针不同，删除后此迭代器不在存在，一般无法对删除过得迭代器进行操作，可以这样 it=neme.erase(it);删除 it 迭代器并指向下一个迭代器；但是有的编译器会因为 vector 是线型容器自动指向下一元素；建议使用 it=neme.erase(it);操作；

name1.swap(name2);将 name1 和 name2 交换；

name1=name2；当 name1 和 name2 类型相同的话（例：都为 int）可以直接赋值；

name1assign(it1,it2);name 清空，然后将 it1 到 it2 迭代器中的元素拷贝给 name(遇上面直接复制的区别在与可以拷贝不同类型的 vector，列如把一个 char 拷贝给 int 类型，则相当于把 int 当做 ascii 码值赋给 char)

# vector 的排序

vector 可以用 sort 和 reverse 对迭代器进行排序和颠倒。

Vector 存结构体的时候可以用 sort 自写函数排序。

使用 sort 从大到小排序时可以直接调用函数 sort(it1,it2,greater<typename>() );排序

# vector 元素的访问：

通过下标访问：

name[index]，例如 name[0],name[0],但若是访问到不存在的元素会乱出结果。

name.at(i);与上面一样，但若是访问到不存在元素会报错。

通过迭代器访问：

定义迭代器：vectore\<typename>::iteratorit;

第一个元素的迭代器：it.begin();

最后一个元素后面一位的迭代器：it.end();

Vectore 的迭代器可以进行 it=it+i 的操作；

# 反转向迭代器的定义和运用

vector\<typename>::reverse_iteratorit;定义反向迭代器

name.rbegin();最后一个元素

name.rend();第一个元素前面的迭代器

可以用 name.rbegin();代替 name.end()-1;操作

具体应用如下：
```c++
#include<iostream>
#include<vector>
using namespace std;
int main()
{
	vector<int> s;
	vector<int>::reverse_iterator it1;
	vector<int>::iterator it;
	s.push_back(1);
	s.push_back(2);
	s.push_back(3);
	/*for(it=s.end()-1;it>=s.begin();it--)
	cout<<*it<<" ";
	cout<<endl;
	这种情况到达s.begin的时候it--在执行一次，程序有可能崩掉*/
	for(it1=s.rbegin();it1!=s.rend();it1++)
	cout<<*it1<<" ";
	cout<<endl;
	/*输出结果 3 2 1 */ 
}


```
