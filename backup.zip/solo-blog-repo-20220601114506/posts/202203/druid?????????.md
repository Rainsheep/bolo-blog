title: druid 丢弃连接的守护线程
date: '2022-03-04 15:41:08'
updated: '2022-03-04 15:41:08'
tags: [druid]
permalink: /articles/2022/03/04/1646379668477.html
---
```java
// 连接池瘦身，参考主流程4
public class DestroyConnectionThread extends Thread {

    public DestroyConnectionThread(String name) {
        // 给线程重命名
        super(name);
        // 标记为守护线程
        this.setDaemon(true);
    }

    // run 方法
    public void run() {
        // 通知 init（主流程2）自己已经启动成功
        initedLatch.countDown();

        // 死循环
        for (;;) {
            // 从前面开始删除
            try {
                if (closed || closing) {
                    break;
                }

                // 检查时间间隔，缺省值是 60s
                if (timeBetweenEvictionRunsMillis > 0) {
                    Thread.sleep(timeBetweenEvictionRunsMillis);
                } else {
                    // 小于 0 时则是 1s
                    Thread.sleep(1000); 
                }

                if (Thread.interrupted()) {
                    break;
                }

                // 启动 destroy 的 run 方法（在下方）
                destroyTask.run();
            } catch (InterruptedException e) {
                break;
            }
        }
    }

}

// DruidDataSource 内部类
public class DestroyTask implements Runnable {
    public DestroyTask() {

    }

    @Override
    public void run() {
        // 连接池的检查&瘦身
        shrink(true, keepAlive);

        // 如果开启该属性，则进行强制回收检查
        if (isRemoveAbandoned()) {
            removeAbandoned();
        }
    }

}
```

