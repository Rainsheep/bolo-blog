title: druid 责任链
date: '2022-03-04 14:57:51'
updated: '2022-03-04 14:57:51'
tags: [druid]
permalink: /articles/2022/03/04/1646377071540.html
---
```java
// DruidDataSource 类里的方法：获取连接
public DruidPooledConnection getConnection(long maxWaitMillis) throws SQLException {
    init();

    // 责任链上的 filter 存在
    if (filters.size() > 0) {
        // 该类是执行整个责任链的执行者
        FilterChainImpl filterChain = new FilterChainImpl(this);
        // 每个需要执行责任链的方法，在 filterChain 里都可以找到映射方法，比如本方法 getConnection，就对应 filterChain.dataSource_connect（参考流程1.1）
        return filterChain.dataSource_connect(this, maxWaitMillis);
    } else {
        return getConnectionDirect(maxWaitMillis);
    }
}

// FilterChainImpl 类里的方法：获取连接映射方法
@Override
public DruidPooledConnection dataSource_connect(DruidDataSource dataSource, long maxWaitMillis) throws SQLException {
    // 除了 FilterChainImpl 里面包含一些 datasource 的映射方法，需要执行的 filter 里面也包括，比如下面的 dataSource_getConnection 方法
    if (this.pos < filterSize) {
        DruidPooledConnection conn = nextFilter().dataSource_getConnection(this, dataSource, maxWaitMillis);
        return conn;
    }

    // 执行到最后一个 filter 时，触发 datasource，返回真正的连接
    return dataSource.getConnectionDirect(maxWaitMillis);
}

// FilterChainImpl 类里的方法：获取下一个需要执行的 filter
private Filter nextFilter() {
    return getFilters()
            .get(pos++); // 根据游标计算
}

// 随便找了一个 filter 里的目标方法
// LogFilter 类里的方法：dataSource_getConnection
@Override
public DruidPooledConnection dataSource_getConnection(FilterChain chain, DruidDataSource dataSource,
                                                      long maxWaitMillis) throws SQLException {
    // 这里又会利用 FilterChainImpl 触发映射方法
    DruidPooledConnection conn = chain.dataSource_connect(dataSource, maxWaitMillis);

    // 下面就是自己内部的一些特有逻辑，忽略
    ConnectionProxy connection = (ConnectionProxy) conn.getConnectionHolder().getConnection();

    if (connectionConnectAfterLogEnable && isConnectionLogEnabled()) {
        connectionLog("{conn-" + connection.getId() + "} pool-connect");
    }

    // 返回
    return conn;
}
```

