title: mybatis 缓存
date: '2022-02-28 16:43:21'
updated: '2022-02-28 16:43:21'
tags: [spring]
permalink: /articles/2022/02/28/1646037801701.html
---
参考文献：
[MyBatis|缓存机制](https://www.jianshu.com/p/b4522c9212fb)
[mybatis一级缓存二级缓存 ](https://www.cnblogs.com/happyflyingpig/p/7739749.html)
[【MyBatis学习13】MyBatis中的二级缓存](https://blog.csdn.net/eson_15/article/details/51669608)

# 1. mybatis 缓存

* 一级缓存：也称为本地缓存，用于保存用户在一次会话过程中查询的结果，用户一次会话中只能使用一个 sqlSession，一级缓存是自动开启的，不允许关闭。
* 二级缓存：也称为全局缓存，是 namespace 级别的缓存，是针对一个表的查结果的存储，可以共享给所有针对这张表的查询的用户。也就是说对于 namespace 级别的缓存不同的 sqlsession 是可以共享的。

对一级缓存和二级缓存的作用范围做一个介绍：

* 一级缓存的作用范围为 sqlSession，即为一次 commit, 其实作用不大，如果我们想看一级缓存的效果，可以通过事务管理来进行 commit 的控制。
* 二级缓存的作用范围为 namespace, namespace 在 xml 中配置，一般一个 mapper 对应一个 namespce
  
  ```java
  <mapper namespace="mapper.ComAdminMapper"></mapper>
  ```

缓存查询的时候，先查询二级缓存，再查询一级缓存，最后看数据库。

# 2. 二级缓存

**不同的 mapper 使用同一个 namespace，也是使用相同的缓存**

我们看个示意图

![20160614105455733](https://oss.rainsheep.cn/blog/20160614105455733-1646036686-b9c.png)

增删改都会清空二级缓存。

## 2.1 使用

springboot 中 mybatis 的二级缓存是默认开启的。

不过 mybatis 缓存是在本地的，分布式情况下，会出现脏数据的情况，两端数据不一致，我们可以通过整合 redis 来解决。

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-redis</artifactId>
</dependency>
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-cache</artifactId>
</dependency>
```

配置缓存管理器

```
spring.cache.type=redis
```

使用 spring cache 注解来管理缓存

