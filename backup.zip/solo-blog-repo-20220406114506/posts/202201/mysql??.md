title: mysql 索引
date: '2022-01-13 17:39:02'
updated: '2022-01-14 00:07:18'
tags: [mysql]
permalink: /articles/2022/01/13/1642066741987.html
---
参考文献：
[MySQL索引原理以及查询优化](https://www.cnblogs.com/bypp/p/7755307.html)
[mysql - 降序索引](https://www.modb.pro/db/96806)
[mysql覆盖索引与回表](https://www.jianshu.com/p/8991cbca3854)

# 1. 介绍

## 1.1 什么是索引？

一般的应用系统，读写比例在10:1左右，而且插入操作和一般的更新操作很少出现性能问题，在生产环境中，我们遇到最多的，也是最容易出问题的，还是一些复杂的查询操作，因此对查询语句的优化显然是重中之重。说起加速查询，就不得不提到索引了。

## 1.2 为什么要有索引呢？

* 索引在MySQL中也叫做“键”，是存储引擎用于快速找到记录的一种数据结构。
* 索引对于良好的性能非常关键，尤其是当表中的数据量越来越大时，索引对于性能的影响愈发重要。
* 索引优化应该是对查询性能优化最有效的手段了。
* 索引能够轻易将查询性能提高好几个数量级。
* 索引相当于字典的音序表，如果要查某个字，如果不使用音序表，则需要从几百页中逐页去查。

# 2. 索引的原理

## 2.1 索引原理

索引的目的在于提高查询效率，与我们查阅图书所用的目录是一个道理：先定位到章，然后定位到该章下的一个小节，然后找到页数。相似的例子还有：查字典，查火车车次，飞机航班等

**本质都是：通过不断地缩小想要获取数据的范围来筛选出最终想要的结果，同时把随机的事件变成顺序的事件，也就是说，有了这种索引机制，我们可以总是用同一种查找方式来锁定数据。**

数据库也是一样，但显然要复杂的多，因为不仅面临着等值查询，还有范围查询(>、<、between、in)、模糊查询(like)、并集查询(or)等等。数据库应该选择怎么样的方式来应对所有的问题呢？我们回想字典的例子，能不能把数据分成段，然后分段查询呢？最简单的如果1000条数据，1到100分成第一段，101到200分成第二段，201到300分成第三段......这样查第250条数据，只要找第三段就可以了，一下子去除了90%的无效数据。但如果是1千万的记录呢，分成几段比较好？稍有算法基础的同学会想到搜索树，其平均复杂度是lgN，具有不错的查询性能。但这里我们忽略了一个关键的问题，复杂度模型是基于每次相同的操作成本来考虑的。而数据库实现比较复杂，一方面数据是保存在磁盘上的，另外一方面为了提高性能，每次又可以把部分数据读入内存来计算，因为我们知道**访问磁盘的成本大概是访问内存的十万倍左右**，所以简单的搜索树难以满足复杂的应用场景。

## 2.2 磁盘 IO 与预读

考虑到磁盘 IO 是非常高昂的操作，计算机操作系统做了一些优化，**当一次 IO 时，不光把当前磁盘地址的数据，而是把相邻的数据也都读取到内存缓冲区内**，因为局部预读性原理告诉我们，当计算机访问一个地址的数据的时候，与其相邻的数据也会很快被访问到。每一次IO读取的数据我们称之为一页(page)。具体一页有多大数据跟操作系统有关，一般为4k或8k，也就是我们读取一页内的数据时候，实际上才发生了一次IO，这个理论对于索引的数据结构设计非常有帮助。

# 3. 索引的数据结构

任何一种数据结构都不是凭空产生的，一定会有它的背景和使用场景，我们现在总结一下，我们需要这种数据结构能够做些什么，其实很简单，那就是：每次查找数据时把磁盘IO次数控制在一个很小的数量级，最好是常数数量级。那么我们就想到如果一个高度可控的多路搜索树是否能满足需求呢？就这样，b+树应运而生。

![1184802-20170912211249219-1576835998](https://oss.rainsheep.cn/blog/1184802-20170912211249219-1576835998-1642049482-5c4-1642075886-fca-1642088459-58c.png)

如上图，是一颗b+树，关于b+树的定义可以参见[B+树](http://zh.wikipedia.org/wiki/B%2B树)，这里只说一些重点，浅蓝色的块我们称之为一个磁盘块，可以看到每个磁盘块包含几个数据项（深蓝色所示）和指针（黄色所示），如磁盘块1包含数据项17和35，包含指针P1、P2、P3，P1表示小于17的磁盘块，P2表示在17和35之间的磁盘块，P3表示大于35的磁盘块。真实的数据存在于叶子节点即3、5、9、10、13、15、28、29、36、60、75、79、90、99。非叶子节点只不存储真实的数据，只存储指引搜索方向的数据项，如17、35并不真实存在于数据表中。

## 3.1 b+ 树的查找过程

如图所示，如果要查找数据项29，那么首先会把磁盘块1由磁盘加载到内存，此时发生一次IO，在内存中用二分查找确定29在17和35之间，锁定磁盘块1的P2指针，内存时间因为非常短（相比磁盘的IO）可以忽略不计，通过磁盘块1的P2指针的磁盘地址把磁盘块3由磁盘加载到内存，发生第二次IO，29在26和30之间，锁定磁盘块3的P2指针，通过指针加载磁盘块8到内存，发生第三次IO，同时内存中做二分查找找到29，结束查询，总计三次IO。真实的情况是，3层的b+树可以表示上百万的数据，如果上百万的数据查找只需要三次IO，性能提高将是巨大的，如果没有索引，每个数据项都要发生一次IO，那么总共需要百万次的IO，显然成本非常非常高。

## 3.2 b+ 树的性质

1**.索引字段要尽量的小**：

通过上面的分析，我们知道 IO 次数取决于 b+ 数的高度 h，假设当前数据表的数据为 N，每个磁盘块的数据项的数量是 m，则有 h=㏒(m+1)N，当数据量 N 一定的情况下，m 越大，h 越小；

而 (m = 磁盘块的大小 / 数据项的大小)，磁盘块的大小也就是一个数据页的大小，是固定的，如果数据项占的空间越小，数据项的数量越多，树的高度越低。这就是为什么每个数据项，即索引字段要尽量的小，比如int占4字节，要比bigint8字节少一半。这也是为什么b+树要求把真实的数据放到叶子节点而不是内层节点，一旦放到内层节点，磁盘块的数据项会大幅度下降，导致树增高。当数据项等于1时将会退化成线性表。

2.**索引的最左匹配特性（即从左往右匹配）**:

当 b+ 树的数据项是复合的数据结构，比如 (name,age,sex) 的时候，b+ 树是按照从左到右的顺序来建立搜索树的，比如当 (张三,20,F) 这样的数据来检索的时候， b+ 树会优先比较 name 来确定下一步的所搜方向，如果 name 相同再依次比较 age 和 sex，最后得到检索的数据；但当 (20,F) 这样的没有 name 的数据来的时候，b+ 树就不知道下一步该查哪个节点，因为建立搜索树的时候 name 就是第一个比较因子，必须要先根据 name 来搜索才能知道下一步去哪里查询。比如当 (张三,F) 这样的数据来检索时，b+ 树可以用 name 来指定搜索方向，但下一个字段 age 的缺失，所以只能把名字等于张三的数据都找到，然后再匹配性别是 F 的数据了， 这个是非常重要的性质，即索引的最左匹配特性。

# 4. mysql 索引管理

## 4.1 功能

1. 索引的功能就是加速查找
2. mysql 中的 primary key、unique、联合、唯一也都是索引，这些索引除了加速查找以外，还有约束的功能

## 4.2 mysql 索引分类

1. 普通索引index :加速查找
2. 唯一索引
   主键索引：primary key ：加速查找+约束（不为空且唯一）
   唯一索引：unique：加速查找+约束 （唯一）
3. 联合索引
   * primary key(id,name): 联合主键索引
   * unique(id,name): 联合唯一索引
   * index(id,name): 联合普通索引
4. 全文索引 fulltext :用于搜索很长一篇文章的时候，效果最好。
5. 空间索引 spatial :了解就好，几乎不用

**应用场景**

举个例子来说，比如你在为某商场做一个会员卡的系统。
这个系统有一个会员表
有下列字段：

* 会员编号 INT
* 会员姓名 VARCHAR(10)
* 会员身份证号码 VARCHAR(18)
* 会员电话 VARCHAR(10)
* 会员住址 VARCHAR(50)
* 会员备注信息 TEXT

那么这个 会员编号，作为主键，使用 PRIMARY
会员姓名， 如果要建索引的话，那么就是普通的 INDEX
会员身份证号码， 如果要建索引的话，那么可以选择 UNIQUE （唯一的，不允许重复）

除此之外还有全文索引，即 FULLTEXT
会员备注信息 ， 如果需要建索引的话，可以选择全文搜索。
用于搜索很长一篇文章的时候，效果最好。

用在比较短的文本，如果就一两行字的，普通的 INDEX 也可以。
但其实对于全文搜索，我们并不会使用 MySQL 自带的该索引，而是会选择第三方软件如 Sphinx，专门来做全文搜索。

其他的如空间索引SPATIAL，了解即可，几乎不用

## 4.3 索引的两大类型

hash 和 btree

我们可以在创建上述索引的时候，为其指定索引类型，分两类

* hash类型的索引：查询单条快，范围查询慢
* btree类型的索引：b+树，层数越多，数据量指数级增长（我们就用它，因为innodb默认支持它）

不同的存储引擎支持的索引类型也不一样

* InnoDB 支持事务，支持行级别锁定，支持 B-tree、Full-text 等索引，不支持 Hash 索引；
* MyISAM 不支持事务，支持表级别锁定，支持 B-tree、Full-text 等索引，不支持 Hash 索引；
* Memory 不支持事务，支持表级别锁定，支持 B-tree、Hash 等索引，不支持 Full-text 索引；
* NDB 支持事务，支持行级别锁定，支持 Hash 索引，不支持 B-tree、Full-text 等索引；
* Archive 不支持事务，支持表级别锁定，不支持 B-tree、Hash、Full-text 等索引；

## 4.4 创建/删除索引的语法

**创建表时**

```sql
CREATE TABLE 表名 (
    字段名1  数据类型 [完整性约束条件…],
    字段名2  数据类型 [完整性约束条件…],
    [UNIQUE | FULLTEXT | SPATIAL ]   INDEX | KEY [索引名]  (字段名[(长度)]  [ASC |DESC]) 
);
```

**在已存在的表上创建索引**

```sql
CREATE  [UNIQUE | FULLTEXT | SPATIAL ]  INDEX  索引名  ON 表名 (字段名[(长度)]  [ASC |DESC]) ;
ALTER TABLE 表名 ADD [UNIQUE | FULLTEXT | SPATIAL ] INDEX  [索引名]  (字段名[(长度)]  [ASC |DESC])
```

**删除索引**

```sql
DROP INDEX 索引名 ON 表名字;
```

# 5. 测试索引

## 5.1 准备表

```sql
CREATE TABLE `tb_user_disorder` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(5) NOT NULL,
  `sex` tinyint(1) NOT NULL,
  `email` varchar(128) NOT NULL,
  `time` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1000002 DEFAULT CHARSET=utf8mb4;
```

准备了五百多万条数据。

## 5.2 测试

**在没有索引的情况下测试查询速度**

```sql
SELECT * FROM tb_user WHERE email='tcf8ssbbyu@hotmail.com'
```

查询时间 1.307 s

**加上索引**

查询时间 0.001 s

# 6. 正确使用索引

## 6.1 回表查询

### 6.1.1 介绍

这先要从 InnoDB 的索引实现说起，InnoDB 有两大类索引：

- 聚集索引 (clustered index)
- 普通索引 (secondary index)

**InnoDB 聚集索引和普通索引有什么差异？**

InnoDB **聚集索引**的叶子节点存储行记录，因此， InnoDB 必须要有，且只有一个聚集索引：

1. 如果表定义了 PK，则 PK 就是聚集索引；
2. 如果表没有定义 PK，则第一个 not NULL unique 列是聚集索引；
3. 否则，InnoDB 会创建一个隐藏的 row-id 作为聚集索引；

> 画外音：所以 PK 查询非常快，直接定位行记录。

InnoDB **普通索引**的叶子节点存储主键值。

> 画外音：注意，不是存储行记录头指针，MyISAM 的索引叶子节点存储记录指针。

### 6.1.2 例子

举个栗子，不妨设有表：

t(id PK, name KEY, sex, flag);

> 画外音：id 是聚集索引，name 是普通索引。

表中有四条记录：

```
1, shenjian, m, A
3, zhangsan, m, A
5, lisi, m, A
9, wangwu, f, B
```

![4459024-8636fab05de6780b](https://oss.rainsheep.cn/blog/4459024-8636fab05de6780b-1642088950-db8.webp)

两个B+树索引分别如上图：

* id 为 PK，聚集索引，叶子节点存储行记录；
* name 为 KEY，普通索引，叶子节点存储 PK 值，即 id；

既然从普通索引无法直接定位行记录，那**普通索引的查询过程是怎么样的呢？**

通常情况下，需要扫码两遍索引树。

例如：

```
select * from t where name='lisi';
```

**是如何执行的呢？**

![4459024-a75e767d0198a6a4](https://oss.rainsheep.cn/blog/4459024-a75e767d0198a6a4-1642089003-4f7.webp)

如**粉红色**路径，需要扫码两遍索引树：

1. 先通过普通索引定位到主键值 id=5；
2. 在通过聚集索引定位到行记录；

这就是所谓的**回表查询**，先定位主键值，再定位行记录，它的性能较扫一遍索引树更低。

## 6.2 覆盖索引

**什么是索引覆盖?**

MySQL 官网，类似的说法出现在 explain 查询计划优化章节，即 explain 的输出结果 Extra 字段为 Using index 时，能够触发索引覆盖。

表达了：只需要在一棵索引树上就能获取 SQL 所需的所有列数据，无需回表，速度更快。

**如何实现索引覆盖？**

常见的方法是：将被查询的字段，建立到联合索引里去。

```
create table user (
	id int primary key,
	name varchar(20),
	sex varchar(5),
	index(name)
)engine=innodb;
```

第一个SQL语句：

![4459024-9e1c684ef3808d5f](https://oss.rainsheep.cn/blog/4459024-9e1c684ef3808d5f-1642089244-c00.webp)

```sql
select id,name from user where name='shenjian';
```

能够命中 name 索引，索引叶子节点存储了主键 id，通过 name 的索引树即可获取 id 和 name，无需回表，符合索引覆盖，效率较高。

> 画外音，Extra：**Using index**。

第二个SQL语句：

![4459024-8dcf28741073e0d0](https://oss.rainsheep.cn/blog/4459024-8dcf28741073e0d0-1642089319-e80.webp)

```sql
select id,name,sex from user where name='shenjian';
```

能够命中 name 索引，索引叶子节点存储了主键 id，但 sex 字段必须回表查询才能获取到，不符合索引覆盖，需要再次通过 id 值扫码聚集索引获取 sex 字段，效率会降低。

> 画外音，Extra：**Using index condition**。

如果把(name)单列索引升级为联合索引(name, sex)就不同了。

![4459024-55b74f7a1cdd1249](https://oss.rainsheep.cn/blog/4459024-55b74f7a1cdd1249-1642089402-aef.webp)

可以看到：

```sql
select id,name where name='shenjian';

select id,name,sex where name='shenjian';
```

都能够命中索引覆盖，无需回表。

> 画外音，Extra：**Using index**。

## 6.3 联合索引

**普通联合索引包含主键索引没有意义**

* 普通索引 b+ 树叶子节点存储的 value 就是主键索引
* 因为联合索引是为了快速确定一条数据，主键索引已经可以确定，主键索引和普通联合索引(包含主键)都存在的时候，只会走主键索引

**没有索引**

```sql
SELECT SQL_NO_CACHE * FROM tb_user WHERE name='谭梳卷' and email='tcf8ssbbyu@hotmail.com'
```

查询时间：1.347 s

**有索引**

```sql
CREATE index idx on tb_user(name,email);
SELECT SQL_NO_CACHE * FROM tb_user WHERE name='谭梳卷' and email='tcf8ssbbyu@hotmail.com';
SELECT SQL_NO_CACHE * FROM tb_user WHERE email='tcf8ssbbyu@hotmail.com' and name='谭梳卷';
```

查询时间 0.000s

## 6.4 索引合并

索引合并：把多个单列索引合并使用

组合索引能做到的事情，我们都可以用索引合并去解决，比如

```sql
create index idx on tb_user(name,email); #组合索引
```

我们完全可以单独为 name 和 email 创建索引

组合索引可以命中

```sql
select * from tb_user where name='egon' ;
select * from tb_user where name='egon' and email='adf';  # 无论 and 顺序，mysql 会为我们自动排序
```

索引合并可以命中：

```sql
select * from s1 where name='egon' ;
select * from s1 where email='adf';
select * from s1 where name='egon' and email='adf';
```

乍一看好像索引合并更好了：可以命中更多的情况，但其实要分情况去看，如果是 `name='egon' and email='adf'`,
那么组合索引的效率要高于索引合并，如果是单条件查，那么还是用索引合并比较合理。

* 组合索引所用时间：0.000 s
* 索引合并所用时间：0.001 s

# 7. 最左前缀

## 7.1 介绍

**最左前缀匹配原则，非常重要的原则**

```sql
CREATE index idx on tb_user(name,email);
```

最左前缀匹配：必须按照从左到右的顺序匹配

```sql
select * from s1 where name='egon'; #可以
select * from s1 where name='egon' and email='asdf'; #可以
select * from s1 where email='asdf' and name='egon'; #可以
select * from s1 where email='alex@oldboy.com'; #不可以
```

mysql 会一直向右匹配直到遇到范围查询(>、<、between、like)就停止匹配。

比如 `a = 1 and b = 2 and c > 3 and d = 4`  如果建立 (a,b,c,d) 顺序的索引，d 是用不到索引的，如果建立 (a,b,d,c) 的索引则都可以用到，a,b,d 的顺序可以任意调整。

**=和in可以乱序**

比如`a = 1 and b = 2 and c = 3` 建立 (a,b,c) 索引可以任意顺序，mysql 的查询优化器会帮你优化成索引可以识别的形式

**尽量选择区分度高的列作为索引**

区分度的公式是 `count(distinct col)/count(*)`，
表示字段不重复的比例，比例越大我们扫描的记录数越少，唯一键的区分度是1，而一些状态、性别字段可能在大数据面前区分度就是0，那可能有人会问，这个比例有什么经验值吗？

使用场景不同，这个值也很难确定，一般需要 join 的字段我们都要求是 0.1 以上，即平均 1 条扫描 10 条记录。

**索引列不能参与计算**

保持列“干净”，比如

```sql
SELECT * FROM tb_user WHERE FROM_UNIXTIME(time)='2014-05-29'
```

就不能使用到索引，原因很简单，b+ 树中存的都是数据表中的字段值，但进行检索时，需要把所有元素都应用函数才能比较，显然成本太大。

所以语句应该写成

```sql
SELECT * FROM tb_user WHERE time=unix_timestamp(’2014-05-29’);
```

## 7.2 最左前缀示范

**对比**

未遵循最左前缀

```sql
select * from s1 where id>3 and name='egon' and email='alex333@oldboy.com' and gender='male';
Empty set (0.39 sec)

create index idx on s1(id,name,email,gender); #未遵循最左前缀
Query OK, 0 rows affected (15.27 sec)
Records: 0  Duplicates: 0  Warnings: 0

select * from s1 where id>3 and name='egon' and email='alex333@oldboy.com' and gender='male';
Empty set (0.43 sec)
```

遵循最左前缀

```sql
select * from s1 where id>3 and name='egon' and email='alex333@oldboy.com' and gender='male';
Empty set (0.39 sec)

create index idx on s1(name,email,gender,id); #遵循最左前缀
Query OK, 0 rows affected (15.97 sec)
Records: 0  Duplicates: 0  Warnings: 0

select * from s1 where id>3 and name='egon' and email='alex333@oldboy.com' and gender='male';
Empty set (0.03 sec)
```

**命中索引**

```sql
最左前缀匹配
index(id,age,email,name)   # 注意索引的顺序

#条件中一定要出现id (只要出现 id 就会提升速度)
id  		# 很快 (只查一行)
id age 		# 很快 (只查一行)
id email	# 较快，id 会使用索引筛选出一部分，然后遍历，寻找 email 对应的
id name		# 较快，id 会使用索引筛选出一部分，然后遍历，寻找 name 对应的
email 		#不行  如果单独这个开头就不能提升速度了

select count(*) from s1 where id=3000;
1 row in set (0.11 sec)
 
create index xxx on s1(id,name,age,email);
select count(*) from s1 where id=3000;
1 row in set (0.00 sec)
 

select count(*) from s1 where name='egon';
1 row in set (0.16 sec)
 
select count(*) from s1 where email='egon3333@oldboy.com';
1 row in set (0.15 sec)

select count(*) from s1 where id=1000 and age=18;
1 row in set (0.00 sec)


select count(*) from s1 where id=1000 and email='egon3333@oldboy.com';
1 row in set (0.01 sec)

select count(*) from s1 where email='egon3333@oldboy.com' and id=3000;
1 row in set (0.01 sec)
```

**不能使用索引的情况**

```sql
- like '%xx'
    select * from tb1 where email like '%cn';
    
    
- 使用函数
    select * from tb1 where reverse(email) = 'wupeiqi';

    
- or
    select * from tb1 where nid = 1 or name = 'seven@live.com';
    
    特别的：当or条件中有未建立索引的列才失效，以下会走索引
            primary key(nid)
            index(name,eamil)
            select * from tb1 where nid = 1 or name = 'seven';
            select * from tb1 where nid = 1 or name = 'seven@live.com' and email = 'alex'
            
            
- 类型不一致
    如果列是字符串类型，传入条件是必须用引号引起来，不然...
    select * from tb1 where email = 999;
    

- != 普通索引的不等于不会走索引
    select * from tb1 where email != 'alex'
    
    特别的：如果是主键，则还是会走索引
        select * from tb1 where nid != 123

- >
    select * from tb1 where email > 'alex'
    
    特别的：如果是主键或索引是整数类型，则还是会走索引
        select * from tb1 where nid > 123
        select * from tb1 where num > 123
        
# 排序条件为索引，则select字段必须也是索引字段，否则无法命中
- order by
    index(email)
    当根据索引排序时候，select查询的字段如果不是索引，则不走索引
    select name from s1 order by email desc;
    走索引
    select email from s1 order by email desc;
    特别的：如果对主键排序，则还是走索引：
        select * from tb1 order by nid desc;
 
- 组合索引最左前缀
    如果组合索引为：(name,email)
    name and email       -- 使用索引
    name                 -- 使用索引
    email                -- 不使用索引


- count(1)或count(列)代替count(*)在mysql中没有差别了

- create index xxxx  on tb(title(19)) #text类型，必须制定长度
```

- 避免使用select *
- count(1)或count(列) 代替 count(*)
- 创建表时尽量用 char 代替 varchar
- 表的字段顺序固定长度的字段优先(char 的效率大于 varchar)
- 组合索引代替多个单列索引（经常使用多个条件查询时）
- 尽量使用短索引
- 使用连接（JOIN）来代替子查询(Sub-Queries)
- 连表时注意条件类型需一致

# 8. 查询优化

* 先运行看看是否真的很慢，注意设置SQL_NO_CACHE
* where条件单表查，锁定最小返回记录表。这句话的意思是把查询语句的where都应用到表中返回的记录数最小的表开始查起，单表每个字段分别查询，看哪个字段的区分度最高
* explain查看执行计划，是否与1预期一致（从锁定记录较少的表开始查询）
* order by limit 形式的sql语句让排序的表优先查

# 9. 倒序索引

mysql8.0 新增了降序索引，从语法上来说，早在 mysql5 版本的初期，已经支持 index idx_c1_c2(c1,c2 desc) 的语法，但实际上它的降序排序是不生效的。

## 9.1 降序索引的作用

如有有个查询，需要对多个列进行排序，而且排序条件不一致，这种情况下，数据库会进行 filesort 排序。这时候就可以使用降序索引进行优化了。

**mysql 5.7**

查询语句：`select * from index_sort_test order by c1,c2 desc;`

explain 以下该语句，果然用到了filesort

**mysql 8.0**

explain 并未使用 filesort，在数据量很大的情况下，减少排序操作会极大加速sql的执行速度

## 9.2 降序索引是否能应用于单列排序的场景？

**mysql 5.7**

```sql
select * from index_sort_test order by c1;

select * from index_sort_test order by c1 desc; #c1进行倒序排序
```

![modb_20210806_bd648c04-f68c-11eb-ab80-00163e068ecd](https://oss.rainsheep.cn/blog/modb_20210806_bd648c04-f68c-11eb-ab80-00163e068ecd-1642066233-de8-1642075886-5da-1642088459-0cd.png)

两条sql执行计划一致。c1 是建表默认的升序索引，对单列排序（无论升序或降序），都不需要进行额外排序。

实际上，对于索引，mysql 不仅支持正向扫描，还可以反向扫描。而且反向扫描的性能同样不差，下面贴个 mysql 官方的压测结果：

有两列(a，b)，一个联合索引(a desc,b asc)

![modb_20210806_bdc4a5a8-f68c-11eb-ab80-00163e068ecd](https://oss.rainsheep.cn/blog/modb_20210806_bdc4a5a8-f68c-11eb-ab80-00163e068ecd-1642066373-219-1642075886-a91-1642088459-c3a.jpg)

**mysql 8.0**

再来看下8.0里有什么不一样的地方![modb_20210806_be0aa2d8-f68c-11eb-ab80-00163e068ecd](https://oss.rainsheep.cn/blog/modb_20210806_be0aa2d8-f68c-11eb-ab80-00163e068ecd-1642066469-87f-1642075886-d7a-1642088459-4c6.png)

在降序排序的场景下，extra中多了个  Backward index scan
状态，这只是用来提醒你，mysql对该索引进行了反向扫描。

## 9.3 group by 排序

mysql 5.7 中，group by 会隐形排序(filesort)，mysql 8.0 不会。

