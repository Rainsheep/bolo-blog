title: mac 安装 brew
date: '2020-09-14 22:39:21'
updated: '2021-07-15 02:24:37'
tags: [mac]
permalink: /articles/2020/09/14/1600094361638.html
---
参考文档：

[github](https://github.com/Homebrew/brew)
[官方教程](https://brew.sh/)

> 诸多波折，读脚本代码解决了，安装时换成腾讯镜像，遇到什么问题通过阅读脚本代码解决

* mac 安装 brew 速度很慢，下面手动安装
* 复制 [https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh](https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh) 内容，保存为 install.sh
* 设置 git 镜像(腾讯的，临时的，终端关闭后失效)

  ```bash
  export HOMEBREW_BREW_GIT_REMOTE="https://mirrors.cloud.tencent.com/homebrew/brew.git"
  export HOMEBREW_CORE_GIT_REMOTE="https://mirrors.cloud.tencent.com/homebrew/homebrew-core.git"
  ```
* 运行 install.sh 脚本
* 安装完成以后

  ```bash
  brew -v
  Homebrew 3.2.2
  Homebrew/homebrew-core (git revision 55f0a24d348; last commit 2021-07-14)
  ```

  > 安装成功
  >
* 换源参考 [brew 换源](https://www.rainsheep.cn/articles/2020/10/29/1603984969117.html)
* 卸载

  ```
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/uninstall.sh)"
  ```

遇到的问题汇总：

**问题一**

报错：curl: (7) Failed to connect to raw.githubusercontent.com port 443: Connection refused，可以通过这个命令解决：`sudo gem install redis`

**问题二**

一直 git fetch 失败，换成腾讯镜像后解决。

**问题三**

安装完以后，出现下面情况

```
brew -v
Homebrew 3.2.2
Homebrew/homebrew-core (no Git repository)
```

可见，homebrew 安装成功，但是 core 安装失败。

研究代码发下，需要删除 `/usr/local/Homebrew/Library/Taps/homebrew/homebrew-core` 文件夹，重新安装 homebrew-core
