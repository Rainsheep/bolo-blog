title: druid
date: '2022-03-02 19:31:23'
updated: '2022-03-02 19:31:23'
tags: [sql]
permalink: /articles/2022/03/02/1646220683047.html
---
参考文献：
[druid 常见问题](https://github.com/alibaba/druid/wiki/%E5%B8%B8%E8%A7%81%E9%97%AE%E9%A2%98)
[池化技术（一）Druid是如何管理数据库连接的？ ](https://www.cnblogs.com/hama1993/p/11421576.html)
[Druid Spring Boot Starter](https://github.com/alibaba/druid/tree/master/druid-spring-boot-starter)

# 1. 使用方式

## 1.1 maven 仓库

```xml
<!-- spring -->
<dependency>
    <groupId>com.alibaba</groupId>
    <artifactId>druid</artifactId>
    <version>${druid-version}</version>
</dependency>

<!-- springboot -->
<dependency>
    <groupId>com.alibaba</groupId>
    <artifactId>druid-spring-boot-starter</artifactId>
    <version>${druid-version}</version>
</dependency>
```

## 1.2 配置文件

参考文献：
[DruidDataSource配置](https://github.com/alibaba/druid/wiki/DruidDataSource%E9%85%8D%E7%BD%AE)
[DRUID连接池的实用 配置详解 ](https://www.cnblogs.com/wuyun-blog/p/5679073.html)

```yml
spring:
  datasource:
    druid:
      # 基本属性 url、user、password
      url: @mysqlUrl@
      driver-class-name: com.mysql.cj.jdbc.Driver
      username: @mysqlUsername@
      password: @mysqlPassword@
      # 配置初始化大小、最小、最大
      initial-size: 10
      min-idle: 10
      max-active: 20
      # 配置获取连接等待超时的时间
      max-wait: 6000
      max-wait-thread-count: -1
      # 配置一个连接在池中最小和最大生存的时间，单位是毫秒
      min-evictable-idle-time-millis: 300000
      max-evictable-idle-time-millis: 900000
      # 配置间隔多久才进行一次检测，检测需要关闭的空闲连接，单位是毫秒
      time-between-eviction-runs-millis: 60000
      # 什么时候进行链接有效性检测
      validation-query: SELECT 1
      test-while-idle: true
      test-on-borrow: false
      test-on-return: false
      # 是否缓存 preparedStatement，也就是 PSCache。PSCache对支持游标的数据库性能提升巨大，比如说 oracle。在 mysql下建议关闭
      pool-prepared-statements: true
      max-open-prepared-statements: 20
      # 保持链接在 minIdle 左右
      keep-alive: true
      # 针对分布式数据库优化，每个链接的最大使用次数
      phy-max-use-count: 500
      # 如果有 initialSize 数量较多时，打开会加快应用启动时间
      async-init: true
      # 配置监控统计拦截的filters
      filters: stat
```

* 基本属性 url , username, password，数据库基本配置，不再累述。
  * druid 可以根据 url 自动识别 driver-class-name，可以不配置
* initial-size：初始化时建立物理连接的个数。
  * 缺省值 0
  * 初始化发生在显示调用 init 方法，或者第一次 getConnection 时。
  * 当我们程序启动，并没有显示调用 init 的时候，并不会初始化连接池，在一次 getConnection 才会初始化，可能会造成第一次请求过慢。
* min-idle：连接池中最小空闲连接数量。实际可能会小于此值。
  * 缺省值 0
* max-active：连接池最大连接数量
  * 缺省值 8
  * 需要连接数超过最大连接数量的时候，不会再创建新的，会进入等待状态，等待旧的连接释放
* max-wait：从连接池获取连接时最大等待时间，单位毫秒。
  * 缺省值 -1
  * 配置了maxWait 之后，缺省启用公平锁，并发效率会有所下降，如果需要可以通过配置 useUnfairLock 属性为 true 使用非公平锁。
  * 去线程池获取连接是，若超过 max-wait，则抛出异常。
* min-evictable-idle-time-millis：连接池中连接最小生存时间。
  * 缺省值 1000L * 60L * 30L，30 分钟
  * 空闲时间还没有超最小生存时间 minEvictableldleTimeMillis 时，是不会回收的。
  * 空闲时间超过最小生存时间是并不会全部回收，只会回收 poolingCount(连接池中数量) - minldle，minldle 数量暂时不会回收。
* max-evictable-idle-time-millis：连接池中连接最大生存时间。
  * 缺省值 1000L * 60L * 60L * 7 ， 7 小时
  * 当空闲大于最大生存时间时 maxEvictableldleTimeMillis 时，由客户端口全部回收
* validation-query：检测连接有效性是执行的语句，一般配置为 select 1
  * mysql 默认情况下，发现一个连接空闲 8h, 则会主动断开连接，此语句的作用就是检验连接是否可用
* time-between-eviction-runs-millis： 配置间隔多久才进行一次检测，检测需要关闭的空闲连接
  * 缺省值 6000
  * mysql 默认情况下，发现一个连接空闲 8h, 则会主动断开连接，此项配置隔多久检查一次。
  * 若配置不当，会取出一个无效连接。
* test-while-idle：
  * 缺省值 true
  * 建议配置为true，不影响性能，并且保证安全性。
  * 申请连接的时候检测，如果空闲时间大于 timeBetweenEvictionRunsMillis，执行 validationQuery 检测连接是否有效。
* test-on-borrow
  * 缺省值 false
  * 申请连接时执行 validationQuery 检测连接是否有效，做了这个配置会降低性能。
* test-on-return
  * 缺省值 false
  * 归还连接时执行validationQuery检测连接是否有效，做了这个配置会降低性能
* pool-prepared-statements：
  * 缺省值 false
  * 是否缓存 preparedStatement，也就是PSCache。PSCache对支持游标的数据库性能提升巨大。
  * oracle 建议开启。在 mysql 下建议关闭。
* max-open-prepared-statements：
  * 缺省值 -1
  * 要启用PSCache，必须配置大于0，当大于0时，poolPreparedStatements 自动触发修改为 true。
  * 在Druid中，不会存在 Oracle 下 PSCache 占用内存过多的问题，可以把这个数值配置大一些，比如说 100
* keep-alive：
  * 缺省值 false
  * 开启后，初始化连接池时会填充到 minIdle 数量。
  * 开启后，连接池中的 minIdle 数量以内的连接，空闲时间超过 minEvictableIdleTimeMillis，则会执行 keepAlive 操作。
  * 开启后，当网络断开等原因产生的由 ExceptionSorter 检测出来的死连接被清除后，自动补充连接到 minIdle 数量。
  * 简单来说，开启后，通过超时重新创建连接的手段，可以把连接数量，维持在 min-idle 左右(即使空闲时间超过 max-evictable-idle-time-millis)，防止并发上升时创建连接花费太长时间。
* phy-max-use-count：
  * 缺省值 -1
  * 针对分布式数据库优化，每个链接的最大使用次数，若达到使用次数，则回收，创建新的，达到每个数据库负载均衡的目的。
* filters：在下文介绍
* async-init：是 1.1.4 中新增加的配置，如果有 initialSize 数量较多时，打开会加快应用启动时间。
  * 缺省值 false
  * 初始化时，线程池异步新增，加快 initial-size 速度。
  * 不开启的话使用默认方式：开启不同的守护线程通过 await、signal 通信实现线程池新增。
* max-wait-thread-count
  * 缺省值 -1,不启用
  * 如果 maxWaitThreadCount 配置大于0，表示启用，这是 druid 做的一种丢弃措施，如果你不希望在池子里的连接完全不够用导阻塞的业务线程过多，就可以考虑配置该项，这个属性的意思是说在连接不够用时最多让多少个业务线程发生阻塞，一旦超过甚至不触发 pollLast 的调用(防止新增等待线程)，直接抛错。

# 2. filters

参考：[Druid Spring Boot Starter](https://github.com/alibaba/druid/tree/master/druid-spring-boot-starter)

## 2.1 使用 druid 内置监控页面

参考：[配置_StatViewServlet配置](https://github.com/alibaba/druid/wiki/%E9%85%8D%E7%BD%AE_StatViewServlet%E9%85%8D%E7%BD%AE)

```properties
# StatViewServlet配置

#是否启用StatViewServlet（监控页面）默认值为false（考虑到安全问题默认并未启动，如需启用建议设置密码或白名单以保障安全）
spring.datasource.druid.stat-view-servlet.enabled=true 
spring.datasource.druid.stat-view-servlet.url-pattern=/druid/*

# 配置界面的访问账号和密码
spring.datasource.druid.stat-view-servlet.login-username=admin
spring.datasource.druid.stat-view-servlet.login-password=admin

# 在 StatViewSerlvet 输出的 html 页面中，有一个功能是 Reset All，执行这个操作之后，会导致所有计数器清零，重新计数。你可以通过配置参数关闭它。
spring.datasource.druid.stat-view-servlet.reset-enable=true

# 访问控制
spring.datasource.druid.stat-view-servlet.allow=128.242.127.1/24,128.242.128.1
spring.datasource.druid.stat-view-servlet.deny=128.242.127.4
```

* deny 优先于 allow，如果在 deny 列表中，就算在 allow 列表中，也会被拒绝。
* 如果 allow 没有配置或者为空，则允许所有访问
* 配置完成后可通过 `/druid/index.html` 看到界面，此时并没有 sql 监控信息

## 2.2 stat 监控统计

参考：[配置_StatFilter](https://github.com/alibaba/druid/wiki/%E9%85%8D%E7%BD%AE_StatFilter)

### 2.2.1 开启监控

Druid 的监控统计功能是通过 filter-chain 扩展实现，如果要打开监控统计功能，配置 StatFilter。

```properties
spring.datasource.druid.filters=stat
```

配置完成后即可查看到 sql 监控项

![image-20220302174733763](https://oss.rainsheep.cn/blog/image-20220302174733763-1646214453-1cb.png)

### 2.2.2 sql 合并配置

当你程序中存在没有参数化的sql执行时，sql统计的效果会不好。比如：

```sql
select * from t where id = 1
select * from t where id = 2
select * from t where id = 3
```

在统计中，显示为3条sql，这不是我们希望要的效果。StatFilter提供合并的功能，能够将这3个SQL合并为如下的SQL

```sql
select * from t where id = ?
```

做如下配置即可

```properties
spring.datasource.druid.filters=stat,mergeStat
```

### 2.2.3 慢 sql 记录

```properties
# 慢 sql 时间，缺省值 为 3000
spring.datasource.druid.filter.stat.slow-sql-millis=5000
# 是否记录 log
spring.datasource.druid.filter.stat.log-slow-sql=true
```

## 2.3 web 关联监控配置

参考：[配置_配置WebStatFilter](https://github.com/alibaba/druid/wiki/%E9%85%8D%E7%BD%AE_%E9%85%8D%E7%BD%AEWebStatFilter)

```properties
# WebStatFilter配置，说明请参考Druid Wiki，配置_配置WebStatFilter
# 是否启用StatFilter默认值false
spring.datasource.druid.web-stat-filter.enabled=true
spring.datasource.druid.web-stat-filter.url-pattern=/*
spring.datasource.druid.web-stat-filter.exclusions=*.js,*.gif,*.jpg,*.png,*.css,*.ico,/druid/*

# session 监控相关
spring.datasource.druid.web-stat-filter.session-stat-enable=true
spring.datasource.druid.web-stat-filter.session-stat-max-count=1000  # 缺省 1000
# 配置 principalSessionName，使得 druid 能够知道当前的 session 的用户是谁。
spring.datasource.druid.web-stat-filter.principal-session-name=sessionName
# 如果 user 信息保存在 cookie 中，你可以配置 principalCookieName，使得 druid 知道当前的 user 是谁
spring.datasource.druid.web-stat-filter.principal-cookie-name=cookieName

# 配置 profileEnable 能够监控单个 url 调用的 sql 列表（点击 url 有个 profiles）
spring.datasource.druid.web-stat-filter.profile-enable=true
```

配置完成后，我们可以看到如下效果

![image-20220302183405869](https://oss.rainsheep.cn/blog/image-20220302183405869-1646217245-b21.png)

## 2.4 spring 关联监控配置

参考：[配置_Druid和Spring关联监控配置](https://github.com/alibaba/druid/wiki/%E9%85%8D%E7%BD%AE_Druid%E5%92%8CSpring%E5%85%B3%E8%81%94%E7%9B%91%E6%8E%A7%E9%85%8D%E7%BD%AE)

```properties
# Spring 监控配置，配置 _Druid 和 Spring 关联监控配置
spring.datasource.druid.aop-patterns= # Spring监控AOP切入点，如x.y.z.service.*,配置多个英文逗号分隔
```

![image-20220302183947270](https://oss.rainsheep.cn/blog/image-20220302183947270-1646217587-484.png)

## 2.5 wall

参考：[配置 wallfilter](https://github.com/alibaba/druid/wiki/%E9%85%8D%E7%BD%AE-wallfilter)

Druid 提供了 WallFilter，它是基于 SQL 语义分析来实现防御 SQL 注入攻击的。

配置方式

```properties
spring.datasource.druid.filters=wall
```

与其他 filter 一起使用

```properties
spring.datasource.druid.filters=stat,wall
```

> 若 stat 在 wall 后面则无法统计拦截检测的时间

具体详细配置参考官网。

## 2.6 logFilter

参考：[配置_LogFilter](https://github.com/alibaba/druid/wiki/%E9%85%8D%E7%BD%AE_LogFilter)

我们想看 druid 日志的话，做如下配置

```properties
spring.datasource.druid.filters=slf4j
logging.level.druid.sql=debug
```

若需要指定日志，可以查看官网配置。

# 3. 流程分析

> 下面的比较难，做了解即可

参考：[池化技术（一）Druid是如何管理数据库连接的？](https://www.cnblogs.com/hama1993/p/11421576.html)



