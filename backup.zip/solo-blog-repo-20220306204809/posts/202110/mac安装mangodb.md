title: mac 安装 mangodb
date: '2021-10-01 23:09:19'
updated: '2021-10-01 23:09:19'
tags: [nosql, sql]
permalink: /articles/2021/10/01/1633100959279.html
---
参考文档：

[Mac 高版本 brew MongoDB 4.x 安装](https://zhuanlan.zhihu.com/p/111701216)
[mongodb/homebrew-brew](https://github.com/mongodb/homebrew-brew)

```
brew tap mongodb/brew
brew install mongodb-community
```

安装后的安装目录地址

- a configuration file: `/usr/local/etc/mongod.conf`
- a log directory path: `/usr/local/var/log/mongodb`
- a data directory path: `/usr/local/var/mongodb`

```
// 后台运行 mongodb
brew services start mongodb-community
// 关闭 mongodb服务
brew services stop mongodb-community
// 启动 mongodb
mongo
// 退出 mongo 的输入界面
exit
```



