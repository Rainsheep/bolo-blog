title: nginx 502 错误
date: '2021-10-21 19:25:17'
updated: '2021-10-21 19:25:17'
tags: [nginx]
permalink: /articles/2021/10/21/1634815517416.html
---
参考文献：[nginx 报 upstream sent too big header while reading response header from upstream](https://blog.csdn.net/yyj108317/article/details/109484923)

### 1. 问题

nginx 502 错误，查看日志，发现报错：

```
upstream sent too big header while reading response header from upstream
```

### 2. 解决方案

在 nginx 的配置文件 nginx.conf 的 http 块中添加如下配置：

```
proxy_buffer_size  64k;
proxy_buffers   32 64k;
proxy_busy_buffers_size 128k;
```

![20201104163737772](https://oss.rainsheep.cn/blog/20201104163737772-1634815116-5fd.png)

### 3. 参数解释

**proxy_buffer_size**

```
Syntax: 	proxy_buffer_size size;
Default: 	proxy_buffer_size 4k|8k;
Context: 	http, server, location
```

设置 Nginx 代理服务器从实际服务器接收到响应数据时的缓冲区的大小，默认是 4k|8k（根据系统处理），

简单理解：Nginx 代理服务器时，在接收到实际服务器的响应时，它会在自身搞出个缓冲区去放置，而这个缓冲区的默认大小是 4k 或者 8k.(后来查了下，我的接口请求的响应大小在 28k,远远超出了这个上限)

**proxy_buffers**

```
Syntax: 	proxy_buffers number size;
Default: 	proxy_buffers 8 4k|8k;
Context: 	http, server, location
```

这个参数设置存储被代理服务器上的数据所占用的 buffer 的个数和每个 buffer 的大小。当当前 buf 不够存响应 body 时才会新申请一个

**proxy_busy_buffers_size**

nginx 会在没有完全读完后端响应就开始向客户端传送数据，所以它会划出一部分 busy 状态的 buffer 来专门向客户端传送数据(建议为 proxy_buffers 中单个缓冲区的2倍)，然后它继续从后端取数据。

**proxy_buffering**

```
Syntax: 	proxy_buffering on | off;
Default:        proxy_buffering on;
Context: 	http, server, location
```

该指令开启从后端被代理服务器的响应 body 缓冲。
如果 proxy_buffering 开启, nginx 假定被代理的后端服务器会以最快速度响应,并把内容保存在由指令  proxy_buffer_size 和 proxy_buffers 指定的缓冲区里边.
如果响应 body 无法放在内存里边,那么部分内容会被写到磁盘上。
如果 proxy_buffering 被关闭了,那么响应 body 会按照获取 body 的多少立刻同步传送到客户端。nginx 不尝试计算被代理服务器整个响应 body 的大小, nginx 能从服务器接受的最大数据,是由指令 proxy_buffer_size 指定的。
对于基于长轮询(long-polling)的 Comet 应用来说,关闭 proxy_buffering 是重要的,不然异步响应将被缓存导致 Comet 无法工作。
但是无论 proxy_buffering 是否开启，proxy_buffer_size 都是生效的。

