title: android 点击事件
date: '2021-02-23 19:11:04'
updated: '2021-02-23 19:11:04'
tags: [android]
permalink: /articles/2021/02/23/1614078664162.html
---
**案例：电话拨号器**

activity_main.xml

```xml
<RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    tools:context=".MainActivity">

    <TextView
        android:id="@+id/textView1"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="请输入电话号码" />

    <EditText
        android:id="@+id/editText1"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_below="@+id/textView1"
        android:layout_alignParentStart="true"
        android:ems="10"
        android:hint="在这里输入电话"
        android:importantForAutofill="no"
        android:inputType="phone">

        <requestFocus />
    </EditText>

    <Button
        android:id="@+id/button1"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_below="@+id/editText1"
        android:layout_alignParentStart="true"
        android:text="拨打此号码" />

</RelativeLayout>
```

MainActivity.java

第一种写法：内部类实现 OnClickListener 接口

```java
public class MainActivity extends Activity {

    private EditText et_number;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et_number = findViewById(R.id.editText1);
        Button btn_call = findViewById(R.id.button1);
        btn_call.setOnClickListener(new MyOnclickListener());

    }

    private class MyOnclickListener implements OnClickListener {

        @Override
        public void onClick(View v) {
            String number = MainActivity.this.et_number.getText().toString();
            if (TextUtils.isEmpty(number)) {
                Toast.makeText(MainActivity.this, "电话号码不能为空", Toast.LENGTH_SHORT).show();
                System.out.println("用户输入是空的");
            } else {
                System.out.println("打电话:" + number);
                Intent intent = new Intent();
                intent.setAction("android.intent.action.CALL");
                Uri data = Uri.parse("tel:" + number);
                intent.setData(data);
                startActivity(intent);
            }
        }
    }
}
```

第二种写法：匿名内部类

此方法弊端：需要为每个控件设置匿名内部类，匿名内部类无法共用

```java
public class MainActivity extends Activity {

    private EditText et_number;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et_number = findViewById(R.id.editText1);
        Button btn_call = findViewById(R.id.button1);
        btn_call.setOnClickListener(v -> {
            String number = et_number.getText().toString().trim();
            if (TextUtils.isEmpty(number)) {
                Toast.makeText(MainActivity.this, "电话号码不能为空", Toast.LENGTH_SHORT).show();
            } else {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_CALL);
                intent.setData(Uri.parse("tel:" + number));
                startActivity(intent);
            }
        });
    }
}
```

第三种写法：父类实现 OnClickListener 接口，根据 id 区别被点击的 View，常用

```java
public class MainActivity extends Activity implements OnClickListener {

    private EditText et_number;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et_number = findViewById(R.id.editText1);
        Button btn_call = findViewById(R.id.button1);
        Button btn2 = findViewById(R.id.button2);
        Button btn3 = findViewById(R.id.button3);
        btn_call.setOnClickListener(this);
        btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.button1:
                String number = et_number.getText().toString().trim();
                if (TextUtils.isEmpty(number)) {
                    Toast.makeText(this, "电话号码不能为空", Toast.LENGTH_SHORT).show();
                } else {
                    Intent intent = new Intent();
                    intent.setAction(Intent.ACTION_CALL);
                    intent.setData(Uri.parse("tel:" + number));
                    startActivity(intent);
                }
                break;
            case R.id.button2:
                Toast.makeText(this, "电话号码不能为空2", Toast.LENGTH_SHORT).show();
                break;
            case R.id.button3:
                Toast.makeText(this, "电话号码不能为空3", Toast.LENGTH_SHORT).show();
                break;
        }
    }
}
```

第四种写法：onClick 属性，基本不用

```xml
<Button
    android:id="@+id/button1"
    android:layout_width="wrap_content"
    android:layout_height="wrap_content"
    android:layout_below="@+id/editText1"
    android:layout_alignParentStart="true"
    android:onClick="btnClick"
    android:text="拨打此号码" />
```

```java
public class MainActivity extends Activity {

    private EditText et_number;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et_number = findViewById(R.id.editText1);
    }

    public void btnClick(View v) {
        String number = et_number.getText().toString().trim();
        if (TextUtils.isEmpty(number)) {
            Toast.makeText(this, "电话号码不能为空", Toast.LENGTH_SHORT).show();
        } else {
            Intent intent = new Intent();
            intent.setAction(Intent.ACTION_CALL);
            intent.setData(Uri.parse("tel:" + number));
            startActivity(intent);
        }
    }
}
```

