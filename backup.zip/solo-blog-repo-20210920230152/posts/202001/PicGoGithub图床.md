title: PicGo+Github图床
date: '2020-01-01 13:03:23'
updated: '2020-01-01 13:03:23'
tags: [图床]
permalink: /articles/2020/01/01/1577855003862.html
---
## 参考链接：

[PicGo+ GitHub图床，让 Markdown飞](https://www.jianshu.com/p/2756724a5dee)

## 作用：

1. 图片转在线链接
2. 写 Markdown 时需要保存图片

## 为什么选择 GitHub

### 优点

- 稳定
- 免费

### 缺点

- 网速慢

## 配置 GitHub

### 创建 GitHub 仓库

![创建仓库](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-01-01+12:34:18+3146329-25f1990a188f9103.webp)

![输入仓库信息](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-01-01+12:35:02+3146329-596d8282a217da7e.webp)

### 生成 token 用于操作 GitHub repository

![点击settings](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-01-01+12:36:37+3146329-69a2b38f4634e509.webp)

![Developer settings](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-01-01+12:36:58+3146329-833a01142ad92e6d.webp)

![Personal access tokens](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-01-01+12:37:39+3146329-3ba67ab9f5224bda.webp)

![选择权限](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-01-01+12:38:32+3146329-2cddeffa8fe35933.webp)

> 注：创建成功后，会生成一串 token，这串 token 之后不会再显示，所以第一次看到的时候，就要好好保存

## 配置 picgo

下载地址：https://github.com/Molunerfinn/PicGo/releases

### GitHub 配置

![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-01-01+12:43:43+p_20200101124337.png)

> - 设定仓库名：账户名/仓库名
> - 设备分支名分支名：统一填写 master
> - 设定 Token：将之前的 Token 粘贴在这里
> - 存储的路径：可以按照我这样子写，就会在仓库下创建一个 img 文件夹
> - 自定义域名的作用是，在上传图片后成功后， PicGo 会将自定义域名 + 上传的图片名生成的访问链接，放到剪切板上。
>   -` https://raw.githubusercontent.com/用户名/仓库名/分支名`，自定义域名需要按照这样去填写

### 使用方法

- 右键图片上传
- 截图以后或者点击图片按上传快捷键

## 插件

优秀插件地址：https://github.com/PicGo/Awesome-PicGo

### 我的插件

![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-01-01+12:52:36+p_20200101125231.png)

### 插件配置方法

进去插件设置 →插件右下角小齿轮

### picgo-plugin-github-plus

本地删除相册的时候，GitHub 是不会删除的，此软件用于同步本地和 GitHub，两端保持一致，没啥用

配置如下：
![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-01-01+12:57:28+p_20200101125714.png)

> 其中 customUrl:`https://raw.githubusercontent.com/用户名/仓库名/master`

### picgo-plugin-super-prefix

用于自定义图像文件名和前缀
配置如下：

![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-01-01+13:00:05+p_20200101125950.png)

效果如下：
![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-01-01+13:00:39+p_20200101010034.png)
