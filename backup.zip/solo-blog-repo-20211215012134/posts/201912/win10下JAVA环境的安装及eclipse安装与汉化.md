title: win10下JAVA环境的安装及eclipse安装与汉化
date: '2019-12-03 22:43:14'
updated: '2021-06-05 02:08:58'
tags: [软件教程]
permalink: /articles/2019/12/03/1575384194057.html
---
# Java 环境的配置：

**windows 系统**

先去官网下载 jdk:[https://www.oracle.com/technetwork/java/javase/downloads/index.html](https://www.oracle.com/technetwork/java/javase/downloads/index.html)
百度云盘链接：[https://pan.baidu.com/s/1t3VjaMRPSnI2rGd1hjIcMQ](https://pan.baidu.com/s/1t3VjaMRPSnI2rGd1hjIcMQ) 密码：6hjy

建议下载 jdk8, jdk10 太新了，容易出现不兼容现象，下载 jdl 不是 jre。

Jre 是 Java runtime environment, 是 Java 程序的运行环境。既然是运行，当然要包含 jvm，也就是大家熟悉的虚拟机啦，还有所有 Java 类库的 class 文件，都在 lib 目录下打包成了 jar。
Jdk 是 Java development kit，是 Java 的开发工具包，里面包含了各种类库和工具，当然也包括了另外一个 Jre。
这里只需要下载 jdk 即可，安装的时候会自动安装 jre。

![20180801233008728.png](https://img.hacpai.com/file/2019/12/20180801233008728-e29428d1.png)

这里接受点上去才能下载：
![20180801234112240.png](https://img.hacpai.com/file/2019/12/20180801234112240-fe7f424a.png)

下载完以后直接安装就行，安装的时候不要修改路径！特别容易出问题，安装过程中提示安装 jre 的时候安装上去就行。

中途提一下卸载，如果要卸载的话把 jdk 和 jre 都卸载掉。

接下来说环境 win10 下环境的配置，我的系统版本是 win10 1803 版本

我的电脑-&gt; 右键-&gt; 属性-&gt; 高级系统设置-&gt; 环境变量

![20180801234549808.png](https://img.hacpai.com/file/2019/12/20180801234549808-5c6145dc.png)

![20180801234643373.png](https://img.hacpai.com/file/2019/12/20180801234643373-aaa8c420.png)

可以看到两个环境变量，接下来的操作是在下面那个环境变量进行的，就是系统变量，切记

![20180801234802233.png](https://img.hacpai.com/file/2019/12/20180801234802233-b5f36c45.png)

新建 JAVA_HOME，变量值填写你 jdk 刚才安装的路径，默认如下

![20180801235052967.png](https://img.hacpai.com/file/2019/12/20180801235052967-fcae7512.png)

新建 CLASSPATH，变量值`.;%JAVA_HOME%\lib\dt.jar;%JAVA_HOME%\lib\tools.jar;`

![20180801235143949.png](https://img.hacpai.com/file/2019/12/20180801235143949-40117514.png)

最重要的一步，也是 win10 和 win7 的差距

在系统变量区域找到“Path”变量，并双击打开，path 是原有的

win7 下添加`%JAVA_HOME%\bin;%JAVA_HOME%\jre\bin;`即可

win10 的 path 必须写绝对路径，如下设置，添加两行

![2018080123553566.png](https://img.hacpai.com/file/2019/12/2018080123553566-4f7a5020.png)

（在对环境变量有了进一步了解后，更新一下此处，如果只安装的 jdk 的话，第二个环境变量可以写成

`C:\Program Files\Java\jdk1.8.0_181\jre\bin` 因为 jdk 是自带 jre 的，就在 jdk 下面的 jre 文件夹内，所以说是一样的，

另外，刚刚我测试的时候，发现 win10 也可以使用相对路径了，所以也可以写成

```
%JAVA_HOME%\bin
%JAVA_HOME%\jre\bin
```

点确定返回即可，是 3 个确定

然后 WIN+R 输入 cmd，打开运行

在 cmd 中分别输入 Java，Java -version(jdk 版本号)，javac(编译命令)

结果如下

![20180801235815341.png](https://img.hacpai.com/file/2019/12/20180801235815341-c993424c.png)
![20180801235839148.png](https://img.hacpai.com/file/2019/12/20180801235839148-41277ca1.png)
![20180801235902746.png](https://img.hacpai.com/file/2019/12/20180801235902746-1bc886b1.png)

至此，Java 环境配置成功

**mac 系统**

下载 JDK [Oracle JDK](https://www.oracle.com/cn/java/technologies/javase-downloads.html)

下载 dmg 直接安装

查看默认安装环境：`/usr/libexec/java_home -V`

配置环境变量(.zshrc 文件)

```bash
export JAVA_HOME=/Library/Java/JavaVirtualMachines/jdk-11.0.11.jdk/Contents/Home
export CLASS_PATH=$JAVA_HOME/lib
export PATH=$JAVA_HOME/bin:$PATH
```

# eclipse 的安装

我参考的[https://blog.csdn.net/longshenlmj/article/details/52330106](https://blog.csdn.net/longshenlmj/article/details/52330106)

首先去官网下载 eclipse,[http://www.eclipse.org/downloads/packages/](http://www.eclipse.org/downloads/packages/)

百度网盘链接：[https://pan.baidu.com/s/1NnJER35HQL-HWqCMJtOglw](https://pan.baidu.com/s/1NnJER35HQL-HWqCMJtOglw) 密码：33nl

现在应该可以自动安装，还是推荐下载包

选择 “Eclipse IDE for Java Developers”，确定是 64bit 还是 32 的

下载完是个压缩包，加压出来即可使用，注意:配置完 Java 环境后才能使用

打开以后直接使用

# eclipse 的汉化

明确一下现在你的软件版本，打开安装目录的 readme 文件夹，可以看到一个 HTML 文件，用浏览器打开，如图，

4.8 就是版本号，后面是一个版本代号，不显示的话百度查各版本对应的代号

![20180802000958457.png](https://img.hacpai.com/file/2019/12/20180802000958457-d1327101.png)

4.7 Oxygen   氧气           4.8 Photo 光子

光子版本的百度云盘链接： [https://pan.baidu.com/s/1NnJER35HQL-HWqCMJtOglw](https://pan.baidu.com/s/1NnJER35HQL-HWqCMJtOglw) 密码：33nl

查完以后打开语言包下载网址：[http://www.eclipse.org/babel/](http://www.eclipse.org/babel/)

![20180802001208993.png](https://img.hacpai.com/file/2019/12/20180802001208993-40fe2713.png)

下载对应版本

![20180802001248627.png](https://img.hacpai.com/file/2019/12/20180802001248627-fa7f74f8.png)

找到与此名字类似的包下载

![20180802001357530.png](https://img.hacpai.com/file/2019/12/20180802001357530-37a5d1be.png)

解压下载的压缩文件，可以看到 eclipse 目录下有 plugins 和 features 两个文件夹，把他们复制或者剪切下来放到 Eclipse 安装目录里的 dropins 文件夹下

![20180802001605910.png](https://img.hacpai.com/file/2019/12/20180802001605910-6361a388.png)

![20180802001630250.png](https://img.hacpai.com/file/2019/12/20180802001630250-ec8fe4df.png)

![20180802001645406.png](https://img.hacpai.com/file/2019/12/20180802001645406-e79f31df.png)

到此完成，打开软件看看是不是汉化成功了

# API 的汉化（不适用于 JDK10）

下载中文的 API，下载链接：[https://pan.baidu.com/s/1G4CAYWzunFHnkl9Ab2V7gA](https://pan.baidu.com/s/1G4CAYWzunFHnkl9Ab2V7gA) 密码：p6de

参考[https://jingyan.baidu.com/article/c275f6bacb4425e33d7567b6.html](https://jingyan.baidu.com/article/c275f6bacb4425e33d7567b6.html)

我们点击窗口单击”首选项“，我们在“Java”下找到“已安装的 JRE”，我们点击里面已安装的 JRE，界面显示如下：

![20180802002323808.png](https://img.hacpai.com/file/2019/12/20180802002323808-59e29575.png)

我们点击“编辑”，界面显示如下：

![2018080200241673.png](https://img.hacpai.com/file/2019/12/2018080200241673-2ed4fcc0.png)

我们单击上图中的选项，然后单击“移除”，界面显示如下：

![20180802002456245.png](https://img.hacpai.com/file/2019/12/20180802002456245-e2387737.png)

我们选中底下的一个选项，然后单击“Javadoc 位置”，界面显示如下：

![20180802002530965.png](https://img.hacpai.com/file/2019/12/20180802002530965-3eb5ff31.png)

我们按照上图所示的，找到我们之前下载的 Eclipse 的中文 API，要一直到“API”路径，然后点击“确定”，界面显示如下：

![20180802002618159.png](https://img.hacpai.com/file/2019/12/20180802002618159-61222e6f.png)

我们可以点击“测试”，看看我们选择的路径是否正确

我们点击“确定”，关闭弹出窗口，再点击“确定”

对下图 jar 做出同样操作，（操作包括移除以前的，再设置现在的“Javadoc 位置”）

![20180802002748441.png](https://img.hacpai.com/file/2019/12/20180802002748441-059437d1.png)

对两个选项都设置完成后，我们再单击“确定”，即完成了对 Eclipse 的全部设置，现在我们把鼠标放在代码上，就会出现中文的提示了



