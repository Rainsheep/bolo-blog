title: git 命令汇总
date: '2020-09-15 13:46:32'
updated: '2021-03-02 17:12:35'
tags: [GitHub, git]
permalink: /articles/2020/09/15/1600148792043.html
---
参考文献：

[Git撤销&amp;回滚操作(git reset 和 get revert)](https://blog.csdn.net/asoar/article/details/84111841)

[git远程操作相关命令辨析(remote 、push、fetch 、pull)](https://www.cnblogs.com/yinzhi/p/11599997.html)

### git  本地使用

* 将目录变为 git 仓库

  ```
  git init
  ```
* 查询当前工作区和暂存区的状态

  ```
  git status
  ```
* 添加文件到暂存区

  ```
  # path 可以是文件或者目录
  git add <path>

  # 添加所有文件到暂存区，包括 .gitignore 忽略的文件
  git add *

  # 添加所有文件到暂存区，不包括 .gitignore 忽略的文件
  git add .
  git add -A [<path>]
  git add --all [<path>]

  # 添加已被跟踪的文件到暂存区
  git add -u [<path>]
  git add --update [<path>]
  ```
* 提交暂存区内容到版本可

  ```
  # 提交到版本库，message 为提交说明
  git commit -m "message"

  # 提交所有已跟踪文件到本地仓库，即使没有经过 git add 添加到暂存区
  git commit -a -m "message"
  git commit --all -m "message"

  # 修改先前(上一个版本)的提交
  git commit --amend
  ```
* 本地分支

  ```
  # 查看本地分支
  git branch

  # 查看所有分支(包括远程)
  git branch -a

  # 创建本地分支
  git branch branchName

  # 切换本地仓库分支
  git checkout localBranchName
  ```
* 查看提交历史

  ```
  git log
  ```
* 回退

  在Git中，用HEAD表示当前版本,上一个版本是HEAD^,上上一个版本是HEAD^^

  --hard 表示重置 HEAD、索引和工作区

  ```
  # 在工作区中的代码
  # 回到缓存区之前的状态
  git checkout a.txt
  git checkout .


  # 代码 add 到缓存区，并未 commit
  # 回退到 add 操作之前
  git reset HEAD .
  git reset HEAD a.txt


  # commit 到本地分支，但是没有 push 到远程
  # 获取 commit id
  git log
  # 回到某个版本
  git reset --hard <commit id>
  # 回退到最近一次提交
  git reset --hard HEAD^
  # 保留工作区代码，回退到 add 之前
  git reset HEAD^

  # --mixed 
  意思是：不删除工作空间改动代码，撤销commit，并且撤销 git add . 操作，这个为默认参数
  git reset --mixed HEAD^ 和 git reset HEAD^ 效果是一样的。 
  # --soft  
  不删除工作空间改动代码，撤销commit，不撤销git add . 
  # --hard
  删除工作空间改动代码，撤销commit，撤销git add . ，注意完成这个操作后，就恢复到了上一次的 commit 状态。

  # 撤销指定的版本，撤销也会作为一次提交进行保存
  git revert <commit id>
  ```
* 图形化界面操作

  ```
  gitk
  ```

### git 远程使用

* origin 是指向仓库的指针，master 是指向分支的指针
* ```
  # 查看远程仓库名
  git remote

  # 查看远程仓库详细信息
  git remote -v/--version

  # 添加远程仓库
  git remote add name url

  # 删除远程仓库
  git remote remove name

  # 查看远程仓库信息
  git remote show 仓库名
  ```
* 远程分支

  ```
  # 查看所有远程分支
  git branch -r

  # 查看当前本地分支所关联的远程分支
  git branch -vv

  # 创建一个新的本地分支，并与指定的远程分支关联起来。
  git checkout -b localBranchName origin/remoteBranchName

  # 将本地当前分支和远程分支绑定
  git push --set-upstream origin remoteBranchName
  ```
* 从远程仓库克隆

  ```
  git clone
  # 克隆远端指定分支
  git clone -b 远程分支名 ssh地址
  ```
* push 到远程仓库

  ```
  # 完整写法
  git push <远程仓库名> <本地分支名>:<远程分支名>

  # 删除远程分支
  git push origin :远程分支名
  git push origin --delete :远程分支名
  git push origin :远程分支名 --delete

  # 将本地分支推送到与之存在Tracking（追踪关系)的远程分支，通常两分支同名。如果远程分支不存在，则会自动创建分支。
  git push origin master

  # 如果当前分支只有一个追踪分支，那么仓库名都可以省略。
  git push

  # 如果当前分支与多个仓库存在追踪关系，则可以使用-u选项指定一个默认仓库，这样后面就可以不加任何参数使用git push。
  git push -u origin master
  ```
* fetch 从远程拉取更新，从远程获取最新版本到本地仓库，而不是工作目录, 并且不会自动merge

  ```
  git fetch <远程仓库名>   <远程分支名>：<本地分支名>
  git fetch <远程仓库名> <分支名>
  git fetch <远程仓库名>
  ```
* pull 是从远程获取最新版本到本地，并低程度的自动merge；但大部分还需要自己判断合并,等价与 git fetch & git merage

  ```
  git pull <远程仓库名> <远程分支名>:<本地分支名>
  git pull origin <远程分支名>
  # 只有一个追踪分支
  git pull
  ```

### 忽略文件

* 在项目目录下创建 `.gitignore` 文件，写入要忽略的文件
* 忽略规则

  * 空行或是以 # 开头的行为注释行
  * “/ 结尾表示目录
  * “*” 通配多个字符
  * "**" 表示匹配任意中间目录，比如`a/**/z` 可以匹配 a/z, a/b/z 或 a/b/c/z等。
  * “?” 通配单个字符
  * “!” 表示不忽略(跟踪)匹配到的文件或目录
  * "/" 开始的模式匹配项目根目录；如果一个模式不包含斜杠，则它匹配相对于当前 .gitignore 文件路径的内容，如果该模式不在 .gitignore 文件中，则相对于项目根目录。
  * 空格不匹配任意文件，可作为分隔符，可用反斜杠转义
  * 以叹号"!"表示不忽略(跟踪)匹配到的文件或目录，即要忽略指定模式以外的文件或目录，可以在模式前加上惊叹号（!）取反。
* 模板

  ```
  .DS_Store
  node_modules
  /dist

  # local env files
  .env.local
  .env.*.local

  # Log files
  npm-debug.log*
  yarn-debug.log*
  yarn-error.log*

  # Editor directories and files
  .idea
  .vscode
  *.suo
  *.ntvs*
  *.njsproj
  *.sln
  *.sw*
  ```
* 安卓模板

  ```
  *.iml
  .gradle/
  /local.properties
  .idea/
  .DS_Store
  build/
  captures/
  .externalNativeBuild
  .gitignore
  app/build/
  app/platformxm.keystore
  ```
