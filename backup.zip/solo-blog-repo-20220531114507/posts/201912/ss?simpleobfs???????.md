title: ss的simple-obfs混淆客户端设置
date: '2019-12-04 11:55:24'
updated: '2019-12-04 11:55:24'
tags: [Shadowsocks, ss]
permalink: /articles/2019/12/04/1575431723992.html
---
下载 obfs-local.zip   
下载网址：  
[https://github.com/shadowsocks/simple-obfs/releases](https://github.com/shadowsocks/simple-obfs/releases)  
下载后，解压出来的文件一定要和 Windows 客户端的 exe 文件放在同一文件夹下

![2018120623362785.png](https://img.hacpai.com/file/2019/12/2018120623362785-de0b0135.png)


插件程序：obfs-local
插件选项:obfs=http;obfs-host=www.bing.com   (http混淆时；网址随便写)
