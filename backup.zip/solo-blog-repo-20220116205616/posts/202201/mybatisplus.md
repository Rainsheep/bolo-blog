title: mybatis plus
date: '2022-01-16 00:33:15'
updated: '2022-01-16 00:33:15'
tags: [mybatis]
permalink: /articles/2022/01/16/1642264395147.html
---
参考文档：[Mybatis-plus](https://baomidou.com/pages/24112f/#%E7%89%B9%E6%80%A7)

> 此篇文章只记录使用过程中用到的问题，具体使用教程，请参考官网

# 1. 快速入门

# 2. 核心功能

## 2.1 代码生成器

生成的代码：

**entity**

```java
@Data
@EqualsAndHashCode(callSuper = false)
public class User implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 姓名
     */
    private String name;

    /**
     * 年龄
     */
    private Integer age;

    /**
     * 邮箱
     */
    private String email;
}
```

**mapper 接口**

```java
public interface UserMapper extends BaseMapper<User> {
}
```

**controller**

```java
@RestController
@RequestMapping("/user")
public class UserController {
}
```

**mapper.xml**

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN" "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="com.example.springboottest.mapper.UserMapper">
</mapper>
```

## 2.2 条件构造器

### 2.2.1 AbstractWrapper

QueryWrapper(LambdaQueryWrapper) 和 UpdateWrapper(LambdaUpdateWrapper) 的父类
用于生成 sql 的 where 条件, entity 属性也用于生成 sql 的 where 条件。

里面有 eq/in/or 等通用方法。

### 2.2.2 QueryWrapper

继承自 AbstractWrapper，多了 select 方法。

```java
QueryWrapper<User> wrapper = new QueryWrapper<>();
wrapper.eq("name", "zhangsan");
userMapper.selectOne(wrapper);
```

### 2.2.3 LambdaQueryWrapper

可以通过 `new QueryWrapper().lambda()` 获取，区别在于可以使用 lambda 表达式表示列名

```java
// 相当于 new LambdaQueryWrapper<>(entityClass); 不推荐使用 new
LambdaQueryWrapper<User> wrapper = Wrappers.lambdaQuery(User.class);
wrapper.eq(User::getName, "zhangsan");
userMapper.selectOne(wrapper);
```

### 2.2.4 AbstractChainWrapper

相当于 AbstractWrapper 的扩展，增加 one (代替 selectOne), list (代替 selectList) 等链式方法。

看两个例子就明白了。

```java
QueryChainWrapper<User> chainWrapper = new QueryChainWrapper<>(userMapper);
User user = chainWrapper.eq("name", "zhangsan").one();

LambdaQueryChainWrapper<User> wrapper = new LambdaQueryChainWrapper<>(userMapper);
List<User> users = wrapper.eq(User::getName, "zhangsan").list();
```

# 3. 扩展

# 4. 插件



