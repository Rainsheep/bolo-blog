title: STL中常用的vector，map，set，sort 用法 转
date: '2019-12-03 20:11:18'
updated: '2019-12-03 20:11:18'
tags: [STL, 知识点总结]
permalink: /articles/2019/12/03/1575375078258.html
---
STL 中的常用的 vector，map，set，sort，pair 用法

C++ 的标准模板库（Standard Template Library，简称 STL）是一个容器和算法的类库。容器往往包含同一类型的数据。STL 中比较常用的容器是 vector，set 和 map，比较常用的算法有 Sort 等。

# vector

1.声明：
一个 vector 类似于一个动态的一维数组。
vector 中可以存在重复的元素！
vector<int> a;          // 声明一个元素为 int 类型的 vector a
vectot<MyType> a;       // 声明一个元素为 MyType 类型的 vector a
这里的声明的 a 包含 0 个元素，既 a.size()的值为 0，但它是动态的，其大小会随着数据的插入和删除改变而改变。
vector<int> a(100, 0);  // 这里声明的是一个已经存放了 100 个 0 的整数 vector

2.向量操作
常用函数：
a.size();                // 返回 vector 的大小，即包含的元素个数
a.pop_back();            // 删除 vector 末尾的元素，vector 大小相应减一
a.push_back();           // 用于在 vector 的末尾添加元素
a.back();                // 返回 vector 末尾的元素
a.clear();               // 将 vector 清空，vector 大小变为 0
其他访问方式：
cout&lt;&lt;a[5]&lt;&lt;endl;
cout&lt;&lt;a.at(5)&lt;&lt;endl;
以上区别在于后者在访问越界时会抛出异常，而前者不会。

3.遍历
(1). for(vector<datatype>::iterator it=a.begin(); it!=a.end(); it++)
cout&lt;&lt;*it&lt;&lt;endl;
(2). for(int i = 0; i &lt; a.size(); i++)
cout&lt;&lt;a[i]&lt;&lt;endl;

1.vector 的数据的存入和输出：

```c++
#include <cstdio>
#include <vector>
#include <iostream>
using namespace std;
int main()
{
	int i = 0;
    vector<int> v;
    for(i = 0; i < 10; i++)
	{
		v.push_back( i );       //把元素一个一个存入到vector中
	}
    /* v.clear()*/ //对存入的数据清空
	for( i = 0; i < v.size(); i++ ) //v.size() 表示vector存入元素的个数
	{
		cout << v[ i ] << "  "; //把每个元素显示出来
	}
	cout << endl;
}

```

1. push_back()        在数组的最后添加一个数据
2. pop_back()         去掉数组的最后一个数据
3. at()               得到编号位置的数据
4. begin()            得到数组头的指针
5. end()              得到数组的最后一个单元 +1 的指针
6. front()            得到数组头的引用
7. back()             得到数组的最后一个单元的引用
8. max_size()         得到 vector 最大可以是多大
9. capacity()         当前 vector 分配的大小
10. size()             当前使用数据的大小
11. resize()           改变当前使用数据的大小，如果它比当前使用的大，则填充默认值
12. reserve()          改变当前 vecotr 所分配空间的大小
13. erase()            删除指针指向的数据项
14. clear()            清空当前的 vector
15. rbegin()           将 vector 反转后的开始指针返回(其实就是原来的 end-1)
16. rend()             将 vector 反转构的结束指针返回(其实就是原来的 begin-1)
17. empty()            判断 vector 是否为空
18. swap()             与另一个 vector 交换数据

# map

附 map 的详细用法：[http://blog.csdn.net/sunshinewave/article/details/8067862](http://blog.csdn.net/sunshinewave/article/details/8067862)

Map 是 STL 的一个关联容器，它提供一对一（其中第一个可以称为关键字，每个关键字只能在 map 中出现一次，第二个可能称为该关键字的值）的数据处理能力，由于这个特性
map 内部的实现自建一颗红黑树(一种非严格意义上的平衡二叉树)，这颗树具有对数据自动排序的功能。
下面举例说明什么是一对一的数据映射。比如一个班级中，每个学生的学号跟他的姓名就存在着一一映射的关系，这个模型用 map 可能轻易描述，
很明显学号用 int 描述，姓名用字符串描述(本篇文章中不用 char *来描述字符串，而是采用 STL 中 string 来描述),
下面给出 map 描述代码：

1.声明方式：
map&lt;int, string&gt; mapStudent; 或 map&lt;string，int&gt; mapStudent;
/*两者均是正确声明方式，当然效果是不一样的*/

2.数据的插入
在构造 map 容器后，我们就可以往里面插入数据了。这里讲三种插入数据的方法：
第一种：用 insert 函数插入 pair 数据

map&lt;int, string&gt; mapStudent;
mapStudent.insert(pair&lt;int, string&gt;(1,“student_one”));

第二种：用 insert 函数插入 value_type 数据

map&lt;int, string&gt; mapStudent;
mapStudent.insert(map&lt;int, string&gt;::value_type (1,&quot;student_one&quot;));
mapStudent.insert(make_pair(1, &quot;student_one&quot;));

第三种：用数组方式插入数据

map&lt;int, string&gt; mapStudent;
mapStudent[1] = “student_one”;
mapStudent[2] = “student_two”;

/*
如果是
#include &lt;map&gt;
map&lt;string, int&gt; mapStudent;
string s;
插入就用 m[s]++;
*/

以上三种用法，虽然都可以实现数据的插入，但是它们是有区别的，当然了第一种和第二种在效果上是完成一样的，用 insert 函数插入数据，在数据的插入上涉及到集合的唯一性这个概念，即当 map 中有这个关键字时，insert 操作是不能再插入这个数据的，但是用数组方式就不同了，它可以覆盖以前该关键字对应的值;

3.map 的大小
在往 map 里面插入了数据，我们怎么知道当前已经插入了多少数据呢，可以用 size 函数：
int nSize = mapStudent.size();

4.数据的遍历
第一种：应用前向迭代器

```c++
map<int, string>::iterator iter;
for(iter = mapStudent.begin(); iter != mapStudent.end(); iter++)
    cout<<iter->first<<"  "<<iter->second<<end;
```

第二种：应用反向迭代器

```c++
map<int, string>::reverse_iterator iter;
for(iter = mapStudent.rbegin(); iter != mapStudent.rend(); iter++)
    cout<<iter->first<<"  "<<iter->second<<end;

```

第三种：用数组方式

```c++
int nsize = mapStudent.size()
for(int nIndex = 1; nIndex <= nSize; nIndex++)
     cout<<mapStudent[nIndex]<<end;

```

例如：

```c++
#include<map>
#include<string>
#include<iostream>
using namespace std;
 
int main()
{
    map<string,int>  m;
    m["a"]=1;
    m["b"]=2;
    m["c"]=3;
    map<string,int>::iterator it;
    for(it=m.begin();it!=m.end();++it)
        cout<<"key: "<<it->first <<" value: "<<it->second<<endl;
    return   0;
}
```

map&lt;string,int&gt;::iterator it;   定义一个迭代指针 it。
it-&gt;first 为索引键值，it-&gt;second 为值。

5.数据的查找（包括判定这个关键字是否在 map 中出现）
这里给出三种数据查找方法:
第一种：用 count 函数来判定关键字是否出现，但是无法定位数据出现位置
第二种：用 find 函数来定位数据出现位置它返回的一个迭代器，
当数据出现时，它返回数据所在位置的迭代器，如果 map 中没有要查找的数据，它返回的迭代器等于 end 函数返回的迭代器。

例如：

```c++
int main()
{
            map<int, string> mapStudent;
            mapStudent.insert(pair<int, string>(1, “student_one”));
            mapStudent.insert(pair<int, string>(2, “student_two”));
            mapStudent.insert(pair<int, string>(3, “student_three”));
            map<int, string>::iterator iter;
            iter = mapStudent.find(1);
            if(iter != mapStudent.end())
            {
                   cout<<”Find, the value is ”<<iter->second<<endl;
            }
            else
            {
               cout<<”Do not Find”<<endl;
            }
}

```

第三种：这个方法用来判定数据是否出现
lower_bound 函数用法，这个函数用来返回要查找关键字的下界(是一个迭代器)
upper_bound 函数用法，这个函数用来返回要查找关键字的上界(是一个迭代器)
例如：map 中已经插入了 1，2，3，4 的话，如果 lower_bound(2)的话，返回的 2，而 upper-bound（2）的话，返回的就是 3
equal_range 函数返回一个 pair，pair 里面第一个变量是 Lower_bound 返回的迭代器，pair 里面第二个迭代器是 Upper_bound 返回的迭代器，如果这两个迭代器相等的话，则说明 map 中不出现这个关键字，程序说明
mapPair = mapStudent.equal_range(2);
if(mapPair.first == mapPair.second)
cout&lt;&lt;”Do not Find”&lt;&lt;endl;

6.数据的清空与判空
清空 map 中的数据可以用 clear()函数，判定 map 中是否有数据可以用 empty()函数，它返回 true 则说明是空 map

7.数据的删除
这里要用到 erase 函数，它有三个重载了的函数
迭代器删除
iter = mapStudent.find(1);
mapStudent.erase(iter);
用关键字删除
int n = mapStudent.erase(1);//如果删除了会返回 1，否则返回 0
用迭代器，成片的删除
一下代码把整个 map 清空
mapStudent.earse(mapStudent.begin(), mapStudent.end());
//成片删除要注意的是，也是 STL 的特性，删除区间是一个前闭后开的集合

8.其他一些函数用法
这里有 swap,key_comp,value_comp,get_allocator 等函数；

实例运用请见：[http://blog.csdn.net/u012860063/article/details/35338617](http://blog.csdn.net/u012860063/article/details/35338617)

例如：

map &lt;int, vector<int> &gt; mm;
第二个键值是一个 vector 容器，就可以存多个值，和二维数组 a[ ] [ ]，差不多了！
个数 ： int len = mm[tt].size();
访问其中的值，直接可以用 mm[i] [j]访问;
vector&lt;int&gt; ::iterator iter;
iter = lower_bound(mm[tt].begin(), mm[tt].end(), l);
见：[http://blog.csdn.net/u012860063/article/details/44498559](http://blog.csdn.net/u012860063/article/details/44498559)

# set

set 是集合，set 中不会包含重复的元素，这是和 vector 的区别。
定义：
定义一个元素为整数的集合 a，可以用 set<int> a;
1，set 的含义是集合，它是一个有序的容器，里面的元素都是排序好的，支持插入，删除，查找等操作，就像一个集合一样。所有的操作都是严格在 logn 时间之内完成的，效率非常高。 set 和 multiset 的区别是：set 插入的元素不能相同，但是 multiset 可以相同。

set 的基本操作：

1. begin()         返回指向第一个元素的迭代器
2. clear()         清除所有元素
3. count()         返回某个值元素的个数
4. empty()         如果集合为空，返回 true
5. end()           返回指向最后一个元素的迭代器
6. equal_range()   返回集合中与给定值相等的上下限的两个迭代器
7. erase()         删除集合中的元素
8. find()          返回一个指向被查找到元素的迭代器
9. get_allocator() 返回集合的分配器
10. insert()        在集合中插入元素
11. lower_bound()   返回指向大于（或等于）某值的第一个元素的迭代器
12. key_comp()      返回一个用于元素间值比较的函数
13. max_size()      返回集合能容纳的元素的最大限值
14. rbegin()        返回指向集合中最后一个元素的反向迭代器
15. rend()          返回指向集合中第一个元素的反向迭代器
16. size()          集合中元素的数目
17. swap()          交换两个集合变量
18. upper_bound()   返回大于某个值元素的迭代器
19. value_comp()    返回一个用于比较元素间的值的函数

set 的遍历
代码如下：

```c++
set<int>ss;
        set<int>::iterator it;
        for(it = ss.begin(); it != ss.end(); it++)
        {
            printf("%d ",*it);
        }

```

lower_bound()返回一个 iterator 它指向在[first,last)标记的有序序列中可以插入 value，而不会破坏容器顺序的第一个位置，而这个位置标记了一个大于等于 value 的值。　　
例如，有如下序列：　　ia[]={12,15,17,19,20,22,23,26,29,35,40,51};
用值 21 调用 lower_bound(),返回一个指向 22 的 iterator。用值 22 调用 lower_bound(),也返回一个指向 22 的 iterator。
iterator upper_bound( const key_type &amp;key ):返回一个迭代器，指向键值 &gt; key 的第一个元素

---
函数 lower_bound()在 first 和 last 中的前闭后开区间进行二分查找，返回大于或等于 val 的第一个元素位置。如果所有元素都小于 val，则返回 last 的位置

举例如下：

一个数组 number 序列为：4,10,11,30,69,70,96,100.设要插入数字 3,9,111.pos 为要插入的位置的下标

则

pos = lower_bound( number, number + 8, 3) - number，pos = 0.即 number 数组的下标为 0 的位置。

pos = lower_bound( number, number + 8, 9) - number， pos = 1，即 number 数组的下标为 1 的位置（即 10 所在的位置）。

pos = lower_bound( number, number + 8, 111) - number， pos = 8，即 number 数组的下标为 8 的位置（但下标上限为 7，所以返回最后一个元素的下一个元素）。

所以，要记住：函数 lower_bound()在 first 和 last 中的前闭后开区间进行二分查找，返回大于或等于 val 的第一个元素位置。如果所有元素都小于 val，则返回 last 的位置，且 last 的位置是越界的！！~

返回查找元素的第一个可安插位置，也就是“元素值 &gt;= 查找值”的第一个元素的位置

---
集合的并，交和差
set_union(a.begin(),a.end(),b.begin(),b.end(),insert_iterator&lt;set<int> &gt;(c,c.begin()));
set_intersection(a.begin(),a.end(),b.begin(),b.end(),insert_iterator&lt;set<int> &gt;(c,c.begin()));
set_difference(a.begin(),a.end(),b.begin(),b.end(),insert_iterator&lt;set<int> &gt;(c,c.begin()));

详见：[http://blog.csdn.net/u012860063/article/details/33797407](http://blog.csdn.net/u012860063/article/details/33797407)

（注意在此前要将 c 清为空集）。
注意：
为了实现集合的快速运算，set 的实现采用了平衡二叉树，因此，set 中的元素必须是可排序的。如果是自定义的类型，那在定义类型的同时必须给出运算符 &lt; 的定义
struct node
{
int x, y;
bool operator &lt; (const struct node tmp) const
{
if(x == tmp.x)
return y &lt; tmp.y ;
return x &lt; tmp.x ;
}
} ;

# Sort

sort 顾名思义就是排序

用法：
单关键字：
对于 vector a 来说
sort(a,a+n); //n=a.size()       将 a 中元素按递增排序。
多关键字：
我们也可以利用类 pair
vector&lt; pair&lt;int,int&gt; &gt; a; // 注意这里两个 &gt; &gt; 中间必须有一个空格，否则编译器会当是运算符 &gt;&gt;
例如：

```c++
int N,x,y;
cin >> N;
for(int i = 0; i < N; ++i) 
{
	cin >> x >> y;
	a.push_back(make_pair(x,y)); // make_pair用于创建pair对象
}
sort(&a[0], &a[N]);</span>


```

注意：
对于我们自己定义的类或结构，系统一般不能做比较运算，需要我们自己定义相应的运算符

```c++
bool cmp(MyType x, MyType y)
{
	if(x < y)
		return true;
	if(x >= y)
		return false;
}

```

# Pair

（转自：[http://blog.csdn.net/spaceyqy/article/details/38384501](http://blog.csdn.net/spaceyqy/article/details/38384501)）

map 是一个关联容器，里面存放的是键值对，容器中每一元素都是 pair 类型，通过 map 的 insert()方法来插入元素(pair 类型)。template &lt;class T1,class T2&gt;
pair&lt;T1,T2&gt; make_pair (T1 x, T2 y)
{
return ( pair&lt;T1,T2&gt;(x,y) );
}

pair 的类型：

pair 是 一种模版类型。每个 pair 可以存储两个值。这两种值无限制。也可以将自己写的 struct 的对象放进去。。

pair&lt;string,int&gt; p;

pair&lt;int ,int &gt; p;

pair&lt;double,int&gt; p;

都可以。。。

std::pair 主要的作用是将两个数据组合成一个数据，两个数据可以是同一类型或者不同类型。例如 std::pair&lt;int,float&gt; 或者 std：：pair&lt;double,double&gt; 等。pair 实质上是一个结构体，其主要的两个成员变量是 first 和 second，这两个变量可以直接使用。初始化一个 pair 可以使用构造函数，也可以使用 std::make_pair 函数。

应用：如果一个函数有两个返回值 的话，如果是相同类型，就可以用数组返回，如果是不同类型，就可以自己写个 struct ，但为了方便就可以使用 c++ 自带的 pair ，返回一个 pair,其中带有两个值。除了返回值的应用，在一个对象有多个属性的时候 ，一般自己写一个 struct ，如果就是两个属性的话，就可以用 pair 进行操作。。。
应用 pair 可以省的自己写一个 struct 。。。如果有三个属性的话，其实也是可以用的 pair 的 ，极端的写法 pair &lt;int ,pair&lt;int ,int &gt; &gt; 写法极端。（后边的两个 &gt; &gt; 要有空格，否则就会是 &gt;&gt; 位移运算符）

pair&lt;int ,int &gt;p (5,6);
pair&lt;int ,int &gt; p1= make_pair(5,6);
pair&lt;string,double&gt; p2 (&quot;aa&quot;,5.0);
pair &lt;string ,double&gt; p3 = make_pair(&quot;aa&quot;,5.0);
有这两种写法来生成一个 pair。
如何取得 pair 的值呢。。
每个 pair 都有两个属性值 first 和 second    cout&lt;&lt;p1.first&lt;&lt;p1.second; 注意是属性值而不是方法。

一般 make_pair 都使用在需要 pair 做参数的位置，可以直接调用 make_pair 生成 pair 对象。make_pair 是根据 2 个参数类型推导出 pair 的 2 个模板参数类型的。另一个使用的方面就是 pair 可以接受隐式的类型转换，这样可以获得更高的灵活度。但是这样会出现如下问题：例如有如下两个定义：

```
<span style="font-size:18px;">std::pair<int, float>(1, 1.1);
std::make_pair(1, 1.1);
</span>

```

其中第一个的 second 变量是 float 类型，而 make_pair 函数会将 second 变量都转换成 double 类型。这个问题在编程是需要引起注意。下面是一段 pair 与 make_pair 的例子程序：

```c++
#include <iostream>
#include <utility>
#include <string>
using namespace std;
int main ()
{
        pair <string,double> product1 ("tomatoes",3.25);
	pair <string,double> product2;
	pair <string,double> product3;
 
	product2.first ="lightbulbs"; // type of first is string
	product2.second =0.99; // type of second is double
	
	product3 = make_pair ("shoes",20.0);
		
	cout <<"The price of "<< product1.first <<" is $"<< product1.second <<"\n";
	cout <<"The price of "<< product2.first <<" is $"<< product2.second <<"\n";
	cout <<"The price of "<< product3.first <<" is $"<< product3.second <<"\n";
	return 0;
}

```

map 是一个关联容器，里面存放的是键值对，容器中每一元素都是 pair 类型，通过 map 的 insert()方法来插入元素(pair 类型)。

mapStudent.insert(map&lt;int, string&gt;::value_type (1,&quot;student_one&quot;));

mapStudent.insert(make_pair(1, &quot;student_one&quot;));
